package com.maxxki;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maxxki.integrity.ChainEntry;
import com.maxxki.integrity.HashChain;
import com.maxxki.integrity.VerificationResult;
import com.maxxki.llm.*;
import com.maxxki.TaintAnalyzer;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Orchestrator v3.6 – MAXXKI Hybrid Analyser
 *
 * Änderungen gegenüber v3.5:
 *
 *   #2  InterruptedException in runJavaParserTaintAnalysis() nicht mehr
 *       verschluckt: Interrupt-Flag wird restauriert und Exception weitergereicht.
 *       Vorher: catch (Exception e) hat InterruptedException still gefressen.
 *       Fix: Separate catch-Blöcke für InterruptedException, TimeoutException,
 *       ExecutionException statt pauschales catch (Exception e).
 *
 *   #5  CLI-Pfad (runPipeline()) jetzt gegen Projekt-Root geprüft.
 *       Vorher: Kein Traversal-Check im CLI – Angreifer konnte beliebigen
 *       Pfad als Argument übergeben. Fix: Identische startsWith()-Prüfung
 *       wie im /api/analyse Server-Handler.
 *
 *   #8  CSP-Port dynamisch: CSP_HEADER als static final String entfernt.
 *       Neuer buildCspHeader(int port) und SERVER_PORT volatile static int.
 *       Vorher: hardcoded "http://localhost:7070" in CSP – bei anderem Port
 *       blockiert der Browser alle API-Aufrufe. Fix: SERVER_PORT wird in
 *       startServer() gesetzt, buildCspHeader() verwendet ihn zur Laufzeit.
 *
 * Unveränderte Fixes aus v3.5:
 *   #T1  Timeout-Konstanten: AGENT=120s, TAINT_FILE=360s, TAINT_OUTER=420s
 *   #T2  volatile für llmClient, hashChain, discourse, taintAnalyzer, CONFIDENCE_THRESHOLD
 *   #T3  runLLMFPReduction() – try-finally für lokalen ExecutorService
 *   #T4  ANALYSIS_POOL – Shutdown-Hook
 *   #6   Content-Security-Policy Header auf allen Responses
 *   #9   Rate-Limiting: max 10 req/min/IP
 */
public class Orchestrator {

    private static final Logger LOG = Logger.getLogger(Orchestrator.class.getName());

    static final String AGENTS_DIR   = Paths.get("").toAbsolutePath() + "/agents";
    static final String OUTPUT_DIR   = "output";
    static final int    DEFAULT_PORT = 7070;

    // ── Timeouts ──────────────────────────────────────────────────────────────
    static final int AGENT_TIMEOUT_SEC       = 120;
    static final int TAINT_FILE_TIMEOUT_SEC  = 360;
    static final int TAINT_OUTER_TIMEOUT_SEC = 420;

    // ── Rate-Limiting ─────────────────────────────────────────────────────────
    private static final int  MAX_REQUESTS_PER_MINUTE = 10;
    private static final long WINDOW_MS               = 60_000L;
    private static final ConcurrentMap<String, Deque<Long>> rateLimitMap = new ConcurrentHashMap<>();

    private static boolean isRateLimited(String clientIp) {
        long now = System.currentTimeMillis();
        Deque<Long> timestamps = rateLimitMap.computeIfAbsent(clientIp, k -> new ArrayDeque<>());
        synchronized (timestamps) {
            while (!timestamps.isEmpty() && (now - timestamps.peekFirst()) > WINDOW_MS) {
                timestamps.pollFirst();
            }
            if (timestamps.size() >= MAX_REQUESTS_PER_MINUTE) return true;
            timestamps.addLast(now);
        }
        if (rateLimitMap.size() > 10_000) {
            rateLimitMap.entrySet().removeIf(entry -> {
                synchronized (entry.getValue()) {
                    return entry.getValue().isEmpty() ||
                        (now - entry.getValue().peekFirst()) > WINDOW_MS * 2;
                }
            });
        }
        return false;
    }

    // ── CSP – FIX #8: Dynamischer Port statt hardcoded ──────────────────────
    //
    // Vorher: static final String CSP_HEADER mit hardcoded "http://localhost:7070"
    // Problem: Bei abweichendem Port blockiert CSP alle XHR/fetch-Aufrufe.
    // Fix: buildCspHeader(port) + volatile SERVER_PORT der in startServer() gesetzt wird.
    //
    // volatile: Wird im main()-Thread geschrieben, danach von HTTP-Handler-Threads gelesen.
    // Ohne volatile: Keine JMM-Garantie dass Handler-Threads den aktualisierten Wert sehen.
    private static volatile int SERVER_PORT = DEFAULT_PORT;

    /**
     * Baut den CSP-Header mit dem tatsächlich verwendeten Port.
     * FIX #8: Ersetzt die static final CSP_HEADER Konstante.
     */
    private static String buildCspHeader(int port) {
        return
            "default-src 'self'; " +
            "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com " +
                "https://cdn.tailwindcss.com https://fonts.googleapis.com; " +
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com " +
                "https://fonts.gstatic.com; " +
            "font-src 'self' https://fonts.gstatic.com; " +
            "connect-src 'self' http://localhost:" + port + "; " +
            "img-src 'self' data:; " +
            "frame-ancestors 'none'; " +
            "base-uri 'self'";
    }

    // ── Regex-Vorfilter ────────────────────────────────────────────────────────
    private static final Pattern QUICK_TAINT_FILTER = Pattern.compile(
        "getParameter|getHeader|getInputStream|getReader|getRequestURI|getQueryString" +
        "|getCookies|getAttribute|PathVariable|RequestParam|RequestBody|RequestHeader" +
        "|getenv|getProperty|readLine|readAllBytes",
        Pattern.MULTILINE
    );

    // ── Komponenten ───────────────────────────────────────────────────────────
    private static volatile LLMClient        llmClient;
    private static volatile HashChain        hashChain;
    private static volatile PersonaDiscourse discourse;
    private static volatile TaintAnalyzer    taintAnalyzer;
    private static volatile double           CONFIDENCE_THRESHOLD = 0.7;

    // ObjectMapper: thread-safe laut Jackson-Doku
    private static final ObjectMapper mapper = new ObjectMapper();

    private static volatile ExecutorService ANALYSIS_POOL;

    // ═════════════════════════════════════════════════════════════════════════
    // MAIN
    // ═════════════════════════════════════════════════════════════════════════

    public static void main(String[] args) throws Exception {
        Properties props = loadProperties();
        initComponents(props);

        if (args.length > 0 && args[0].equals("--server")) {
            int port = (args.length > 1) ? Integer.parseInt(args[1]) : DEFAULT_PORT;
            startServer(port);
            return;
        }
        String target = (args.length > 0) ? args[0] : "target";
        System.out.println("\n" + "=".repeat(62));
        System.out.println("  MAXXKI Hybrid Analyser v3.6 – CLI");
        System.out.println("=".repeat(62));
        String result = runPipeline(target);
        System.out.println(result);
    }

    // ═════════════════════════════════════════════════════════════════════════
    // INITIALIZATION
    // ═════════════════════════════════════════════════════════════════════════

    static Properties loadProperties() {
        Properties props = new Properties();
        props.setProperty("llm.enabled",              "true");
        props.setProperty("llm.url",                  "http://127.0.0.1:8080");
        props.setProperty("llm.model",                "Qwen2:1.5B-instruct");
        props.setProperty("llm.temperature",          "0.4");
        props.setProperty("llm.max_tokens",           "350");
        props.setProperty("llm.timeout_seconds",      "30");
        props.setProperty("llm.retry_attempts",       "3");
        props.setProperty("blake3.chain.path",        "hashes/chain.jsonl");
        props.setProperty("discourse.default_rounds", "4");
        props.setProperty("taint.enabled",            "true");
        props.setProperty("taint.source_root",        ".");
        props.setProperty("taint.max_files",          "500");

        Path configPath = Paths.get("config/maxxki.properties");
        if (Files.exists(configPath)) {
            try (InputStream in = Files.newInputStream(configPath)) {
                props.load(in);
                LOG.info("Loaded config: " + configPath);
            } catch (IOException e) {
                LOG.warning("Could not load maxxki.properties: " + e.getMessage());
            }
        } else {
            LOG.info("No config/maxxki.properties found – using defaults.");
        }
        return props;
    }

    static void initComponents(Properties props) {
        llmClient = new LLMClient(props);
        hashChain = new HashChain(Paths.get(props.getProperty("blake3.chain.path")));
        discourse = new PersonaDiscourse(llmClient, hashChain);

        if (Boolean.parseBoolean(props.getProperty("blake3.chain.verify_on_start", "true"))) {
            VerificationResult vr = hashChain.verify();
            if (vr.valid) LOG.info("[chain] Integrity OK – " + vr.message);
            else          LOG.severe("[chain] INTEGRITY BROKEN! " + vr.message);
        }

        CONFIDENCE_THRESHOLD = Double.parseDouble(props.getProperty("llm.confidence_threshold", "0.7"));
        LOG.info("LLM enabled: " + llmClient.isEnabled());

        if (Boolean.parseBoolean(props.getProperty("taint.enabled", "true"))) {
            Path sourceRoot = Paths.get(props.getProperty("taint.source_root", ".")).toAbsolutePath();
            taintAnalyzer = new TaintAnalyzer(sourceRoot);
            LOG.info("[TaintAnalyzer] Initialized with source root: " + sourceRoot);
        } else {
            LOG.info("[TaintAnalyzer] Disabled in config (taint.enabled=false)");
        }

        int cores = Runtime.getRuntime().availableProcessors();
        ANALYSIS_POOL = Executors.newFixedThreadPool(Math.max(2, cores));
        LOG.info("[Pool] Analysis thread pool: " + cores + " threads");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOG.info("[Pool] Shutdown hook triggered – shutting down ANALYSIS_POOL...");
            ExecutorService pool = ANALYSIS_POOL;
            if (pool != null && !pool.isShutdown()) {
                pool.shutdown();
                try {
                    if (!pool.awaitTermination(10, TimeUnit.SECONDS)) {
                        pool.shutdownNow();
                        LOG.warning("[Pool] ANALYSIS_POOL did not terminate cleanly – forced shutdown.");
                    }
                } catch (InterruptedException e) {
                    pool.shutdownNow();
                    Thread.currentThread().interrupt();
                }
            }
        }, "maxxki-pool-shutdown"));
    }

    // ═════════════════════════════════════════════════════════════════════════
    // SERVER
    // ═════════════════════════════════════════════════════════════════════════

    static void startServer(int port) throws Exception {
        // FIX #8: SERVER_PORT vor server.start() setzen, damit addSecurityHeaders()
        // den korrekten Port im CSP-Header verwendet.
        SERVER_PORT = port;

        Files.createDirectories(Paths.get(OUTPUT_DIR));
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.setExecutor(Executors.newFixedThreadPool(8));

        // ── /api/analyse ──────────────────────────────────────────────────────
        server.createContext("/api/analyse", ex -> {
            addCors(ex);
            addSecurityHeaders(ex);

            if ("OPTIONS".equals(ex.getRequestMethod())) { respond(ex, 200, ""); return; }
            if (!"GET".equals(ex.getRequestMethod()))    { respond(ex, 405, ""); return; }

            String clientIp = getClientIp(ex);
            if (isRateLimited(clientIp)) {
                respond(ex, 429, json("error", "Rate limit exceeded. Max " +
                    MAX_REQUESTS_PER_MINUTE + " requests per minute."));
                return;
            }

            String query  = ex.getRequestURI().getQuery();
            String target = parseParam(query, "path");
            if (target == null || target.isEmpty()) target = "target";

            Path base = Paths.get(".").toAbsolutePath().normalize();
            Path tgt  = Paths.get(target).toAbsolutePath().normalize();
            if (!tgt.startsWith(base)) {
                respond(ex, 403, json("error", "Path outside project root.")); return;
            }
            if (!Files.isDirectory(tgt)) {
                respond(ex, 404, json("error", "Directory not found: " + target)); return;
            }

            try {
                String filesJson    = runAgent("fileReader.js",   target);
                String analysisJson = runAgent("codeAnalyzer.js", filesJson);
                String payload      = buildPayload(filesJson, analysisJson, target);
                String report       = runAgent("mdGenerator.js",  payload);

                final String finalTarget       = target;
                final String finalAnalysisJson = analysisJson;

                CompletableFuture<String> taintFuture = CompletableFuture.supplyAsync(() -> {
                    if (taintAnalyzer == null) return buildEmptyTaintResult();
                    try {
                        return runJavaParserTaintAnalysis(finalTarget, finalAnalysisJson);
                    } catch (Exception e) {
                        LOG.warning("[TaintAnalyzer] Failed (non-fatal): " + e.getMessage());
                        return buildEmptyTaintResult();
                    }
                }, ANALYSIS_POOL);

                CompletableFuture<String> llmFuture = CompletableFuture.supplyAsync(() -> {
                    if (!llmClient.isEnabled() || !llmClient.isHealthy()) return "null";
                    try {
                        return runLLMFPReduction(finalAnalysisJson);
                    } catch (Exception e) {
                        LOG.warning("[LLM] FP reduction failed (non-fatal): " + e.getMessage());
                        return "null";
                    }
                }, ANALYSIS_POOL);

                String taintJson = "null";
                String llmJson   = "null";
                try {
                    taintJson = taintFuture.get(TAINT_OUTER_TIMEOUT_SEC, TimeUnit.SECONDS);
                } catch (TimeoutException e) {
                    LOG.warning("[TaintAnalyzer] Timeout after " + TAINT_OUTER_TIMEOUT_SEC + "s – returning partial results");
                    taintFuture.cancel(true);
                }
                try {
                    llmJson = llmFuture.get(45, TimeUnit.SECONDS);
                } catch (TimeoutException e) {
                    LOG.warning("[LLM] Timeout after 45s");
                    llmFuture.cancel(true);
                }

                String broadcastJson = extractBroadcastInfo(analysisJson);

                String ts   = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
                String name = OUTPUT_DIR + "/report_" + ts + ".md";
                Files.writeString(Paths.get(name), report);

                String body = "{\"status\":\"ok\","
                    + "\"report\":"     + jsonString(report)  + ","
                    + "\"analysis\":"   + analysisJson         + ","
                    + "\"taint\":"      + taintJson            + ","
                    + "\"broadcast\":"  + broadcastJson        + ","
                    + "\"llmSummary\":" + llmJson              + ","
                    + "\"savedAs\":"    + jsonString(name)     + "}";

                respond(ex, 200, body);

            } catch (Exception e) {
                LOG.severe("/api/analyse error: " + e.getMessage());
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        server.createContext("/api/health", ex -> {
            addCors(ex);
            addSecurityHeaders(ex);
            boolean agentsOk     = Files.isDirectory(Paths.get(AGENTS_DIR));
            boolean taintEnabled = taintAnalyzer != null;
            respond(ex, 200, "{\"status\":\"ok\","
                + "\"agents\":"    + agentsOk     + ","
                + "\"taint_ast\":" + taintEnabled + ","
                + "\"version\":\"3.6-hybrid\"}");
        });

        // ── LLM Endpoints ────────────────────────────────────────────────────

        server.createContext("/api/llm/analyze", ex -> {
            addCors(ex);
            addSecurityHeaders(ex);
            if ("OPTIONS".equals(ex.getRequestMethod())) { respond(ex, 200, ""); return; }
            if (!"POST".equals(ex.getRequestMethod()))   { respond(ex, 405, json("error", "POST required")); return; }

            String clientIp = getClientIp(ex);
            if (isRateLimited(clientIp)) {
                respond(ex, 429, json("error", "Rate limit exceeded."));
                return;
            }

            try {
                String   body   = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                JsonNode req    = mapper.readTree(body);
                String   type   = req.path("type").asText("UNKNOWN");
                String   code   = req.path("code").asText("");

                if (code.isEmpty()) { respond(ex, 400, json("error", "Field 'code' is required")); return; }

                LLMJudge judge = discourse.quickJudge(type, code);
                if (judge == null) { respond(ex, 503, json("error", "LLM not available.")); return; }

                VerificationResult vr = hashChain.verify();
                respond(ex, 200, "{" +
                    "\"verdict\":"    + jsonString(judge.judgement)  + "," +
                    "\"confidence\":" + judge.confidence             + "," +
                    "\"tps\":"        + judge.tps                    + "," +
                    "\"blake3_hash\":" + jsonString(judge.blake3Hash) + "," +
                    "\"chain_valid\":" + vr.valid                    + "," +
                    "\"is_real\":"    + (judge.confidence >= CONFIDENCE_THRESHOLD) + "}");

            } catch (Exception e) {
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        server.createContext("/api/llm/discourse", ex -> {
            addCors(ex);
            addSecurityHeaders(ex);
            if ("OPTIONS".equals(ex.getRequestMethod())) { respond(ex, 200, ""); return; }
            if (!"POST".equals(ex.getRequestMethod()))   { respond(ex, 405, json("error", "POST required")); return; }

            String clientIp = getClientIp(ex);
            if (isRateLimited(clientIp)) {
                respond(ex, 429, json("error", "Rate limit exceeded."));
                return;
            }

            try {
                String   body   = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                JsonNode req    = mapper.readTree(body);
                String   topic  = req.path("topic").asText("");
                int      rounds = req.path("rounds").asInt(4);

                if (topic.isEmpty()) { respond(ex, 400, json("error", "Field 'topic' is required")); return; }

                DiscourseResult result = discourse.runDiscourse(topic, rounds);
                respond(ex, 200, discourseToJson(result));

            } catch (Exception e) {
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        server.createContext("/api/llm/health", ex -> {
            addCors(ex);
            addSecurityHeaders(ex);
            if (!"GET".equals(ex.getRequestMethod())) { respond(ex, 405, ""); return; }

            boolean llmOk = llmClient.isEnabled() && llmClient.isHealthy();
            VerificationResult vr = hashChain.verify();
            respond(ex, 200, "{" +
                "\"llm_available\":"   + llmOk                            + "," +
                "\"llm_enabled\":"     + llmClient.isEnabled()            + "," +
                "\"model\":"           + jsonString(llmClient.getModel()) + "," +
                "\"last_tps\":"        + llmClient.getLastTPS()           + "," +
                "\"last_tokens\":"     + llmClient.getLastTokens()        + "," +
                "\"taint_ast\":"       + (taintAnalyzer != null)          + "," +
                "\"chain_integrity\":" + vr.valid                         + "," +
                "\"chain_size\":"      + hashChain.size()                 + "," +
                "\"last_hash\":"       + jsonString(hashChain.getLastHash()) + "," +
                "\"chain_message\":"   + jsonString(vr.message)           + "}");
        });

        server.createContext("/api/llm/export", ex -> {
            addCors(ex);
            addSecurityHeaders(ex);
            if (!"GET".equals(ex.getRequestMethod())) { respond(ex, 405, ""); return; }
            try {
                Files.createDirectories(Paths.get("exports"));
                Path exportPath = Paths.get("exports/chain_" + System.currentTimeMillis() + ".jsonl");
                hashChain.export(exportPath);
                respond(ex, 200, "{\"status\":\"ok\",\"exported\":" + jsonString(exportPath.toString()) +
                    ",\"entries\":" + hashChain.size() + "}");
            } catch (Exception e) {
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        server.createContext("/", ex -> {
            if (!"GET".equals(ex.getRequestMethod())) { respond(ex, 405, ""); return; }
            addSecurityHeaders(ex);
            Path html = Paths.get("frontend/index.html");
            if (!Files.exists(html)) {
                byte[] msg = "frontend/index.html not found".getBytes();
                ex.getResponseHeaders().set("Content-Type", "text/plain");
                ex.sendResponseHeaders(404, msg.length);
                try (OutputStream o = ex.getResponseBody()) { o.write(msg); }
                return;
            }
            byte[] bytes = Files.readAllBytes(html);
            ex.getResponseHeaders().set("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(200, bytes.length);
            try (OutputStream o = ex.getResponseBody()) { o.write(bytes); }
        });

        server.start();
        System.out.println("\n" + "=".repeat(68));
        System.out.println("  MAXXKI Hybrid Analyser – API Server v3.6");
        System.out.println("=".repeat(68));
        System.out.println("  http://localhost:" + port);
        System.out.println("  Stufe 1 – Regex/Node.js:  Struktur · Broadcast · Legacy · SCC");
        System.out.println("  Stufe 2 – JavaParser AST: Interprozeduraler Taint-Fluss");
        System.out.println("  Stufe 3 – LLM:            " +
            (llmClient.isEnabled() ? "ENABLED (" + llmClient.getModel() + ")" : "DISABLED"));
        System.out.println("  Timeouts: Agenten=" + AGENT_TIMEOUT_SEC + "s" +
            " | TaintFile=" + TAINT_FILE_TIMEOUT_SEC + "s" +
            " | TaintOuter=" + TAINT_OUTER_TIMEOUT_SEC + "s");
        System.out.println("  Rate-Limit: " + MAX_REQUESTS_PER_MINUTE + " req/min/IP");
        System.out.println("=".repeat(68));
        System.out.println("  Press Ctrl+C to stop.\n");
    }

    // ═════════════════════════════════════════════════════════════════════════
    // STUFE 2 – JAVAPARSER TAINT-ANALYSE
    // ═════════════════════════════════════════════════════════════════════════

    private static String runJavaParserTaintAnalysis(String targetPath, String analysisJson)
            throws Exception {

        Path srcPath = Paths.get(targetPath).toAbsolutePath();
        if (!Files.isDirectory(srcPath)) return buildEmptyTaintResult();

        List<Path> allJavaFiles;
        try (var stream = Files.walk(srcPath)) {
            allJavaFiles = stream
                .filter(p -> p.toString().endsWith(".java"))
                .limit(500)
                .collect(Collectors.toList());
        }

        if (allJavaFiles.isEmpty()) return buildEmptyTaintResult();

        List<Path> candidates = allJavaFiles.parallelStream()
            .filter(p -> {
                try {
                    String content = Files.readString(p);
                    return QUICK_TAINT_FILTER.matcher(content).find();
                } catch (IOException e) {
                    return false;
                }
            })
            .collect(Collectors.toList());

        LOG.info(String.format("[TaintAnalyzer] Files: %d total, %d with taint sources (%.0f%% filtered out)",
            allJavaFiles.size(), candidates.size(),
            allJavaFiles.isEmpty() ? 0 : (1.0 - (double) candidates.size() / allJavaFiles.size()) * 100));

        if (candidates.isEmpty()) return buildEmptyTaintResult();

        List<CompletableFuture<Void>> futures = candidates.stream()
            .map(filePath -> CompletableFuture.runAsync(
                () -> taintAnalyzer.analyzeFile(filePath),
                ANALYSIS_POOL
            ))
            .collect(Collectors.toList());

        // FIX #2: Separate catch-Blöcke statt pauschales catch (Exception e).
        // InterruptedException darf nicht still verschluckt werden – das würde
        // das Interrupt-Flag löschen und Thread-Koordination korrumpieren.
        try {
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .get(TAINT_FILE_TIMEOUT_SEC, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            // FIX #2: Interrupt-Flag restaurieren, dann weiterwerfen
            Thread.currentThread().interrupt();
            throw new Exception("Taint analysis interrupted", e);
        } catch (TimeoutException e) {
            LOG.warning("[TaintAnalyzer] File-pass timeout after " + TAINT_FILE_TIMEOUT_SEC + "s – partial results");
            futures.forEach(f -> f.cancel(true));
            // Kein Re-throw: Wir arbeiten mit dem was bisher fertig ist
        } catch (ExecutionException e) {
            // Einzelne Datei-Analyse fehlgeschlagen – kein fataler Fehler
            LOG.warning("[TaintAnalyzer] File-pass execution error: " +
                (e.getCause() != null ? e.getCause().getMessage() : e.getMessage()));
        }

        taintAnalyzer.runInterproceduralPass(candidates);

        return taintAnalyzer.mergeWithRegexAnalysis(analysisJson);
    }

    private static String buildEmptyTaintResult() {
        return "{\"vulnerabilities\":[],\"summary\":{\"totalVulnerabilities\":0," +
               "\"critical\":0,\"high\":0,\"fromJavaParser\":0,\"fromRegex\":0," +
               "\"interproceduralMethods\":0}}";
    }

    // ═════════════════════════════════════════════════════════════════════════
    // BROADCAST-INFO EXTRAKTOR
    // ═════════════════════════════════════════════════════════════════════════

    private static String extractBroadcastInfo(String analysisJson) {
        try {
            JsonNode analysis = mapper.readTree(analysisJson);

            JsonNode broadcastFiles = analysis.path("broadcastFiles");
            JsonNode domainMap      = analysis.path("domainMap");
            JsonNode hardwareFiles  = domainMap.path("HARDWARE");
            JsonNode realtimeFiles  = domainMap.path("REALTIME");

            int broadcastCount = broadcastFiles.size();
            int hardwareCount  = hardwareFiles.size();
            int realtimeCount  = realtimeFiles.size();

            JsonNode vulns        = analysis.path("security").path("vulnerabilities");
            int totalVulns        = vulns.size();
            int criticalVulns     = 0;
            for (JsonNode v : vulns) {
                if ("CRITICAL".equals(v.path("severity").asText())) criticalVulns++;
            }

            int criticalityScore = Math.min(
                (broadcastCount * 10) +
                (hardwareCount  * 15) +
                (realtimeCount  *  8) +
                (criticalVulns  * 20),
                100
            );

            String riskLevel = criticalityScore >= 70 ? "DO_NOT_TOUCH"
                             : criticalityScore >= 50 ? "ANALYZE_ONLY"
                             : criticalityScore >= 30 ? "SAFE_TRANSFORM"
                             :                          "MICROSERVICE_WRAP";

            Set<String> allCriticalSet = new LinkedHashSet<>();
            for (JsonNode f : broadcastFiles) allCriticalSet.add(f.asText());
            for (JsonNode f : hardwareFiles)  allCriticalSet.add(f.asText());
            for (JsonNode f : realtimeFiles)  allCriticalSet.add(f.asText());

            StringBuilder criticalFilesArr = new StringBuilder("[");
            boolean first = true;
            for (String filePath : allCriticalSet) {
                if (!first) criticalFilesArr.append(",");
                first = false;

                boolean isBroadcast = false;
                for (JsonNode f : broadcastFiles) { if (filePath.equals(f.asText())) { isBroadcast = true; break; } }
                boolean isHardware = false;
                for (JsonNode f : hardwareFiles)  { if (filePath.equals(f.asText())) { isHardware  = true; break; } }
                boolean isRealtime = false;
                for (JsonNode f : realtimeFiles)  { if (filePath.equals(f.asText())) { isRealtime  = true; break; } }

                int fileScore = (isBroadcast ? 50 : 0) + (isHardware ? 30 : 0) + (isRealtime ? 20 : 0);

                criticalFilesArr.append("{")
                    .append("\"path\":").append(jsonString(filePath)).append(",")
                    .append("\"broadcast\":").append(isBroadcast).append(",")
                    .append("\"hardware\":").append(isHardware).append(",")
                    .append("\"realtime\":").append(isRealtime).append(",")
                    .append("\"criticalityScore\":").append(fileScore)
                    .append("}");
            }
            criticalFilesArr.append("]");

            return "{" +
                "\"broadcastCount\":"          + broadcastCount              + "," +
                "\"hardwareCount\":"           + hardwareCount               + "," +
                "\"realtimeCount\":"           + realtimeCount               + "," +
                "\"totalVulnerabilities\":"    + totalVulns                  + "," +
                "\"criticalVulnerabilities\":" + criticalVulns               + "," +
                "\"criticalityScore\":"        + criticalityScore            + "," +
                "\"riskLevel\":"               + jsonString(riskLevel)       + "," +
                "\"criticalFiles\":"           + criticalFilesArr.toString() +
                "}";

        } catch (Exception e) {
            LOG.warning("extractBroadcastInfo failed (non-fatal): " + e.getMessage());
            return "{\"broadcastCount\":0,\"hardwareCount\":0,\"realtimeCount\":0," +
                   "\"totalVulnerabilities\":0,\"criticalVulnerabilities\":0," +
                   "\"criticalityScore\":0,\"riskLevel\":\"UNKNOWN\",\"criticalFiles\":[]}";
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // STUFE 3 – LLM FALSE-POSITIVE REDUCTION
    // ═════════════════════════════════════════════════════════════════════════

    private static String runLLMFPReduction(String analysisJson) throws Exception {
        JsonNode analysis = mapper.readTree(analysisJson);
        JsonNode vulns    = analysis.path("security").path("vulnerabilities");

        if (vulns.isEmpty()) return "[]";

        // try-finally garantiert pool.shutdown() auch bei Exception (FIX aus v3.5 #T3)
        ExecutorService pool = Executors.newFixedThreadPool(3);
        try {
            List<CompletableFuture<String>> futures = new ArrayList<>();

            int limit = Math.min(vulns.size(), 10);
            for (int i = 0; i < limit; i++) {
                final JsonNode vuln = vulns.get(i);
                futures.add(CompletableFuture.supplyAsync(() -> {
                    try {
                        String   type  = vuln.path("type").asText("UNKNOWN");
                        String   code  = vuln.path("code").asText("");
                        String   file  = vuln.path("file").asText("");
                        LLMJudge judge = discourse.quickJudge(type, code);
                        if (judge == null) {
                            return "{\"type\":" + jsonString(type) + ",\"file\":" + jsonString(file) +
                                ",\"llm_verdict\":\"UNAVAILABLE\",\"confidence\":0.5,\"is_real\":null}";
                        }
                        return "{\"type\":" + jsonString(type) + ",\"file\":" + jsonString(file) +
                            ",\"llm_verdict\":" + jsonString(judge.judgement.substring(0, Math.min(200, judge.judgement.length()))) +
                            ",\"confidence\":" + judge.confidence +
                            ",\"tps\":" + judge.tps +
                            ",\"blake3_hash\":" + jsonString(judge.blake3Hash) +
                            ",\"is_real\":" + (judge.confidence >= CONFIDENCE_THRESHOLD) + "}";
                    } catch (Exception e) {
                        return "{\"error\":" + jsonString(e.getMessage()) + "}";
                    }
                }, pool));
            }

            StringBuilder sb      = new StringBuilder("[");
            List<String>  results = futures.stream()
                .map(f -> { try { return f.get(35, TimeUnit.SECONDS); } catch (Exception e) { return "{\"error\":\"timeout\"}"; } })
                .collect(Collectors.toList());
            for (int i = 0; i < results.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append(results.get(i));
            }
            sb.append("]");
            return sb.toString();

        } finally {
            pool.shutdown();
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // CLI PIPELINE
    // ═════════════════════════════════════════════════════════════════════════

    static String runPipeline(String target) throws Exception {
        // FIX #5: CLI-Pfad gegen Projekt-Root prüfen – identisch mit Server-Handler.
        // Vorher: Kein Traversal-Check – beliebiger Pfad als CLI-Argument möglich.
        // Fix: Kanonischer Pfad-Vergleich mit startsWith() gegen Projekt-Root.
        Path base = Paths.get(".").toAbsolutePath().normalize();
        Path tgt  = Paths.get(target).toAbsolutePath().normalize();
        if (!tgt.startsWith(base)) {
            throw new IllegalArgumentException(
                "Path outside project root: " + target);
        }
        if (!Files.isDirectory(tgt)) {
            throw new IllegalArgumentException(
                "Not a directory: " + target);
        }

        Files.createDirectories(Paths.get(OUTPUT_DIR));

        System.out.println("[1/4] Scanning Java files …");
        String filesJson    = runAgent("fileReader.js",   target);

        System.out.println("[2/4] Regex analysis (Broadcast · Legacy · SCC · Memory) …");
        String analysisJson = runAgent("codeAnalyzer.js", filesJson);

        System.out.println("[3/4] JavaParser taint analysis (interprocedural) …");
        String taintJson = buildEmptyTaintResult();
        if (taintAnalyzer != null) {
            try {
                taintJson = runJavaParserTaintAnalysis(target, analysisJson);
            } catch (Exception e) {
                LOG.warning("[TaintAnalyzer] CLI failed: " + e.getMessage());
            }
        }

        System.out.println("[4/4] Generating semantic report …");
        String payload = buildPayload(filesJson, analysisJson, target);
        String report  = runAgent("mdGenerator.js", payload);

        String ts   = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
        String name = OUTPUT_DIR + "/report_" + ts + ".md";
        Files.writeString(Paths.get(name), report);
        System.out.println("\nSaved → " + name);
        System.out.println("Taint findings: " + countTaintFindings(taintJson) + "\n");

        return report;
    }

    private static int countTaintFindings(String taintJson) {
        try {
            return mapper.readTree(taintJson).path("vulnerabilities").size();
        } catch (Exception e) {
            return 0;
        }
    }

    // ═════════════════════════════════════════════════════════════════════════
    // AGENT RUNNER
    // ═════════════════════════════════════════════════════════════════════════

    static String runAgent(String agentName, String input) throws Exception {
        String agentPath = AGENTS_DIR + "/" + agentName;
        if (!Files.exists(Paths.get(agentPath)))
            throw new Exception("Agent not found: " + agentPath);

        ProcessBuilder pb = new ProcessBuilder("node", "--max-old-space-size=512", agentPath);
        pb.redirectErrorStream(false);
        Process p = pb.start();

        try (OutputStream stdin = p.getOutputStream()) {
            stdin.write(input.getBytes(StandardCharsets.UTF_8));
        }

        final StringBuilder outBuf = new StringBuilder();
        final StringBuilder errBuf = new StringBuilder();
        Thread outReader = new Thread(() -> {
            try { outBuf.append(new String(p.getInputStream().readAllBytes(), StandardCharsets.UTF_8)); } catch (IOException ignored) {}
        });
        Thread errReader = new Thread(() -> {
            try { errBuf.append(new String(p.getErrorStream().readAllBytes(), StandardCharsets.UTF_8)); } catch (IOException ignored) {}
        });
        outReader.start(); errReader.start();

        if (!p.waitFor(AGENT_TIMEOUT_SEC, TimeUnit.SECONDS)) {
            p.destroyForcibly();
            throw new Exception("Timeout (" + AGENT_TIMEOUT_SEC + "s): " + agentName);
        }
        outReader.join(); errReader.join();

        String out = outBuf.toString().trim();
        String err = errBuf.toString().trim();
        if (p.exitValue() != 0)
            throw new Exception("Agent '" + agentName + "' failed: " + (err.isEmpty() ? out : err));
        return out;
    }

    // ═════════════════════════════════════════════════════════════════════════
    // UTILITIES
    // ═════════════════════════════════════════════════════════════════════════

    static String buildPayload(String filesJson, String analysisJson, String project) {
        return "{\"files\":"    + filesJson
             + ",\"analysis\":" + analysisJson
             + ",\"project\":"  + jsonString(project)
             + ",\"date\":"     + jsonString(LocalDateTime.now().toString())
             + "}";
    }

    private static String discourseToJson(DiscourseResult r) throws Exception {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"topic\":").append(jsonString(r.topic)).append(",");
        sb.append("\"consensus\":").append(jsonString(r.consensus)).append(",");
        sb.append("\"blake3_root_hash\":").append(jsonString(r.blake3RootHash)).append(",");
        sb.append("\"average_tps\":").append(r.averageTPS).append(",");
        sb.append("\"rounds\":[");
        for (int i = 0; i < r.rounds.size(); i++) {
            if (i > 0) sb.append(",");
            DiscourseRound rnd = r.rounds.get(i);
            sb.append("{")
              .append("\"round\":").append(rnd.roundNumber).append(",")
              .append("\"persona\":").append(jsonString(rnd.persona.name())).append(",")
              .append("\"role\":").append(jsonString(rnd.persona.role)).append(",")
              .append("\"content\":").append(jsonString(rnd.content)).append(",")
              .append("\"confidence\":").append(rnd.confidence).append(",")
              .append("\"tps\":").append(rnd.tps).append(",")
              .append("\"blake3_hash\":").append(jsonString(rnd.blake3Hash))
              .append("}");
        }
        sb.append("]}");
        return sb.toString();
    }

    static String jsonString(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\","\\\\").replace("\"","\\\"")
                       .replace("\n","\\n").replace("\r","\\r")
                       .replace("\t","\\t") + "\"";
    }

    static String json(String key, String value) {
        return "{\"" + key + "\":" + jsonString(value) + "}";
    }

    static String parseParam(String query, String key) {
        if (query == null) return null;
        for (String part : query.split("&")) {
            String[] kv = part.split("=", 2);
            if (kv.length == 2 && kv[0].equals(key))
                return java.net.URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
        }
        return null;
    }

    static void addCors(HttpExchange ex) {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin",  "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
    }

    /**
     * FIX #8: Verwendet buildCspHeader(SERVER_PORT) statt hardcoded CSP_HEADER.
     * SERVER_PORT ist volatile und wird in startServer() vor server.start() gesetzt.
     */
    static void addSecurityHeaders(HttpExchange ex) {
        ex.getResponseHeaders().add("Content-Security-Policy", buildCspHeader(SERVER_PORT));
        ex.getResponseHeaders().add("X-Content-Type-Options",  "nosniff");
        ex.getResponseHeaders().add("X-Frame-Options",         "DENY");
        ex.getResponseHeaders().add("Referrer-Policy",         "strict-origin-when-cross-origin");
    }

    static String getClientIp(HttpExchange ex) {
        String forwarded = ex.getRequestHeaders().getFirst("X-Forwarded-For");
        if (forwarded != null && !forwarded.isBlank()) {
            String first = forwarded.split(",")[0].trim();
            if (first.matches("[\\w.:]+")) return first;
        }
        return ex.getRemoteAddress().getAddress().getHostAddress();
    }

    static void respond(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }
}
