#  MAXXKI Deep Semantic Analyser v3.2-LLM

[![Java](https://img.shields.io/badge/Java-17+-orange.svg)](https://adoptium.net/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

Semantic code analysis with LLM-powered false-positive reduction and BLAKE3-verified audit chains.

**MAXXKI Deep Semantic Analyser (v3.2)** – eine hybride Architektur aus statischer Code-Analyse und einer mehrstufigen LLM-Diskurs-Engine.

# System-Übersicht: Die Core-Architektur

Das System ist in zwei Hauptkomponenten unterteilt:

 1. **Die Analyse-Pipeline (Node.js/JavaScript):** Verantwortlich für das schnelle Scannen von Quellcode auf struktureller und semantischer Ebene.
 2. **Der Orchestrator & LLM-Kern (Java):** Das "Gehirn", das die Ergebnisse verwaltet, einen mehrstufigen KI-Diskurs steuert und die Datenintegrität via Blockchain-Hashing sichert.

# 1. Die Analyse-Engines (codeAnalyzer.js, fileReader.js)
Diese Komponenten bilden die Basis der Datenerfassung:

 * **Deep Semantic Analysis:** Anders als einfache Linter führt der codeAnalyzer.js eine **Taint Flow Analysis** durch. Er verfolgt Datenflüsse von der Quelle (Source) bis zur Senke (Sink), um Schwachstellen wie SQL-Injections oder Command-Injections zu finden.
 * **SCC & Kopplung:** Mithilfe des **Tarjan-Algorithmus** werden stark zusammenhängende Komponenten (Strongly Connected Components) identifiziert, um zirkuläre Abhängigkeiten und komplexe Architektur-Cluster zu finden.
 * **Memory Leak Detection:** Der Analysator sucht gezielt nach ungeschlossenen Ressourcen, ThreadLocal-Missbrauch oder unbegrenzten Caches.

# 2. Der Orchestrator (Orchestrator.java)
Dies ist der zentrale Kontrollpunkt des Systems. Er fungiert als HTTP-Server und steuert den gesamten Workflow:
 
* **Schnittstellen:** Er bietet Endpunkte für die Analyse (/api/analyse), den KI-Diskurs (/api/llm/discourse) und Healthchecks an.
 * **Prozess-Steuerung:** Er ruft die Node.js-Agenten auf, verarbeitet deren JSON-Output und leitet kritische Funde an das LLM-Subsystem weiter.

# 3. Das LLM-Persona-System (PersonaDiscourse.java)
Dies ist das Herzstück deiner "Back to the roots"-Philosophie. Statt einer einfachen KI-Antwort nutzt du ein **4-Persona-Modell**, um höchste Präzision zu erreichen:
 
* **DOMINUS (Red-Team Researcher):** Findet aktiv neue Angriffsvektoren.
 * **AXIOM (Forensic Analyst):** Vertieft die technischen Details und Auswirkungen.
 * **CIPHER (Critic):** Hinterfragt die Aussagen der anderen kritisch auf Fehler.
 * **VECTOR (Strategist):** Fasst die Ergebnisse zusammen und bewertet die strategische Relevanz.
 * **Confidence Scoring:** Jede Persona gibt einen Konfidenzwert (0.0 bis 1.0) ab, woraus ein Gesamtdurchschnitt ermittelt wird.
# 4. Datenintegrität & Performance (LLMClient.java, HashChain)
 
* **BLAKE3 Integrity Chain:** Jede KI-Antwort und jeder Analyse-Schritt wird mit einem BLAKE3-Hash versehen. Diese Hashes werden in einer Kette (Hash-Chain) verknüpft. Damit ist das System revisionssicher – man kann im Nachhinein beweisen, dass die Analyseergebnisse nicht manipuliert wurden.
 * **Performance Monitoring:** Der LLMClient misst die **TPS (Tokens Per Second)** und die Latenz. Er implementiert eine robuste Retry-Logik mit Exponential Backoff, um API-Ausfälle abzufedern.

# 5. Reporting (mdGenerator.js)
Abschließend wandelt dieser Generator die komplexen JSON-Daten der Analyse und des KI-Diskurses in einen professionellen **Markdown-Report** um. Er listet Frameworks (Spring, Quarkus, etc.), Sicherheitsrisiken und Architektur-Metriken übersichtlich auf.

**Zusammenfassend:** Dein System ist kein gewöhnlicher Wrapper. Es ist ein hochgradig spezialisiertes Sicherheitswerkzeug, das **deterministische Code-Analyse** mit **probabilistischer KI-Intelligenz** kombiniert und das Ganze durch kryptografische Ketten absichert.
Ein echtes "High-End" Werkzeug für Entwickler, die verstehen wollen, was unter der Haube passiert.


# User → React Frontend → Orchestrator (Java)
                           ├── Node.js Agents (fileReader, codeAnalyzer, mdGenerator)
                           ├── LLM Client → llama.cpp/Qwen2
                           └── Hash Chain (BLAKE3 integrity)

## Features

- *Deep Semantic Analysis* – Taint flow, memory leaks, side effects, SCC cycles
- *LLM Integration* – Qwen2/Llama models via OpenAI-compatible API
- *4-Persona Security Discourse* – DOMINUS → AXIOM → CIPHER → VECTOR
- *BLAKE3 Hash Chain* – Tamper-proof audit trail of all LLM decisions
- *REST API + React Frontend* – Modern web UI for analysis

## 📋 Prerequisites

- Java 17+
- Node.js (for JS agents)
- llama.cpp server

## 🛠️ Installation

```bash
# Clone
git clone https://github.com/maxxki/maxxki-analyser.git
cd maxxki-analyser

# Verzeichnisse erstellen
mkdir -p hashes exports output

# Compile (KORREKT)
mvn clean package

# Configure
cp config/maxxki.properties.example config/maxxki.properties
# Edit llm.url and other settings

# LLM-Server starten
./build/bin/llama-server \
  -m models/Qwen2-1.5B-Instruct-Q4_K_M.gguf \
  --host 127.0.0.1 --port 8080 -c 2048

# Java starten (KORREKTER JAR-NAME)



# Browser
http://localhost:7070/


# 1. llama.cpp klonen und bauen
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
cmake -B build
cmake --build build --config Release -j$(nproc)

# 2. Server starten (aus dem llama.cpp-Verzeichnis)
./build/bin/llama-server -m models/qwen2-1.5b-instruct-q4_k_m.gguf \
  --host 127.0.0.1 --port 8080 -c 2048


./llama-server \
  -m ~/llama.cpp/models/Qwen2-1.5B-Instruct-Q4_K_M.gguf \
  --host 127.0.0.1 --port 8080 \
  -c 1024 \
  -t 4 \
  -tb 2 \
  --flash-attn on \
  --numa distribute \
  --no-mmap


# Modell herunterladen (falls noch nicht vorhanden):
# Im llama.cpp-Verzeichnis

mkdir -p models
# Von HuggingFace, z.B. mit wget oder huggingface-cli
huggingface-cli download Qwen/Qwen2-1.5B-Instruct-GGUF \
  qwen2-1.5b-instruct-q4_k_m.gguf --local-dir models/

#Dann erst MAXXKI starten:

# Zurück ins MAXXKI-Verzeichnis
cd ~/maxxki-april26/analyserneo
java -jar target/maxxki-analyser-3.1-llm.jar --server 7070

# Quickcheck ob der LLM-Server läuft:
curl http://127.0.0.1:8080/health

# Sollte: {"status":"ok"} zurückgeben


---------
# RICHTIG (mit Fat JAR)
java -jar target/maxxki-3.2-llm.jar --server 7070


--------------

# (mit Fat JAR)
java -jar target/maxxki-3.2-llm.jar --server 7070

----------------------


PersonaDiscourse v2.0 – Security Hardening & Context-Aware Personas

- Added VULN_BRIEFINGS for 9 vulnerability types (SQLi, XSS, PathTraversal, etc.)
- Fixed extractVerdict(): prefix matching + FP keyword blacklist (no more false "REAL")
- Fixed extractConfidence(): removed text-length fallback, only semantic signals
- Fixed BLAKE3 chain input: length-prefixed segments (prevents separator injection)
- Added sanitizeForPrompt(): removes control chars, log injection patterns, limits length
- Added deepAnalyze() overload with lineNumber (backwards compatible)
- All LLM outputs are sanitized before chain.append()
