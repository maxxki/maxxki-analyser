package com.maxxki;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.symbolsolver.JavaSymbolSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * TaintAnalyzer v1.1 – Interprozeduraler Taint-Tracker mit JavaParser
 * ══════════════════════════════════════════════════════════════════════
 *
 * Architektur-Rolle: Präzise Datenfluss-Analyse (Ergänzung zu codeAnalyzer.js)
 *
 * Änderungen gegenüber v1.0:
 *   #1  Thread-safe JavaParser: Kein globaler StaticJavaParser mehr.
 *       buildParserConfig() erzeugt pro analyzeFile()-Aufruf eine eigene
 *       JavaParser-Instanz → sicher für parallele Ausführung im ANALYSIS_POOL.
 *   #9  Duplikat-Unterdrückung in runInterproceduralPass(): Findings die
 *       bereits aus Pass 1 bekannt sind (file|type|line), werden nicht
 *       ein zweites Mal hinzugefügt.
 *
 * Was dieser Analyzer kann:
 *   - Taint Sources erkennen: HTTP-Parameter, Annotationen (@RequestParam etc.)
 *   - Taint-Propagation über Variablen, String-Konkatenation, Methodenketten
 *   - Interprozeduraler Fluss: wenn eine Methode einen Taint-Wert zurückgibt,
 *     wird der Aufrufer ebenfalls als tainted markiert
 *   - Sink-Erkennung mit Kontext (PreparedStatement-Check für SQLi)
 *   - Confidence-Score: JavaParser-basierte Findings haben 0.85+
 *   - Merging mit Regex-Analyse: JavaParser-Findings überschreiben
 *     Regex-Findings bei gleicher Datei+Zeile (Deduplizierung)
 *
 * Bekannte Grenzen:
 *   - Kein vollständiger Call-Graph (max. 2 Ebenen interprozedural)
 *   - Kein Flow durch externe Bibliotheken
 *   - Symbol-Resolver funktioniert nur wenn Source vollständig vorhanden
 *
 * Dependency (pom.xml / build.gradle):
 *   com.github.javaparser:javaparser-symbol-solver-core:3.25.8
 */
public class TaintAnalyzer {

    private static final Logger LOG = Logger.getLogger(TaintAnalyzer.class.getName());

    // ── Taint Sources ────────────────────────────────────────────────────────
    private static final Set<String> SOURCE_METHODS = Set.of(
        "getParameter", "getHeader", "getInputStream", "getReader",
        "getRequestURI", "getQueryString", "getCookies", "getAttribute",
        "getBody", "readLine", "readAllBytes", "readString",
        "getenv", "getProperty"
    );

    private static final Set<String> SOURCE_ANNOTATIONS = Set.of(
        "RequestParam", "PathVariable", "RequestBody", "RequestHeader",
        "QueryParam", "FormParam", "MatrixParam", "CookieParam", "HeaderParam"
    );

    // ── Sinks ────────────────────────────────────────────────────────────────
    private static final Map<String, SinkDescriptor> SINKS;
    static {
        Map<String, SinkDescriptor> m = new LinkedHashMap<>();
        m.put("executeQuery",     new SinkDescriptor("SQL_INJECTION",     "CRITICAL", "Use PreparedStatement with parameterized queries (?)"));
        m.put("executeUpdate",    new SinkDescriptor("SQL_INJECTION",     "CRITICAL", "Use PreparedStatement with parameterized queries (?)"));
        m.put("execute",          new SinkDescriptor("SQL_INJECTION",     "CRITICAL", "Use PreparedStatement; avoid dynamic SQL"));
        m.put("prepareStatement", new SinkDescriptor("SQL_INJECTION",     "HIGH",     "Ensure the SQL string is not dynamically constructed from user input"));
        m.put("createNativeQuery",new SinkDescriptor("SQL_INJECTION",     "CRITICAL", "Use parameterized JPQL or named parameters"));
        m.put("print",            new SinkDescriptor("XSS",               "HIGH",     "Encode output with OWASP Java Encoder before writing to response"));
        m.put("println",          new SinkDescriptor("XSS",               "HIGH",     "Encode output with OWASP Java Encoder before writing to response"));
        m.put("write",            new SinkDescriptor("XSS",               "MEDIUM",   "Encode output; ensure Content-Type is set correctly"));
        m.put("append",           new SinkDescriptor("XSS",               "MEDIUM",   "Encode output before appending to response writer"));
        m.put("get",              new SinkDescriptor("PATH_TRAVERSAL",    "HIGH",     "Validate and normalize paths; restrict to allowed base directory"));
        m.put("exec",             new SinkDescriptor("COMMAND_INJECTION", "CRITICAL", "Never pass user input to Runtime.exec(); use whitelist or ProcessBuilder with array args"));
        m.put("search",           new SinkDescriptor("LDAP_INJECTION",    "HIGH",     "Escape LDAP special characters; use parameterized LDAP queries"));
        SINKS = Collections.unmodifiableMap(m);
    }

    // ── Object-Creation Sinks ─────────────────────────────────────────────────
    private static final Map<String, SinkDescriptor> CREATION_SINKS;
    static {
        Map<String, SinkDescriptor> m = new LinkedHashMap<>();
        m.put("File",          new SinkDescriptor("PATH_TRAVERSAL",    "HIGH",     "Validate and canonicalize path; restrict to allowed directories"));
        m.put("ProcessBuilder",new SinkDescriptor("COMMAND_INJECTION", "CRITICAL", "Never construct ProcessBuilder args from user input"));
        CREATION_SINKS = Collections.unmodifiableMap(m);
    }

    // ── State ─────────────────────────────────────────────────────────────────
    private final ConcurrentMap<String, List<TaintFinding>> findingsByFile   = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, Boolean>            taintedReturnMethods = new ConcurrentHashMap<>();
    private final ConcurrentMap<String, CompilationUnit>    parsedCUs        = new ConcurrentHashMap<>();

    private final Path         sourceRoot;
    private final ObjectMapper mapper = new ObjectMapper();

    // ── Constructor ───────────────────────────────────────────────────────────

    public TaintAnalyzer(Path sourceRoot) {
        this.sourceRoot = sourceRoot;
        // FIX #1: Kein globaler StaticJavaParser mehr – buildParserConfig() erzeugt
        // pro Thread eine eigene Instanz. configureParser() wurde entfernt.
    }

    /**
     * FIX #1: Erzeugt eine frische ParserConfiguration pro analyzeFile()-Aufruf.
     * JavaParser's StaticJavaParser ist nicht thread-safe; durch Verwendung einer
     * eigenen JavaParser-Instanz pro Thread wird das Race-Condition-Problem beseitigt.
     */
    private ParserConfiguration buildParserConfig() {
        try {
            CombinedTypeSolver solver = new CombinedTypeSolver();
            solver.add(new ReflectionTypeSolver(false));
            if (Files.isDirectory(sourceRoot)) {
                solver.add(new JavaParserTypeSolver(sourceRoot.toFile()));
            }
            return new ParserConfiguration()
                .setSymbolResolver(new JavaSymbolSolver(solver))
                .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_17);
        } catch (Exception e) {
            LOG.warning("[TaintAnalyzer] Symbol solver init failed, running without type resolution: " + e.getMessage());
            return new ParserConfiguration()
                .setLanguageLevel(ParserConfiguration.LanguageLevel.JAVA_17);
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Analysiert eine einzelne Java-Datei.
     * Thread-safe – FIX #1: Eigene JavaParser-Instanz statt StaticJavaParser.
     *
     * @param filePath Absoluter Pfad zur .java-Datei
     * @return Liste der gefundenen Taint-Findings (leer wenn keine)
     */
    public List<TaintFinding> analyzeFile(Path filePath) {
        try {
            // FIX #1: Eigene JavaParser-Instanz pro Thread – kein geteilter Zustand
            JavaParser parser = new JavaParser(buildParserConfig());
            ParseResult<CompilationUnit> parseResult = parser.parse(filePath);

            if (!parseResult.isSuccessful() || parseResult.getResult().isEmpty()) {
                LOG.fine("[TaintAnalyzer] Parse failed: " + filePath.getFileName());
                return List.of();
            }

            CompilationUnit cu = parseResult.getResult().get();
            parsedCUs.put(filePath.toString(), cu);

            List<TaintFinding> fileFindings = new ArrayList<>();

            for (MethodDeclaration method : cu.findAll(MethodDeclaration.class)) {
                TaintContext ctx = buildTaintContext(method);
                if (!ctx.hasTaint()) continue;
                fileFindings.addAll(findSinks(method, ctx, filePath));
                trackTaintedReturn(cu, method, ctx);
            }

            findingsByFile.put(filePath.toString(), fileFindings);
            return fileFindings;

        } catch (Exception e) {
            LOG.fine("[TaintAnalyzer] Skipping " + filePath.getFileName() + ": " + e.getMessage());
            return List.of();
        }
    }

    /**
     * Pass 2 – Interprozeduraler Taint-Fluss.
     * Muss NACH analyzeFile() für alle Dateien aufgerufen werden.
     *
     * FIX #9: Deduplizierung – Findings die bereits aus Pass 1 bekannt sind
     * (gleiche file|type|lineNumber), werden nicht erneut hinzugefügt.
     */
    public void runInterproceduralPass(List<Path> allFiles) {
        for (Map.Entry<String, CompilationUnit> entry : parsedCUs.entrySet()) {
            Path            filePath = Paths.get(entry.getKey());
            CompilationUnit cu       = entry.getValue();

            for (MethodDeclaration method : cu.findAll(MethodDeclaration.class)) {
                TaintContext ctx = buildTaintContext(method);

                method.findAll(MethodCallExpr.class).forEach(call -> {
                    String key = buildMethodKey(call);
                    if (key != null && taintedReturnMethods.getOrDefault(key, false)) {
                        extractAssignedVarName(call).ifPresent(ctx::addTainted);
                    }
                });

                if (!ctx.hasTaint()) continue;

                List<TaintFinding> extras = findSinks(method, ctx, filePath);
                if (extras.isEmpty()) continue;

                // FIX #9: Nur neue Findings hinzufügen (kein Duplikat file|type|line)
                List<TaintFinding> existing =
                    findingsByFile.computeIfAbsent(entry.getKey(), k -> new ArrayList<>());
                for (TaintFinding extra : extras) {
                    if (!isDuplicate(existing, extra)) {
                        existing.add(extra);
                    }
                }
            }
        }
    }

    /**
     * Merged JavaParser-Findings mit Regex-Analyse-Output von codeAnalyzer.js.
     */
    public String mergeWithRegexAnalysis(String regexAnalysisJson) throws Exception {
        JsonNode regexRoot  = mapper.readTree(regexAnalysisJson);
        JsonNode regexVulns = regexRoot.path("security").path("vulnerabilities");

        List<TaintFinding> javaParserFindings = findingsByFile.values().stream()
            .flatMap(Collection::stream)
            .collect(Collectors.toList());

        Map<String, TaintFinding> jpIndex = new HashMap<>();
        for (TaintFinding f : javaParserFindings) {
            String key = f.file() + "|" + f.type();
            jpIndex.merge(key, f, (a, b) -> a.confidence() >= b.confidence() ? a : b);
        }

        ArrayNode merged = mapper.createArrayNode();

        for (JsonNode rv : regexVulns) {
            String file = rv.path("file").asText("");
            String type = rv.path("type").asText("");
            String key  = file + "|" + type;

            if (jpIndex.containsKey(key)) {
                merged.add(taintFindingToJson(jpIndex.get(key), "JavaParser"));
                jpIndex.remove(key);
            } else {
                ObjectNode rv2 = (ObjectNode) rv.deepCopy();
                rv2.put("source", "Regex");
                if (!rv2.has("confidence")) rv2.put("confidence", 0.65);
                merged.add(rv2);
            }
        }

        for (TaintFinding f : jpIndex.values()) {
            merged.add(taintFindingToJson(f, "JavaParser"));
        }

        List<JsonNode> sortedList = new ArrayList<>();
        merged.forEach(sortedList::add);
        sortedList.sort(Comparator.comparingInt(n -> severityOrder(n.path("severity").asText())));

        ArrayNode sortedArray = mapper.createArrayNode();
        sortedList.forEach(sortedArray::add);

        long critCount = sortedList.stream().filter(n -> "CRITICAL".equals(n.path("severity").asText())).count();
        long highCount  = sortedList.stream().filter(n -> "HIGH".equals(n.path("severity").asText())).count();
        long jpCount    = sortedList.stream().filter(n -> "JavaParser".equals(n.path("source").asText())).count();
        long rxCount    = sortedList.size() - jpCount;

        ObjectNode summary = mapper.createObjectNode();
        summary.put("totalVulnerabilities",    sortedList.size());
        summary.put("critical",                (int) critCount);
        summary.put("high",                    (int) highCount);
        summary.put("fromJavaParser",          (int) jpCount);
        summary.put("fromRegex",               (int) rxCount);
        summary.put("interproceduralMethods",  taintedReturnMethods.size());

        ObjectNode result = mapper.createObjectNode();
        result.set("vulnerabilities", sortedArray);
        result.set("summary", summary);

        return mapper.writeValueAsString(result);
    }

    /**
     * Gibt alle Findings als JSON-String zurück (ohne Merging).
     */
    public String getAllFindingsJson() throws Exception {
        List<TaintFinding> all = findingsByFile.values().stream()
            .flatMap(Collection::stream)
            .collect(Collectors.toList());

        ArrayNode arr = mapper.createArrayNode();
        for (TaintFinding f : all) arr.add(taintFindingToJson(f, "JavaParser"));
        return mapper.writeValueAsString(arr);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL – DUPLICATE CHECK (FIX #9)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * FIX #9: Prüft ob ein Finding bereits in der Liste vorhanden ist.
     * Schlüssel: file + type + lineNumber (dreistellige Identität).
     */
    private boolean isDuplicate(List<TaintFinding> existing, TaintFinding candidate) {
        return existing.stream().anyMatch(f ->
            f.file().equals(candidate.file()) &&
            f.type().equals(candidate.type()) &&
            f.lineNumber() == candidate.lineNumber()
        );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL – TAINT CONTEXT
    // ══════════════════════════════════════════════════════════════════════════

    private TaintContext buildTaintContext(MethodDeclaration method) {
        TaintContext ctx = new TaintContext();

        for (Parameter param : method.getParameters()) {
            for (String anno : SOURCE_ANNOTATIONS) {
                if (param.getAnnotationByName(anno).isPresent()) {
                    ctx.addTainted(param.getNameAsString());
                    break;
                }
            }
        }

        method.findAll(VariableDeclarator.class).forEach(vd -> {
            vd.getInitializer().ifPresent(init -> {
                if (isSourceExpression(init)) {
                    ctx.addTainted(vd.getNameAsString());
                }
            });
        });

        method.findAll(AssignExpr.class).forEach(ae -> {
            if (isSourceExpression(ae.getValue())) {
                if (ae.getTarget().isNameExpr()) {
                    ctx.addTainted(ae.getTarget().asNameExpr().getNameAsString());
                }
            }
        });

        return ctx;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL – SOURCE DETECTION
    // ══════════════════════════════════════════════════════════════════════════

    private boolean isSourceExpression(Expression expr) {
        if (expr.isMethodCallExpr()) {
            MethodCallExpr call = expr.asMethodCallExpr();
            if (SOURCE_METHODS.contains(call.getNameAsString())) return true;
            if (call.getScope().isPresent() && isSourceExpression(call.getScope().get())) return true;
        }
        if (expr.isEnclosedExpr()) return isSourceExpression(expr.asEnclosedExpr().getInner());
        if (expr.isCastExpr())     return isSourceExpression(expr.asCastExpr().getExpression());
        return false;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL – TAINT PROPAGATION
    // ══════════════════════════════════════════════════════════════════════════

    private boolean isTainted(Expression expr, TaintContext ctx) {
        if (expr == null) return false;

        if (expr.isNameExpr()) {
            return ctx.isTainted(expr.asNameExpr().getNameAsString());
        }

        if (expr.isBinaryExpr()) {
            BinaryExpr bin = expr.asBinaryExpr();
            if (bin.getOperator() == BinaryExpr.Operator.PLUS) {
                return isTainted(bin.getLeft(), ctx) || isTainted(bin.getRight(), ctx);
            }
        }

        if (expr.isMethodCallExpr()) {
            MethodCallExpr call = expr.asMethodCallExpr();
            String name = call.getNameAsString();

            if ("format".equals(name)) {
                return call.getArguments().stream().skip(1).anyMatch(a -> isTainted(a, ctx));
            }
            if (Set.of("trim", "strip", "toLowerCase", "toUpperCase", "replace",
                        "replaceAll", "substring", "concat", "toString").contains(name)) {
                return call.getScope().map(s -> isTainted(s, ctx)).orElse(false) ||
                       call.getArguments().stream().anyMatch(a -> isTainted(a, ctx));
            }
            if (isSourceExpression(call)) return true;
            if (call.getScope().map(s -> isTainted(s, ctx)).orElse(false)) return true;
        }

        if (expr.isConditionalExpr()) {
            ConditionalExpr ce = expr.asConditionalExpr();
            return isTainted(ce.getThenExpr(), ctx) || isTainted(ce.getElseExpr(), ctx);
        }

        if (expr.isCastExpr())      return isTainted(expr.asCastExpr().getExpression(), ctx);
        if (expr.isEnclosedExpr())  return isTainted(expr.asEnclosedExpr().getInner(), ctx);

        if (expr.isArrayAccessExpr()) {
            ArrayAccessExpr aae = expr.asArrayAccessExpr();
            return ctx.isTainted(aae.getName().toString());
        }

        return false;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL – SINK DETECTION
    // ══════════════════════════════════════════════════════════════════════════

    private List<TaintFinding> findSinks(MethodDeclaration method, TaintContext ctx, Path filePath) {
        List<TaintFinding> results = new ArrayList<>();

        method.findAll(MethodCallExpr.class).forEach(call -> {
            String         name = call.getNameAsString();
            SinkDescriptor sink = SINKS.get(name);
            if (sink == null) return;

            if ("get".equals(name)) {
                boolean isPathsGet = call.getScope()
                    .map(s -> "Paths".equals(s.toString()))
                    .orElse(false);
                if (!isPathsGet) return;
            }

            boolean hasTaintedArg = call.getArguments().stream()
                .anyMatch(arg -> isTainted(arg, ctx));
            if (!hasTaintedArg) return;

            if ("SQL_INJECTION".equals(sink.type())) {
                boolean hasPrepared = methodContainsPreparedPattern(method, call);
                if (hasPrepared) {
                    results.add(buildFinding(sink, call, filePath, 0.5,
                        "Possible false positive: PreparedStatement detected nearby. Verify parameterization."));
                    return;
                }
            }

            results.add(buildFinding(sink, call, filePath, 0.88, sink.recommendation()));
        });

        method.findAll(ObjectCreationExpr.class).forEach(oc -> {
            String         typeName = oc.getType().getNameAsString();
            SinkDescriptor sink     = CREATION_SINKS.get(typeName);
            if (sink == null) return;

            boolean hasTaintedArg = oc.getArguments().stream()
                .anyMatch(arg -> isTainted(arg, ctx));
            if (!hasTaintedArg) return;

            int line = oc.getRange().map(r -> r.begin.line).orElse(0);
            results.add(new TaintFinding(
                sink.type(), sink.severity(),
                filePath.toString(), line,
                "new " + typeName + "(" + oc.getArguments() + ")",
                sink.recommendation(), 0.87
            ));
        });

        return results;
    }

    private boolean methodContainsPreparedPattern(MethodDeclaration method, MethodCallExpr sinkCall) {
        return method.findAll(MethodCallExpr.class).stream()
            .filter(c -> "prepareStatement".equals(c.getNameAsString()))
            .anyMatch(c -> c.getArguments().stream()
                .anyMatch(arg -> arg.isStringLiteralExpr() &&
                    arg.asStringLiteralExpr().asString().contains("?")));
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL – INTERPROCEDURAL HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private void trackTaintedReturn(CompilationUnit cu, MethodDeclaration method, TaintContext ctx) {
        boolean returnsTaint = method.findAll(ReturnStmt.class).stream()
            .anyMatch(ret -> ret.getExpression().map(e -> isTainted(e, ctx)).orElse(false));

        if (returnsTaint) {
            String className = cu.getPrimaryTypeName().orElse("Unknown");
            String key       = className + "#" + method.getNameAsString();
            taintedReturnMethods.put(key, true);
        }
    }

    private String buildMethodKey(MethodCallExpr call) {
        return call.getScope()
            .map(s -> s.toString() + "#" + call.getNameAsString())
            .orElse(null);
    }

    private Optional<String> extractAssignedVarName(MethodCallExpr call) {
        return call.getParentNode()
            .filter(p -> p instanceof VariableDeclarator)
            .map(p -> ((VariableDeclarator) p).getNameAsString());
    }

    // ══════════════════════════════════════════════════════════════════════════
    // INTERNAL – HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private TaintFinding buildFinding(SinkDescriptor sink, MethodCallExpr call,
                                      Path filePath, double confidence, String recommendation) {
        int    line = call.getRange().map(r -> r.begin.line).orElse(0);
        String code = call.toString();
        if (code.length() > 120) code = code.substring(0, 120) + "…";
        return new TaintFinding(
            sink.type(), sink.severity(),
            filePath.toString(), line,
            code, recommendation, confidence
        );
    }

    private ObjectNode taintFindingToJson(TaintFinding f, String source) {
        ObjectNode n = mapper.createObjectNode();
        n.put("type",           f.type());
        n.put("severity",       f.severity());
        n.put("file",           f.file());
        n.put("lineNumber",     f.lineNumber());
        n.put("code",           f.code());
        n.put("recommendation", f.recommendation());
        n.put("confidence",     f.confidence());
        n.put("source",         source);
        return n;
    }

    private int severityOrder(String severity) {
        return switch (severity) {
            case "CRITICAL" -> 0;
            case "HIGH"     -> 1;
            case "MEDIUM"   -> 2;
            case "LOW"      -> 3;
            default         -> 4;
        };
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DATA CLASSES
    // ══════════════════════════════════════════════════════════════════════════

    private static class TaintContext {
        private final Set<String> taintedVars = new HashSet<>();

        void    addTainted(String varName) { taintedVars.add(varName); }
        boolean isTainted(String varName)  { return taintedVars.contains(varName); }
        boolean hasTaint()                 { return !taintedVars.isEmpty(); }

        @Override
        public String toString() { return "TaintCtx" + taintedVars; }
    }

    private record SinkDescriptor(String type, String severity, String recommendation) {}

    public record TaintFinding(
        String type,
        String severity,
        String file,
        int    lineNumber,
        String code,
        String recommendation,
        double confidence
    ) {}
}
