#!/usr/bin/env node
/**
 * fileReader.js
 * Reads the target path from stdin (first line = path string, or raw path arg).
 * Returns JSON array of { name, path, relative, size, ext }.
 * READ-ONLY: write operations are blocked.
 *
 * Security Fixes (review.md #2 / #3):
 *   #2  Path Traversal: Root-Binding – targetArg muss innerhalb des
 *       erlaubten Wurzelpfads liegen. Traversal via ../ wird abgewiesen.
 *   #3  Symlink-Schutz: fs.realpathSync() vor stat() – symbolische Links
 *       auf Dateien außerhalb des Root werden erkannt und übersprungen.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

// ── Read-only protection ─────────────────────────────────────────────────────
fs.writeFileSync = fs.writeFile = fs.appendFileSync = fs.appendFile =
fs.unlinkSync    = fs.unlink    = fs.rmdirSync      = fs.rmdir      =
fs.mkdirSync     = fs.mkdir     = () => { process.exit(99); };

// ── Collect stdin ────────────────────────────────────────────────────────────
let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => { inputBuf += chunk; });
process.stdin.on('end', () => {
    const targetArg = inputBuf.trim() || process.argv[2] || '.';

    // FIX (review.md #2): Root-Binding
    // Der erlaubte Wurzelpfad = CWD des Orchestrator-Prozesses.
    // Dateien außerhalb davon werden prinzipiell abgewiesen.
    const allowedRoot = path.resolve('.');
    const root        = path.resolve(targetArg);

    if (!root.startsWith(allowedRoot)) {
        process.stderr.write('Access denied: path outside allowed root: ' + root + '\n');
        process.exit(1);
    }

    if (!fs.existsSync(root)) {
        process.stderr.write('Directory not found: ' + root + '\n');
        process.exit(1);
    }

    try {
        const files = walk(root, root, allowedRoot);
        process.stdout.write(JSON.stringify(files, null, 0) + '\n');
    } catch (e) {
        process.stderr.write(e.message + '\n');
        process.exit(1);
    }
});

function walk(dir, root, allowedRoot) {
    let results = [];

    let entries;
    try {
        entries = fs.readdirSync(dir);
    } catch (e) {
        // Verzeichnis nicht lesbar (Permission) → überspringen
        return results;
    }

    for (const entry of entries) {
        if (entry.startsWith('.') ||
            entry === 'node_modules' || entry === 'build' ||
            entry === 'bin' || entry === 'out') continue;

        const full = path.join(dir, entry);

        // FIX (review.md #3): Symlink-Schutz
        // Erst lstat() prüfen ob es ein Symlink ist.
        // Wenn ja: realpathSync() berechnen und prüfen ob Ziel innerhalb des Roots liegt.
        let stat;
        try { stat = fs.lstatSync(full); } catch { continue; }

        if (stat.isSymbolicLink()) {
            let realTarget;
            try {
                realTarget = fs.realpathSync(full);
            } catch {
                // Broken symlink → überspringen
                continue;
            }
            if (!realTarget.startsWith(allowedRoot)) {
                // Symlink zeigt aus dem erlaubten Bereich heraus → überspringen
                process.stderr.write('[WARN] Skipping symlink outside root: ' + full + ' → ' + realTarget + '\n');
                continue;
            }
            // Symlink ist erlaubt → stat des Ziels für weitere Verarbeitung
            try { stat = fs.statSync(full); } catch { continue; }
        }

        if (stat.isDirectory()) {
            results = results.concat(walk(full, root, allowedRoot));
        } else if (path.extname(entry).toLowerCase() === '.java') {
            results.push({
                name:     entry,
                path:     full,
                relative: path.relative(root, full),
                size:     stat.size,
                ext:      '.java'
            });
        }
    }
    return results;
}
