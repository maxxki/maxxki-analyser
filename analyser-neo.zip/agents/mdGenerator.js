#!/usr/bin/env node
/**
 * mdGenerator.js  ─  MAXXKI SEMANTIC REPORT GENERATOR  v3.1
 *
 * Security Fix (review.md #4 / Teil 2 #4):
 *   HTML Injection in Markdown: Vorher wurde nur | escaped.
 *   <, >, &, " wurden nicht escaped – ein Angreifer konnte über
 *   manipulierte Java-Kommentare (TODO <script>alert()</script>)
 *   HTML in den Markdown-Report injizieren.
 *
 *   Fix: escapeMarkdown() escaped alle HTML-relevanten Zeichen
 *   und | für Tabellen-Syntax.
 */

'use strict';
const fs = require('fs');
fs.writeFileSync = fs.writeFile = () => { process.exit(99); };

let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', c => { inputBuf += c; });
process.stdin.on('end', () => {
  let payload, analysis;
  try {
    payload  = JSON.parse(inputBuf.trim());
    analysis = typeof payload.analysis === 'string' ? JSON.parse(payload.analysis) : payload.analysis;
  } catch (e) {
    // FIX: Kein Fehlerinhalt in stderr (Information Leakage)
    process.stderr.write('Invalid input\n');
    process.exit(1);
  }

  const s   = analysis.summary  || {};
  const sem = analysis.semanticSummary || {};
  const date    = new Date(payload.date).toLocaleString('de-DE');
  const project = payload.project || '(unknown)';

  let md = '';

  md += `# MAXXKI Deep Semantic Analysis Report\n\n`;
  md += `| | |\n|---|---|\n`;
  md += `| **Project** | \`${escapeMarkdown(project)}\` |\n`;
  md += `| **Analysed** | ${escapeMarkdown(date)} |\n`;
  md += `| **Engine** | MAXXKI Deep Semantic Analyser v3.1 |\n`;
  md += `| **Java Version Detected** | Java ${sem.detectedJavaVersion || '?'} |\n`;
  md += `| **Dominant Domain** | ${escapeMarkdown(sem.dominantDomain || 'UNKNOWN')} |\n`;
  md += `| **Overall Risk** | **${escapeMarkdown(sem.overallRisk || '?')}** |\n\n`;
  md += `---\n\n`;

  md += `## Executive Summary\n\n`;
  md += `| Metric | Value |\n|---|---:|\n`;
  md += `| Java Files | ${s.totalFiles || 0} |\n`;
  md += `| Total Size | ${s.totalSizeKB || 0} KB |\n`;
  md += `| Total Lines | ${s.totalLines || 0} |\n`;
  md += `| Code / Comment / Blank | ${s.codeLines||0} / ${s.commentLines||0} / ${s.blankLines||0} |\n`;
  md += `| Classes / Methods / Fields | ${s.totalClasses||0} / ${s.totalMethods||0} / ${s.totalFields||0} |\n`;
  md += `| Java Version (detected) | **${sem.detectedJavaVersion || 1}** |\n`;
  md += `| **Security Vulnerabilities** | **${sem.totalVulnerabilities||0}** (${sem.criticalVulnerabilities||0} CRITICAL) |\n`;
  md += `| **Memory Leaks Detected** | **${sem.totalMemoryLeaks||0}** (${sem.criticalMemoryLeaks||0} CRITICAL) |\n`;
  md += `| **Files: DO NOT TOUCH** | **${sem.filesDoNotTouch||0}** |\n`;
  md += `| **Files: Safe to Refactor** | **${sem.filesSafeToRefactor||0}** |\n`;
  md += `| Broadcast-Critical Files | ${sem.broadcastCriticalFiles||0} |\n`;
  md += `| Package Dependency Cycles (SCC) | ${sem.packageCycles||0} |\n`;
  md += `| Class Dependency Cycles (SCC) | ${sem.classCycles||0} |\n\n`;

  const commentRatio = s.totalLines ? ((s.commentLines / s.totalLines) * 100).toFixed(1) : 0;
  md += `> **Comment ratio:** ${commentRatio}%  |  **Overall risk:** ${escapeMarkdown(sem.overallRisk || '?')}\n\n`;
  md += `---\n\n`;

  md += `## 1. Domain Context Map\n\n`;
  const domainMap  = analysis.domainMap || {};
  const riskColors = { HARDWARE:'🔴', COMPLIANCE:'🔴', REALTIME:'🟠', SERVER:'🟠', DATA_ACCESS:'🟡', CORE:'🟡', API:'🟢', MODEL:'🟢', UTIL:' 🟢', UNKNOWN:'⚪' };
  const strategies = { HARDWARE:'DO_NOT_TOUCH', COMPLIANCE:'DO_NOT_TOUCH', REALTIME:'ANALYZE_ONLY', SERVER:'ANALYZE_ONLY', DATA_ACCESS:'SAFE_TRANSFORM', CORE:'SAFE_TRANSFORM', API:'SAFE_TRANSFORM', MODEL:'MICROSERVICE_WRAP', UTIL:'MICROSERVICE_WRAP', UNKNOWN:'ANALYZE_ONLY' };

  if (Object.keys(domainMap).length > 0) {
    md += `| Context | Files | Risk | Strategy |\n|---|---:|---|---|\n`;
    const contextPriority = ['HARDWARE','COMPLIANCE','REALTIME','SERVER','DATA_ACCESS','CORE','API','MODEL','UTIL','UNKNOWN'];
    for (const ctx of contextPriority) {
      if (!domainMap[ctx] || domainMap[ctx].length === 0) continue;
      md += `| ${riskColors[ctx]||'⚪'} **${escapeMarkdown(ctx)}** | ${domainMap[ctx].length} | ${getRisk(ctx)} | \`${strategies[ctx]||'ANALYZE_ONLY'}\` |\n`;
    }
    md += '\n';

    for (const ctx of contextPriority) {
      if (!domainMap[ctx] || domainMap[ctx].length === 0) continue;
      md += `<details>\n<summary>${riskColors[ctx]||''} <strong>${escapeMarkdown(ctx)}</strong> – ${domainMap[ctx].length} file(s)</summary>\n\n`;
      for (const f of domainMap[ctx].sort()) md += `- \`${escapeMarkdown(f)}\`\n`;
      md += `\n</details>\n\n`;
    }
  } else {
    md += '_No domain context detected._\n\n';
  }
  md += `---\n\n`;

  md += `## 2. Refactoring Risk Assessment\n\n`;
  const refMap = analysis.refactoringMap || {};
  const byStrategy = { DO_NOT_TOUCH: [], ANALYZE_ONLY: [], SAFE_TRANSFORM: [], MICROSERVICE_WRAP: [] };
  for (const [file, risk] of Object.entries(refMap)) {
    if (byStrategy[risk.strategy]) byStrategy[risk.strategy].push({ file, ...risk });
  }

  for (const [strat, items] of Object.entries(byStrategy)) {
    if (items.length === 0) continue;
    const icon = strat === 'DO_NOT_TOUCH' ? '🚫' : strat === 'ANALYZE_ONLY' ? '⚠️' : strat === 'SAFE_TRANSFORM' ? '✅' : '🔄';
    md += `### ${icon} ${strat} (${items.length} files)\n\n`;
    md += `| File | Risk Score | Risk Level |\n|---|---:|---|\n`;
    for (const item of items.sort((a, b) => b.score - a.score).slice(0, 20)) {
      md += `| \`${escapeMarkdown(item.file)}\` | ${item.score} | ${escapeMarkdown(item.riskLevel)} |\n`;
    }
    md += '\n';
  }
  md += `---\n\n`;

  md += `## 3. Security Vulnerabilities (Taint Flow Analysis)\n\n`;
  const vulns = (analysis.security || {}).vulnerabilities || [];
  if (vulns.length > 0) {
    md += `> ⚠️ **${vulns.length} vulnerability/ies detected** (${vulns.filter(v=>v.severity==='CRITICAL').length} CRITICAL)\n\n`;
    md += `| File | Type | Severity | Line | Recommendation |\n|---|---|---|---:|---|\n`;
    for (const v of vulns.sort((a,b) => severityOrd(b.severity) - severityOrd(a.severity))) {
      md += `| \`${escapeMarkdown(v.file)}\` | \`${escapeMarkdown(v.type)}\` | **${escapeMarkdown(v.severity)}** | ${v.lineNumber} | ${escapeMarkdown(v.recommendation)} |\n`;
    }
  } else {
    md += `_No taint-flow vulnerabilities detected._ ✅\n`;
  }
  md += `\n---\n\n`;

  md += `## 4. Memory Leak Detection\n\n`;
  const leaks = analysis.memoryLeaks || [];
  if (leaks.length > 0) {
    md += `> ⚠️ **${leaks.length} potential memory leak(s)** (${leaks.filter(l=>l.severity==='CRITICAL').length} CRITICAL)\n\n`;
    md += `| File | Type | Severity | Line | Recommendation |\n|---|---|---|---:|---|\n`;
    for (const l of leaks.sort((a,b) => severityOrd(b.severity) - severityOrd(a.severity)).slice(0, 30)) {
      md += `| \`${escapeMarkdown(l.location)}\` | \`${escapeMarkdown(l.type)}\` | **${escapeMarkdown(l.severity)}** | ${l.lineNumber} | ${escapeMarkdown(l.recommendation)} |\n`;
    }
  } else {
    md += `_No memory leaks detected._ ✅\n`;
  }
  md += `\n---\n\n`;

  md += `## 5. Coupling Analysis (Tarjan SCC)\n\n`;
  const scc = analysis.scc || {};
  if ((scc.packageCycles||[]).length > 0 || (scc.classCycles||[]).length > 0) {
    md += `> ⚠️ **Circular dependencies detected** – refactoring these packages is HIGH RISK\n\n`;
    if ((scc.packageCycles||[]).length > 0) {
      md += `### Package-Level Cycles (${scc.packageCycles.length})\n\n`;
      for (const cycle of scc.packageCycles) {
        md += `- \`${escapeMarkdown(cycle.join(' ↔ '))}\`\n`;
      }
      md += '\n';
    }
    if ((scc.classCycles||[]).length > 0) {
      md += `### Class-Level Cycles (${scc.classCycles.length})\n\n`;
      for (const cycle of scc.classCycles.slice(0, 20)) {
        md += `- \`${escapeMarkdown(cycle.join(' ↔ '))}\`\n`;
      }
      md += '\n';
    }
  } else {
    md += `_No circular dependencies detected._ ✅\n\n`;
  }
  md += `---\n\n`;

  md += `## 6. Side Effect Analysis\n\n`;
  const sideEffectFiles = (analysis.files || []).filter(f => f.sideEffects && f.sideEffects.severity !== 'NONE');
  if (sideEffectFiles.length > 0) {
    md += `| File | Severity | Risk Score | IO | Threads | DB | Buffer | Broadcast |\n|---|---|---:|---:|---:|---:|---:|---:|\n`;
    for (const f of sideEffectFiles.sort((a,b) => (b.sideEffects.riskScore||0) - (a.sideEffects.riskScore||0)).slice(0,30)) {
      const se = f.sideEffects;
      md += `| \`${escapeMarkdown(f.relative)}\` | **${escapeMarkdown(se.severity)}** | ${se.riskScore} | ${se.ioOperations?.length||0} | ${se.threadOperations?.length||0} | ${se.dbAccess?.length||0} | ${se.bufferOverflowRisks?.length||0} | ${se.broadcastSpecific?.length||0} |\n`;
    }
    md += '\n';
  } else {
    md += `_No significant side effects detected._ ✅\n\n`;
  }
  md += `---\n\n`;

  md += `## 7. Legacy Code Analysis\n\n`;
  const legacyIssues = analysis.legacyIssues || [];
  if (legacyIssues.length > 0) {
    md += `| File | Issues | High Risk | Safe to Transform |\n|---|---:|---|---|\n`;
    for (const li of legacyIssues.sort((a,b) => b.totalCount - a.totalCount).slice(0,20)) {
      md += `| \`${escapeMarkdown(li.file)}\` | ${li.totalCount} | ${li.hasHighRisk ? '⚠️ Yes' : 'No'} | ${li.safeToTransform ? '✅ Yes' : '❌ No'} |\n`;
    }
    md += '\n';

    const byType = {};
    for (const li of legacyIssues) {
      for (const issue of (li.issues||[])) {
        if (!byType[issue.type]) byType[issue.type] = { count: 0, files: [], recommendation: issue.recommendation };
        byType[issue.type].count += issue.count;
        byType[issue.type].files.push(li.file);
      }
    }
    md += `### Legacy Issue Types\n\n`;
    md += `| Type | Count | Recommendation |\n|---|---:|---|\n`;
    for (const [type, data] of Object.entries(byType).sort((a,b) => b[1].count - a[1].count)) {
      md += `| \`${escapeMarkdown(type)}\` | ${data.count} | ${escapeMarkdown(data.recommendation)} |\n`;
    }
    md += '\n';
  } else {
    md += `_No legacy issues detected._ ✅\n\n`;
  }
  md += `---\n\n`;

  md += `## 8. Broadcast-Critical Files\n\n`;
  const bcFiles = analysis.broadcastFiles || [];
  if (bcFiles.length > 0) {
    md += `> 🔴 These files contain broadcast-specific patterns (RS422, Timecode, Playout, GPI, SDI etc.)\n> **DO NOT TOUCH without broadcast engineering team review.**\n\n`;
    md += `| File |\n|---|\n`;
    for (const bf of bcFiles.sort()) md += `| \`${escapeMarkdown(bf)}\` |\n`;
    md += '\n';
  } else {
    md += `_No broadcast-specific patterns detected._\n\n`;
  }
  md += `---\n\n`;

  md += `## 9. Package Structure\n\n`;
  const pkgs = analysis.packages || {};
  if (Object.keys(pkgs).length) {
    md += `| Package | Files |\n|---|---:|\n`;
    for (const [pkg, files] of Object.entries(pkgs).sort()) md += `| \`${escapeMarkdown(pkg)}\` | ${files.length} |\n`;
    md += '\n';
    for (const [pkg, files] of Object.entries(pkgs).sort()) {
      md += `<details>\n<summary><code>${escapeMarkdown(pkg)}</code> – ${files.length} file(s)</summary>\n\n`;
      for (const f of files.sort()) md += `- \`${escapeMarkdown(f)}\`\n`;
      md += `\n</details>\n\n`;
    }
  } else { md += '_No packages detected._\n\n'; }
  md += `---\n\n`;

  md += `## 10. Class / Interface / Enum Inventory\n\n`;
  const fileList = analysis.files || [];
  if (fileList.length) {
    md += `| File | Domain | Classes | Methods | Fields | Lines | Risk |\n|---|---|---:|---:|---:|---:|---|\n`;
    for (const f of fileList.sort((a,b)=>a.relative.localeCompare(b.relative))) {
      const classNames = f.classes.length ? escapeMarkdown(f.classes.join(', ')) : '—';
      md += `| \`${escapeMarkdown(f.relative)}\` | \`${escapeMarkdown(f.domain||'?')}\` | ${classNames} | ${f.methods.length} | ${f.fields} | ${f.lines} | ${escapeMarkdown(f.refactoringRisk?.riskLevel||'?')} |\n`;
    }
    md += '\n';
  }
  md += `---\n\n`;

  md += `## 11. Most Complex Files (by method count)\n\n`;
  const top = (analysis.topMethods||[]).filter(f=>f.methods.length>0);
  if (top.length) {
    md += `| Rank | File | Domain | Methods | Lines | Risk |\n|---:|---|---|---:|---:|---|\n`;
    top.forEach((f,i) => md += `| ${i+1} | \`${escapeMarkdown(f.relative)}\` | \`${escapeMarkdown(f.domain||'?')}\` | ${f.methods.length} | ${f.lines} | ${escapeMarkdown(f.refactoringRisk?.riskLevel||'?')} |\n`);
    md += '\n';
  } else { md += '_No methods found._\n\n'; }
  md += `---\n\n`;

  md += `## 12. Annotations & Frameworks\n\n`;
  const annos = analysis.annotations || {};
  const annoEntries = Object.entries(annos).sort((a,b)=>b[1]-a[1]);
  if (annoEntries.length) {
    md += `| Annotation | Count |\n|---|---:|\n`;
    for (const [k,v] of annoEntries) md += `| \`@${escapeMarkdown(k)}\` | ${v} |\n`;
    md += '\n';
  } else { md += '_No annotations detected._\n\n'; }

  const fw = analysis.frameworks || {};
  const fwKeys = ['spring','lombok','junit','jakarta','quarkus'];
  const detectedFW = fwKeys.filter(k => (fw[k]||[]).length > 0);
  if (detectedFW.length > 0) {
    md += `### Detected Frameworks\n\n`;
    for (const k of detectedFW) md += `- **${escapeMarkdown(k.charAt(0).toUpperCase()+k.slice(1))}** – ${fw[k].length} file(s)\n`;
    md += '\n';
  }
  md += `---\n\n`;

  md += `## 13. Most Used Imports\n\n`;
  const imports = Object.entries(analysis.imports||{}).sort((a,b)=>b[1]-a[1]).slice(0,20);
  if (imports.length) {
    md += `| Package | Uses |\n|---|---:|\n`;
    for (const [k,v] of imports) md += `| \`${escapeMarkdown(k)}\` | ${v} |\n`;
    md += '\n';
  } else { md += '_No imports found._\n\n'; }
  md += `---\n\n`;

  md += `## 14. TODOs & FIXMEs\n\n`;
  const todos = analysis.todos || [];
  if (todos.length) {
    md += `| File | Note |\n|---|---|\n`;
    // FIX (review.md #4): escapeMarkdown() escaped ALLE HTML-relevanten Zeichen.
    // Vorher: nur | wurde escaped. <script>, <img onerror=...> etc. blieben roh.
    for (const t of todos) md += `| \`${escapeMarkdown(t.file)}\` | ${escapeMarkdown(t.note)} |\n`;
    md += '\n';
  } else { md += '_No TODOs or FIXMEs found._ ✅\n\n'; }
  md += `---\n\n`;

  md += `*Report generated by MAXXKI Deep Semantic Analyser v3.1 — read-only, domain-aware, semantically-enriched.*\n`;

  process.stdout.write(md + '\n');
});

// ══════════════════════════════════════════════════════════════════════════════
// SECURITY: HTML-INJECTION FIX (review.md #4 / Teil 2 #4)
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Escaped alle HTML-relevanten Sonderzeichen und den Markdown-Tabellentrennzeichen.
 *
 * Vorher: s.replace(/\|/g,'\\|')
 * Problem: <, >, &, " wurden NICHT escaped.
 * Ein Angreifer der // TODO <script>alert('XSS')</script> in eine Java-Datei
 * schreibt, konnte HTML in den Markdown-Report injizieren.
 *
 * Jetzt: Vollständiges Escaping für HTML und Markdown.
 *
 * @param {string} s  Eingabe-String (von LLM-Output, Code-Kommentaren, etc.)
 * @returns {string}  Sicherer String für Markdown-Tabellen
 */
function escapeMarkdown(s) {
    if (s == null) return '';
    return String(s)
        .replace(/&/g,  '&amp;')   // Muss zuerst (sonst doppelt-escaped)
        .replace(/</g,  '&lt;')
        .replace(/>/g,  '&gt;')
        .replace(/"/g,  '&quot;')
        .replace(/'/g,  '&#39;')
        .replace(/\|/g, '\\|');    // Markdown-Tabellen-Trennzeichen
}

function getRisk(ctx) {
  const risks = { HARDWARE:'CRITICAL', COMPLIANCE:'CRITICAL', REALTIME:'HIGH', SERVER:'HIGH', DATA_ACCESS:'MEDIUM', CORE:'MEDIUM', API:'MEDIUM', MODEL:'LOW', UTIL:'VERY_LOW', UNKNOWN:'UNKNOWN' };
  return risks[ctx] || 'UNKNOWN';
}

function severityOrd(s) {
  return s === 'CRITICAL' ? 4 : s === 'HIGH' ? 3 : s === 'MEDIUM' ? 2 : s === 'LOW' ? 1 : 0;
}
