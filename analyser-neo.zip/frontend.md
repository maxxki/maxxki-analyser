o $ cat agents/codeAnalyzer.js
#!/usr/bin/env node
/**
 * codeAnalyzer.js  ─  MAXXKI DEEP SEMANTIC ANALYSER  v3.0
 * ══════════════════════════════════════════════════════════════════════════════
 *
 * NOT just static analysis. This engine performs:
 *
 *  1. STRUCTURAL ANALYSIS      – classes, methods, fields, packages, imports
 *  2. SEMANTIC ANALYSIS        – domain context, business logic classification
 *  3. SIDE EFFECT DETECTION    – field mutation, IO, threads, DB, network,
 *                                buffer overflow risks, thread-safety issues,
 *                                IO contention (broadcast-specific)
 *  4. TAINT FLOW ANALYSIS      – SQL injection, XSS, path traversal, cmd inj,
 *                                XXE, LDAP, hardcoded secrets, insecure random
 *  5. SCC / COUPLING           – Tarjan's strongly-connected-components on
 *                                package-graph AND class-graph
 *  6. MEMORY LEAK DETECTION    – static collections, unclosed resources,
 *                                listener leaks, timer leaks, ThreadLocal,
 *                                cache-without-limit, memory layout inefficiency
 *  7. POLYMORPHIC EFFECT MAP   – tracks interface call sites → implementations
 *  8. LEGACY ANALYSIS          – Vector/Hashtable/Stack, raw types, old APIs,
 *                                thread-safety regressions
 *  9. DOMAIN CONTEXT           – HARDWARE / REALTIME / COMPLIANCE / SERVER /
 *                                DATA_ACCESS / CORE / UTIL / MODEL / API / UNKNOWN
 * 10. REFACTORING RISK         – DO_NOT_TOUCH / ANALYZE_ONLY /
 *                                SAFE_TRANSFORM / MICROSERVICE_WRAP
 * 11. JAVA VERSION FINGERPRINT – detects minimal Java version from syntax
 * 12. BROADCAST CRITICALITY    – frame-accuracy, timecode, playout, GPI, RS422
 *
 * READ-ONLY – no file writes under any circumstances.
 *
 * stdin  → JSON array of { name, path, relative, size, ext }
 * stdout → deep analysis JSON
 * ══════════════════════════════════════════════════════════════════════════════
 */

'use strict';

const fs = require('fs');

// ── READ-ONLY PROTECTION ──────────────────────────────────────────────────────
fs.writeFileSync = fs.writeFile = fs.appendFileSync = fs.appendFile =
fs.unlinkSync    = fs.unlink    = fs.rmdirSync      = fs.rmdir      =
fs.mkdirSync     = fs.mkdir     = () => { process.exit(99); };

// ══════════════════════════════════════════════════════════════════════════════
// PATTERN LIBRARIES
// ══════════════════════════════════════════════════════════════════════════════

const RX = {
  // ── STRUCTURE ──────────────────────────────────────────────────────────────
  packageDecl:      /^\s*package\s+([\w.]+)\s*;/m,
  imports:          /^\s*import\s+(static\s+)?([\w.*]+)\s*;/gm,
  classDecl:        /(?:^|\n)\s*(?:(?:public|private|protected|abstract|final|static|sealed|non-sealed)\s+)*(?:class|interface|enum|record|@interface)\s+(\w+)(?:\s*<[^>]*>)?(?:\s+extends\s+[\w.<>, ]+)?(?:\s+implements\s+[\w.<>, ]+)?\s*\{/g,
  methodDecl:       /(?:^|\n)\s*(?:(?:@\w+(?:\([^)]*\))?\s+)*)?(?:public|private|protected)\s+(?:(?:static|final|synchronized|abstract|default|native|transient)\s+)*(?:[\w<>\[\].,? ]+\s+)(\w+)\s*\(([^)]*)\)\s*(?:throws\s+[\w,. ]+)?\s*[\{;]/g,
  fieldDecl:        /(?:^|\n)\s*(?:(?:public|private|protected|static|final|volatile|transient|@\w+\s+)*)+(?:[\w<>\[\].,? ]+)\s+(\w+)\s*(?:=|;)/g,
  annotations:      /@(\w+)(?:\([^)]*\))?/g,
  singleComment:    /\/\/[^\n]*/g,
  blockComment:     /\/\*[\s\S]*?\*\//g,
  todoFixme:        /\/\/\s*(TODO|FIXME|HACK|XXX|NOSONAR|SECURITY)[^\n]*/gi,

  // ── FRAMEWORK FINGERPRINTS ──────────────────────────────────────────────────
  springAnno:       /@(Controller|RestController|Service|Repository|Component|Bean|Autowired|RequestMapping|GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping|Entity|Table|SpringBootApplication|Configuration|Value|Transactional|Scheduled|EventListener|ConditionalOn\w+)/g,
  lombokAnno:       /@(Data|Getter|Setter|Builder|NoArgsConstructor|AllArgsConstructor|RequiredArgsConstructor|Slf4j|Log4j2?|ToString|EqualsAndHashCode|SuperBuilder|With|SneakyThrows|Cleanup|NonNull)/g,
  junitAnno:        /@(Test|BeforeEach|AfterEach|BeforeAll|AfterAll|ParameterizedTest|MockBean|Mock|InjectMocks|ExtendWith|SpringBootTest|WebMvcTest|DataJpaTest|ValueSource|CsvSource|MethodSource)/g,
  jakartaAnno:      /@(NotNull|NotBlank|NotEmpty|Size|Min|Max|Pattern|Email|Valid|Validated|Path|QueryParam|Consumes|Produces|POST|GET|PUT|DELETE)/g,
  quarkusAnno:      /@(ApplicationScoped|RequestScoped|Dependent|Inject|ConfigProperty|RegisterRestClient)/g,
  micronautAnno:    /@(Singleton|Prototype|Controller|Client|Inject|Value|ConfigurationProperties)/g,

  // ── SIDE EFFECT DETECTION ──────────────────────────────────────────────────
  fieldMutation:    /\bthis\.\w+\s*(?:\+|-|\*|\/|%|\||\&|\^)?=(?!=)/g,
  staticMutation:   /\b[A-Z_]{2,}\s*(?:\+|-|\*|\/|%|\||\&|\^)?=(?!=)/g,
  collectionMut:    /\.(add|remove|clear|put|putAll|removeAll|addAll|offer|poll|push|pop|set|replace|merge|compute|computeIfAbsent|computeIfPresent)\s*\(/g,
  ioOperation:      /\b(FileInputStream|FileOutputStream|BufferedReader|BufferedWriter|PrintWriter|FileWriter|FileReader|RandomAccessFile|Files\.(read|write|copy|move|delete)|new\s+File\s*\(|\.read\(|\.write\(|\.flush\(|\.close\()/g,
  threadOp:         /\b(new\s+Thread|\.start\(\)|ExecutorService|ThreadPool|Executors\.|Thread\.sleep|\.interrupt\(\)|\.join\(\)|CompletableFuture|ForkJoinPool|ScheduledExecutor)/g,
  syncOp:           /\b(synchronized\s*\(|\.lock\(\)|\.unlock\(\)|\.await\(\)|\.signal\(\)|Semaphore|CountDownLatch|CyclicBarrier|Phaser|StampedLock)/g,
  dbAccess:         /\b(executeQuery|executeUpdate|prepareStatement|createStatement|getConnection|\.save\(|\.delete\(|\.findBy|\.update\(|entityManager|createQuery|nativeQuery|@Query|JdbcTemplate|NamedParameterJdbc)/g,
  networkCall:      /\b(HttpClient|RestTemplate|WebClient|OkHttpClient|HttpURLConnection|URL\s*\(|\.openConnection\(\)|Socket\s*\(|ServerSocket|DatagramSocket|\.send\(|\.receive\()/g,
  ioContention:     /\b(RandomAccessFile|FileChannel|FileLock|MappedByteBuffer|\.tryLock\(\)|FileDescriptor|StandardOpenOption\.(READ|WRITE|APPEND)|AsynchronousFileChannel)/g,
  bufferOverflow:   /\b(ByteBuffer\.allocate|\.put\(|\.get\(|\.flip\(\)|\.rewind\(\)|DirectByteBuffer|MappedByteBuffer|\.capacity\(\)|\.limit\(|\.position\()/g,
  threadSafety:     /\b((?<!volatile\s)(?<!synchronized\s)(?<!AtomicInteger|AtomicLong|AtomicBoolean|AtomicReference)(?:private|public|protected)\s+(?:static\s+)?(?!final)(?:int|long|boolean|double|float|String|List|Map|Set|Queue|Deque)\s+\w+\s*=)/g,

  // ── TAINT SOURCES ──────────────────────────────────────────────────────────
  taintSources:     /\b(getParameter|getHeader|getInputStream|getReader|readLine|readAllBytes|readString|args\[|System\.in|getenv|getProperty|getAttribute|getCookies|getRequestURI|getQueryString|getBody|PathVariable|RequestParam|RequestBody|RequestHeader)\b/g,
  taintSinks: {
    sqli:           /\b(executeQuery|execute|executeUpdate|prepareStatement|createNativeQuery)\s*\(\s*(?!.*\?)[^)]*(?:query|sql|stmt|command|input|param|value|id|name|user)[^)]*\)/gi,
    xss:            /\b(println|print|write|append|out\.)\s*\([^)]*(?:input|param|value|user|request|data|content)[^)]*\)/gi,
    pathTraversal:  /\b(new\s+File|Paths\.get|FileInputStream|Files\.read)\s*\([^)]*(?:input|param|value|path|file|dir|user|name)[^)]*\)/gi,
    cmdInjection:   /\b(Runtime\.exec|ProcessBuilder|exec)\s*\([^)]*(?:input|param|cmd|command|value|user)[^)]*\)/gi,
    xxe:            /\b(DocumentBuilder|SAXParser|XMLReader|SchemaFactory|TransformerFactory)\b(?!.*setFeature.*XMLConstants)/gs,
    ldapInjection:  /\b(DirContext|LdapContext|NamingEnumeration)\b.*(?:input|param|user|value)/gs,
    hardcodedSecret:/(?:password|passwd|pwd|secret|apikey|api_key|token|auth)\s*=\s*["'][^"']{6,}["']/gi,
    insecureRandom: /\bnew\s+Random\s*\(\)/g,
    weakCrypto:     /\b(MD5|SHA1|DES|RC4|ECB)\b|MessageDigest\.getInstance\s*\(\s*["'](?:MD5|SHA-1)["']\)/gi,
  },

  // ── MEMORY LEAK PATTERNS ───────────────────────────────────────────────────
  staticCollection: /\bstatic\s+(?:final\s+)?(?:List|Map|Set|Queue|Collection|Deque|Stack|Vector|Hashtable)<[^;]*>\s+\w+\s*=\s*new\s+(?:Array|Hash|Linked|Tree|Concurrent|Copy)/g,
  unclosedResource: /\bnew\s+(?:FileInputStream|FileOutputStream|Connection|Socket|BufferedReader|BufferedWriter|PreparedStatement|Statement|ResultSet|Scanner|ZipFile|JarFile)\s*\(/g,
  listenerLeak:     /\.add(?:Action|Key|Mouse|Focus|Component|Item|Change|Document|Selection|Window|Property|VetoableChange)?Listener\s*\(/g,
  timerLeak:        /\bnew\s+(?:Timer|TimerTask|ScheduledThreadPoolExecutor)\s*\(/g,
  threadLocalLeak:  /\bThreadLocal\b/g,
  innerClassRef:    /\bnew\s+\w+\s*\(\)\s*\{/g,
  cacheNoLimit:     /\bnew\s+(?:HashMap|LinkedHashMap|ConcurrentHashMap|WeakHashMap)\s*\(/g,
  memLayoutBad:     /(?:private|public|protected)\s+(?:byte|boolean|char)\s+\w+;\s*\n\s*(?:private|public|protected)\s+(?:long|double|int)\s+\w+;/g,

  // ── LEGACY DETECTION ───────────────────────────────────────────────────────
  legacyCollections:/\b(Vector|Hashtable|Stack|Dictionary|Enumeration|StringBuffer)\b(?:\s*<|\s*\()/g,
  rawTypes:         /\b(List|Map|Set|Collection|Queue|Iterator)\s+\w+\s*=\s*new\s+(?:Array|Hash|Link|Tree)/g,
  deprecatedAPI:    /\b(Thread\.stop|Thread\.suspend|Thread\.resume|Date\.getYear|Date\.getMonth|System\.runFinalizersOnExit|Runtime\.runFinalizersOnExit)\s*\(/g,
  oldDateAPI:       /\bnew\s+(?:Date|Calendar|GregorianCalendar|SimpleDateFormat)\s*\(/g,
  exceptionSwallow: /catch\s*\([^)]+\)\s*\{\s*(?:\/\/[^\n]*)?\s*\}/g,

  // ── BROADCAST / REALTIME DOMAIN ────────────────────────────────────────────
  broadcastHW:      /\b(Rs422|VDCP|GPIO|GPI|SerialPort|HardwareInterface|DeviceDriver|BroadcastController|PlayoutEngine|VBIData|LTCTimecode|ATC|SDI|HDSDI|SFP|NDI|SDIOutput)\b/gi,
  timecode:         /\b(Timecode|Framerate|DropFrame|NonDropFrame|SMPTE|EBU|LTC|VITC|timecode|frameCount|fieldRate|vblank|VBlank|syncFrame|PTS|DTS|PCR)\b/g,
  playout:          /\b(Playout|PlayoutInfo|Automator|SendeplanProcessor|BroadcastStream|LiveStream|OutputStream|Switcher|Matrix|Router|Crosspoint)\b/g,
  compliance:       /\b(EBU|R128|SCTE35|DVB|MPEG|MXF|BXF|ADI|Rechnung|Werbedispo|Sendestatistik|StatistikProcessor)\b/g,

  // ── JAVA VERSION FINGERPRINTS ──────────────────────────────────────────────
  java21:           /\b(Thread\.startVirtualThread|Executors\.newVirtualThreadPerTaskExecutor|Thread\.ofVirtual\(\)|SequencedCollection|SequencedMap)\b/g,
  java17:           /(?:instanceof\s+\w+\s+\w+|\bsealed\b|\bpermits\b)/g,
  java16:           /^\s*(?:public\s+)?record\s+\w+\s*\(/m,
  java15:           /"""[\s\S]*?"""/g,
  java14:           /\byield\b/g,
  java10:           /\bvar\s+\w+\s*=/g,
  java9:            /\bmodule\s+\w+/g,
  java8:            /(?:->|::)|\bStream\b|\bOptional\b|\bCompletableFuture\b/g,
  java7:            /try\s*\([^)]+\)|<>/g,
  java5:            /@\w+|<[A-Z,\s?]+>/g,
};

// ══════════════════════════════════════════════════════════════════════════════
// DOMAIN CONTEXT REGISTRY
// ══════════════════════════════════════════════════════════════════════════════

const DOMAIN_REGISTRY = {
  HARDWARE:    { patterns: ['Rs422','VDCP','GPIO','SerialPort','HardwareInterface','DeviceDriver','BroadcastController','PlayoutEngine','VBIData','LTCTimecode','SDI','NDI','SFP'], risk: 'DO_NOT_TOUCH',     priority: 1 },
  COMPLIANCE:  { patterns: ['EBU','R128','SCTE','DVB','Rechnung','Werbedispo','Sendestatistik','StatistikProcessor','MXF','BXF','ADI'],                                           risk: 'DO_NOT_TOUCH',     priority: 2 },
  REALTIME:    { patterns: ['Timecode','Playout','Automator','Broadcast','LTC','VITC','SMPTE','FrameSet','FreeFlow','SendeplanProcessor'],                                         risk: 'ANALYZE_ONLY',     priority: 3 },
  SERVER:      { patterns: ['JAMServer','Processor','ShutdownProcessor','InvokeDescription','AutomationProcessor'],                                                                risk: 'ANALYZE_ONLY',     priority: 4 },
  DATA_ACCESS: { patterns: ['DBHandler','Repository','JdbcTemplate','EntityManager','DataSource','JpaRepository','CrudRepository'],                                               risk: 'SAFE_TRANSFORM',   priority: 5 },
  CORE:        { patterns: ['SettingsFile','Logger','Log','Tools','KeyFactory','ApplicationFrame','Configuration'],                                                                risk: 'SAFE_TRANSFORM',   priority: 6 },
  API:         { patterns: ['Controller','RestController','Resource','Endpoint','Handler','Servlet','Filter'],                                                                     risk: 'SAFE_TRANSFORM',   priority: 7 },
  MODEL:       { patterns: ['Entity','DTO','Record','Bean','Value','Request','Response','Event','Command','Query'],                                                                risk: 'MICROSERVICE_WRAP',priority: 8 },
  UTIL:        { patterns: ['Util','Helper','Tools','Calendar','Format','Converter','Mapper','Parser','Encoder','Decoder'],                                                        risk: 'MICROSERVICE_WRAP',priority: 9 },
  UNKNOWN:     { patterns: [],                                                                                                                                                    risk: 'ANALYZE_ONLY',     priority: 99 },
};

// ══════════════════════════════════════════════════════════════════════════════
// TARJAN SCC
// ══════════════════════════════════════════════════════════════════════════════

function findSCCs(graph) {
  const index   = new Map();
  const lowlink = new Map();
  const onStack = new Set();
  const stack   = [];
  const sccs    = [];
  let   idx     = 0;

  function strongConnect(node) {
    index.set(node, idx);
    lowlink.set(node, idx);
    idx++;
    stack.push(node);
    onStack.add(node);

    for (const neighbor of (graph.get(node) || [])) {
      if (!index.has(neighbor)) {
        strongConnect(neighbor);
        lowlink.set(node, Math.min(lowlink.get(node), lowlink.get(neighbor)));
      } else if (onStack.has(neighbor)) {
        lowlink.set(node, Math.min(lowlink.get(node), index.get(neighbor)));
      }
    }

    if (lowlink.get(node) === index.get(node)) {
      const scc = [];
      let w;
      do {
        w = stack.pop();
        onStack.delete(w);
        scc.push(w);
      } while (w !== node);
      if (scc.length > 1) sccs.push(scc);
    }
  }

  for (const node of graph.keys()) {
    if (!index.has(node)) strongConnect(node);
  }

  return sccs;
}

// ══════════════════════════════════════════════════════════════════════════════
// COUPLING GRAPH BUILDER
// ══════════════════════════════════════════════════════════════════════════════

function buildCouplingGraphs(files) {
  // package → Set<package>  (from imports)
  const pkgGraph   = new Map();
  // class   → Set<class>   (from extends/implements/field types)
  const classGraph = new Map();

  for (const f of files) {
    const pkg = f.package || '(default)';
    if (!pkgGraph.has(pkg)) pkgGraph.set(pkg, new Set());

    // Parse imports as package-level edges
    for (const imp of (f.imports || [])) {
      const parts = imp.split('.');
      if (parts.length > 1) {
        const targetPkg = parts.slice(0, -1).join('.');
        if (targetPkg !== pkg && !targetPkg.startsWith('java.') && !targetPkg.startsWith('javax.')) {
          pkgGraph.get(pkg).add(targetPkg);
        }
      }
    }

    // Class-level graph from class names x imports (lightweight without AST)
    for (const cls of (f.classes || [])) {
      const fqn = pkg + '.' + cls;
      if (!classGraph.has(fqn)) classGraph.set(fqn, new Set());
      // Each import is a potential class dependency edge
      for (const imp of (f.imports || [])) {
        if (!imp.startsWith('java.') && !imp.startsWith('javax.') && imp !== fqn) {
          classGraph.get(fqn).add(imp);
        }
      }
    }
  }

  return { pkgGraph, classGraph };
}

// ══════════════════════════════════════════════════════════════════════════════
// DOMAIN CONTEXT CLASSIFIER
// ══════════════════════════════════════════════════════════════════════════════

function classifyDomain(raw, filename, pkg) {
  const text = (raw + ' ' + filename + ' ' + pkg).toLowerCase();
  const hits = {};

  for (const [ctx, cfg] of Object.entries(DOMAIN_REGISTRY)) {
    if (ctx === 'UNKNOWN') continue;
    let score = 0;
    for (const pat of cfg.patterns) {
      if (text.includes(pat.toLowerCase())) score++;
    }
    if (score > 0) hits[ctx] = { score, priority: cfg.priority, risk: cfg.risk };
  }

  if (Object.keys(hits).length === 0) return { context: 'UNKNOWN', risk: 'ANALYZE_ONLY', score: 0 };

  const best = Object.entries(hits).sort((a, b) =>
    a[1].priority - b[1].priority || b[1].score - a[1].score
  )[0];

  return { context: best[0], risk: best[1].risk, score: best[1].score, allContexts: hits };
}

// ══════════════════════════════════════════════════════════════════════════════
// JAVA VERSION DETECTOR
// ══════════════════════════════════════════════════════════════════════════════

function detectJavaVersion(raw) {
  if (RX.java21.test(raw))  { RX.java21.lastIndex = 0; return 21; }
  if (RX.java17.test(raw))  { RX.java17.lastIndex = 0; return 17; }
  if (RX.java16.test(raw))  { RX.java16.lastIndex = 0; return 16; }
  if (RX.java15.test(raw))  { RX.java15.lastIndex = 0; return 15; }
  if (RX.java14.test(raw))  { RX.java14.lastIndex = 0; return 14; }
  if (RX.java10.test(raw))  { RX.java10.lastIndex = 0; return 10; }
  if (RX.java9.test(raw))   { RX.java9.lastIndex  = 0; return 9; }
  if (RX.java8.test(raw))   { RX.java8.lastIndex  = 0; return 8; }
  if (RX.java7.test(raw))   { RX.java7.lastIndex  = 0; return 7; }
  if (RX.java5.test(raw))   { RX.java5.lastIndex  = 0; return 5; }
  return 1;
}

// ══════════════════════════════════════════════════════════════════════════════
// SIDE EFFECT ANALYSER
// ══════════════════════════════════════════════════════════════════════════════

function analyzeSideEffects(raw, filename) {
  const effects = {
    fieldMutations:       [],
    staticFieldMutations: [],
    collectionMutations:  [],
    ioOperations:         [],
    threadOperations:     [],
    syncOperations:       [],
    dbAccess:             [],
    networkCalls:         [],
    ioContentions:        [],
    bufferOverflowRisks:  [],
    threadSafetyIssues:   [],
    exceptionThrows:      [],
    broadcastSpecific:    [],
  };

  const collect = (rx, target, extractor) => {
    let m;
    const fresh = new RegExp(rx.source, rx.flags);
    while ((m = fresh.exec(raw)) !== null) {
      const val = extractor ? extractor(m) : m[0].trim();
      if (val && !target.includes(val)) target.push(val);
    }
  };

  collect(RX.collectionMut,   effects.collectionMutations,  m => m[0].trim());
  collect(RX.ioOperation,     effects.ioOperations,          m => m[0].trim());
  collect(RX.threadOp,        effects.threadOperations,      m => m[0].trim());
  collect(RX.syncOp,          effects.syncOperations,        m => m[0].trim());
  collect(RX.dbAccess,        effects.dbAccess,              m => m[0].trim());
  collect(RX.networkCall,     effects.networkCalls,          m => m[0].trim());
  collect(RX.ioContention,    effects.ioContentions,         m => m[0].trim());
  collect(RX.bufferOverflow,  effects.bufferOverflowRisks,   m => m[0].trim());

  // Broadcast-specific side effects
  collect(RX.broadcastHW,     effects.broadcastSpecific,     m => 'HARDWARE:' + m[0]);
  collect(RX.timecode,        effects.broadcastSpecific,     m => 'REALTIME:' + m[0]);
  collect(RX.playout,         effects.broadcastSpecific,     m => 'PLAYOUT:' + m[0]);

  // Field mutation – count `this.x =` patterns
  const fieldHits = (raw.match(RX.fieldMutation) || []);
  effects.fieldMutations = [...new Set(fieldHits.map(h => h.trim()))];

  // Thread safety issues: non-volatile, non-atomic mutable fields in class scope
  // Simplified: count synchronized blocks
  effects.threadSafetyIssues = (raw.match(RX.syncOp) || []).map(s => s.trim());

  // Exception swallowing
  effects.exceptionThrows = (raw.match(/\bthrow\s+new\s+(\w+)/g) || []).map(s => s.replace('throw new ', ''));

  // Severity calculation
  let riskScore = 0;
  riskScore += effects.bufferOverflowRisks.length  * 15;
  riskScore += effects.threadSafetyIssues.length   * 12;
  riskScore += effects.ioContentions.length        * 10;
  riskScore += effects.staticFieldMutations.length * 8;
  riskScore += effects.networkCalls.length         * 6;
  riskScore += effects.dbAccess.length             * 5;
  riskScore += effects.ioOperations.length         * 4;
  riskScore += effects.threadOperations.length     * 4;
  riskScore += effects.collectionMutations.length  * 2;
  riskScore += effects.fieldMutations.length       * 1;

  const severity =
    riskScore >= 60 ? 'CRITICAL' :
    riskScore >= 35 ? 'HIGH'     :
    riskScore >= 15 ? 'MEDIUM'   :
    riskScore >  0  ? 'LOW'      : 'NONE';

  const broadcastSafe =
    effects.bufferOverflowRisks.length === 0 &&
    effects.ioContentions.length === 0 &&
    effects.ioOperations.length === 0;

  return { ...effects, riskScore: Math.min(riskScore, 100), severity, broadcastSafe };
}

// ══════════════════════════════════════════════════════════════════════════════
// TAINT FLOW ANALYSER
// ══════════════════════════════════════════════════════════════════════════════

function analyzeTaint(raw, filename) {
  const sources        = [];
  const vulnerabilities= [];

  // Collect taint sources
  const srcMatches = raw.matchAll(RX.taintSources);
  for (const m of srcMatches) {
    if (!sources.includes(m[1])) sources.push(m[1]);
  }

  if (sources.length === 0) return { sources, vulnerabilities, isTainted: false };

  // Check sinks
  const checkSink = (rx, type, severity, recommendation) => {
    const fresh = new RegExp(rx.source, rx.flags);
    let m;
    while ((m = fresh.exec(raw)) !== null) {
      // Rough line number
      const lineNum = raw.substring(0, m.index).split('\n').length;
      vulnerabilities.push({ type, severity, lineNumber: lineNum, code: m[0].trim().substring(0, 80), recommendation });
    }
  };

  checkSink(RX.taintSinks.sqli,          'SQL_INJECTION',     'CRITICAL', 'Use PreparedStatement with parameterized queries');
  checkSink(RX.taintSinks.xss,           'XSS',               'HIGH',     'Encode user input before rendering in HTML (OWASP Java Encoder)');
  checkSink(RX.taintSinks.pathTraversal, 'PATH_TRAVERSAL',    'HIGH',     'Validate and normalize file paths; check against allowed directories');
  checkSink(RX.taintSinks.cmdInjection,  'COMMAND_INJECTION', 'CRITICAL', 'Avoid executing system commands with user input. Use whitelist validation');
  checkSink(RX.taintSinks.xxe,           'XXE',               'CRITICAL', 'Disable external entity processing in XML parsers');
  checkSink(RX.taintSinks.ldapInjection, 'LDAP_INJECTION',    'HIGH',     'Escape special LDAP characters; use parameterized queries');
  checkSink(RX.taintSinks.hardcodedSecret,'HARDCODED_SECRET', 'HIGH',     'Store secrets in environment variables or a secrets manager');
  checkSink(RX.taintSinks.insecureRandom,'INSECURE_RANDOM',  'MEDIUM',   'Use SecureRandom for security-critical operations');
  checkSink(RX.taintSinks.weakCrypto,    'WEAK_CRYPTOGRAPHY', 'HIGH',     'Use AES-256, SHA-256 or stronger algorithms');

  return { sources, vulnerabilities, isTainted: sources.length > 0 };
}

// ══════════════════════════════════════════════════════════════════════════════
// MEMORY LEAK DETECTOR
// ══════════════════════════════════════════════════════════════════════════════

function detectMemoryLeaks(raw, filename) {
  const leaks = [];

  const check = (rx, type, severity, description, recommendation) => {
    const fresh = new RegExp(rx.source, rx.flags);
    let m;
    while ((m = fresh.exec(raw)) !== null) {
      const lineNum = raw.substring(0, m.index).split('\n').length;
      leaks.push({ type, severity, lineNumber: lineNum, location: filename, code: m[0].trim().substring(0, 80), description, recommendation });
    }
  };

  check(RX.staticCollection, 'STATIC_COLLECTION_GROWTH', 'CRITICAL',
    'Static collection grows indefinitely without cleanup',
    'Add cleanup mechanism or use WeakHashMap/SoftReference');

  check(RX.unclosedResource, 'UNCLOSED_RESOURCE', 'CRITICAL',
    'Resource not wrapped in try-with-resources',
    'Use try-with-resources or ensure close() in finally block');

  check(RX.listenerLeak, 'LISTENER_NOT_REMOVED', 'MEDIUM',
    'Event listener registered – ensure it is removed on cleanup',
    'Implement cleanup method to deregister listeners');

  check(RX.timerLeak, 'TIMER_NOT_CANCELLED', 'MEDIUM',
    'Timer/ScheduledTask created – ensure it is cancelled on shutdown',
    'Cancel timer when component is destroyed');

  check(RX.threadLocalLeak, 'THREADLOCAL_NOT_REMOVED', 'HIGH',
    'ThreadLocal usage detected – ensure remove() is called',
    'Call ThreadLocal.remove() in finally block after use');

  check(RX.memLayoutBad, 'MEMORY_LAYOUT_INEFFICIENT', 'LOW',
    'Field ordering may cause JVM padding waste (byte/boolean before long/double)',
    'Reorder fields: primitives from largest to smallest, objects last');

  return leaks;
}

// ══════════════════════════════════════════════════════════════════════════════
// LEGACY ANALYSER
// ══════════════════════════════════════════════════════════════════════════════

function analyzeLegacy(raw, filename) {
  const issues = [];

  const legacyCols = (raw.match(RX.legacyCollections) || []).map(m => m.trim());
  if (legacyCols.length > 0) {
    issues.push({
      type: 'LEGACY_COLLECTIONS',
      count: legacyCols.length,
      instances: [...new Set(legacyCols)],
      recommendation: 'Replace Vector→ArrayList, Hashtable→HashMap, Stack→ArrayDeque, StringBuffer→StringBuilder',
      severity: 'MEDIUM',
      safeToTransform: true,
    });
  }

  const rawTypes = (raw.match(RX.rawTypes) || []).map(m => m.trim());
  if (rawTypes.length > 0) {
    issues.push({
      type: 'RAW_TYPES',
      count: rawTypes.length,
      recommendation: 'Add generic type parameters for type safety',
      severity: 'LOW',
      safeToTransform: true,
    });
  }

  const deprecated = (raw.match(RX.deprecatedAPI) || []).map(m => m.trim());
  if (deprecated.length > 0) {
    issues.push({
      type: 'DEPRECATED_API',
      count: deprecated.length,
      instances: [...new Set(deprecated)],
      recommendation: 'Migrate away from deprecated Thread and Date APIs',
      severity: 'HIGH',
      safeToTransform: false,
    });
  }

  const oldDates = (raw.match(RX.oldDateAPI) || []).length;
  if (oldDates > 0) {
    issues.push({
      type: 'OLD_DATE_API',
      count: oldDates,
      recommendation: 'Use java.time.* (LocalDate, ZonedDateTime, Instant) instead of Date/Calendar',
      severity: 'LOW',
      safeToTransform: true,
    });
  }

  const swallowed = (raw.match(RX.exceptionSwallow) || []).length;
  if (swallowed > 0) {
    issues.push({
      type: 'EXCEPTION_SWALLOWING',
      count: swallowed,
      recommendation: 'Log or rethrow exceptions; never silently swallow them',
      severity: 'HIGH',
      safeToTransform: false,
    });
  }

  return {
    issues,
    totalCount: issues.reduce((s, i) => s + i.count, 0),
    hasHighRisk: issues.some(i => i.severity === 'HIGH' || i.severity === 'CRITICAL'),
    safeToTransform: issues.every(i => i.safeToTransform),
  };
}

// ══════════════════════════════════════════════════════════════════════════════
// POLYMORPHIC EFFECT MAP BUILDER
// ══════════════════════════════════════════════════════════════════════════════

function buildPolymorphicMap(raw, fileInfo) {
  const interfaceCalls = [];
  // Detect interface type invocations: someService.doSomething(
  const methodCallRx = /(\w+)\s*\.\s*([a-z]\w+)\s*\(/g;
  let m;
  while ((m = methodCallRx.exec(raw)) !== null) {
    const receiver = m[1];
    const method   = m[2];
    // Heuristic: if receiver name ends in Service/Repository/Handler/Manager/Strategy/Factory
    if (/Service|Repository|Handler|Manager|Strategy|Factory|Processor|Provider|Resolver/i.test(receiver)) {
      interfaceCalls.push({ receiver, method, callSite: fileInfo.relative });
    }
  }
  return interfaceCalls;
}

// ══════════════════════════════════════════════════════════════════════════════
// REFACTORING RISK CALCULATOR
// ══════════════════════════════════════════════════════════════════════════════

function calcRefactoringRisk(fileInfo, sideEffects, memLeaks, legacy, domain, sccInfo) {
  let score = 0;

  // Domain context weights
  const domainWeight = { HARDWARE: 80, COMPLIANCE: 70, REALTIME: 60, SERVER: 50, DATA_ACCESS: 30, CORE: 35, API: 25, MODEL: 10, UTIL: 5, UNKNOWN: 40 };
  score += domainWeight[domain.context] || 40;

  // Side effect pressure
  score += sideEffects.riskScore * 0.3;

  // Memory leak pressure
  score += Math.min(memLeaks.filter(l => l.severity === 'CRITICAL').length * 10, 30);

  // Legacy pressure
  if (legacy.hasHighRisk) score += 15;

  // SCC coupling pressure
  score += Math.min((sccInfo.packageCycles || 0) * 10, 30);
  score += Math.min((sccInfo.classCycles || 0) * 5, 20);

  // File size pressure
  if (fileInfo.lines > 2000) score += 20;
  else if (fileInfo.lines > 1000) score += 10;

  score = Math.min(score, 100);

  const strategy =
    score >= 75 ? 'DO_NOT_TOUCH'      :
    score >= 55 ? 'ANALYZE_ONLY'      :
    score >= 30 ? 'SAFE_TRANSFORM'    : 'MICROSERVICE_WRAP';

  const riskLevel =
    score >= 75 ? 'CRITICAL' :
    score >= 55 ? 'HIGH'     :
    score >= 30 ? 'MEDIUM'   : 'LOW';

  return { score: Math.round(score), strategy, riskLevel };
}

// ══════════════════════════════════════════════════════════════════════════════
// PER-FILE DEEP ANALYSIS
// ══════════════════════════════════════════════════════════════════════════════

function analyseFile(f, raw, globalResult) {
  const stripped = raw.replace(RX.blockComment, m => '\n'.repeat((m.match(/\n/g)||[]).length));

  // ── Line metrics ─────────────────────────────────────────────────────────
  const lines    = raw.split('\n');
  const codeL    = lines.filter(l => l.trim() && !l.trim().startsWith('//')).length;
  const commentL = lines.filter(l => l.trim().startsWith('//')).length;
  const blankL   = lines.filter(l => !l.trim()).length;

  globalResult.summary.totalLines   += lines.length;
  globalResult.summary.codeLines    += codeL;
  globalResult.summary.commentLines += commentL;
  globalResult.summary.blankLines   += blankL;

  // ── Package ──────────────────────────────────────────────────────────────
  const pkgMatch = raw.match(RX.packageDecl);
  const pkg      = pkgMatch ? pkgMatch[1] : '(default)';
  if (!globalResult.packages[pkg]) globalResult.packages[pkg] = [];
  globalResult.packages[pkg].push(f.relative);

  // ── Imports ───────────────────────────────────────────────────────────────
  const importMatches = [...raw.matchAll(RX.imports)];
  const importList    = importMatches.map(m => m[2]);
  globalResult.summary.totalImports += importList.length;
  for (const imp of importList) {
    const grp = imp.replace(/\.\w+$/, '');
    globalResult.imports[grp] = (globalResult.imports[grp] || 0) + 1;
  }

  // ── Classes ───────────────────────────────────────────────────────────────
  const classMatches = [...stripped.matchAll(RX.classDecl)];
  globalResult.summary.totalClasses += classMatches.length;
  const classes = classMatches.map(m => m[1]);

  // ── Methods ───────────────────────────────────────────────────────────────
  const methodMatches = [...stripped.matchAll(RX.methodDecl)];
  globalResult.summary.totalMethods += methodMatches.length;
  const methods = methodMatches.map(m => ({
    name:   m[1],
    params: m[2].trim() ? m[2].trim().split(',').length : 0,
    sync:   /\bsynchronized\b/.test(m[0]),
  }));

  // ── Fields ────────────────────────────────────────────────────────────────
  const fieldMatches = [...stripped.matchAll(RX.fieldDecl)];
  globalResult.summary.totalFields += fieldMatches.length;

  // ── Annotations ───────────────────────────────────────────────────────────
  for (const m of raw.matchAll(RX.annotations)) {
    globalResult.annotations[m[1]] = (globalResult.annotations[m[1]] || 0) + 1;
  }

  // ── Framework detection ───────────────────────────────────────────────────
  if ([...raw.matchAll(RX.springAnno)].length  > 0) globalResult.frameworks.spring.add(f.relative);
  if ([...raw.matchAll(RX.lombokAnno)].length  > 0) globalResult.frameworks.lombok.add(f.relative);
  if ([...raw.matchAll(RX.junitAnno)].length   > 0) globalResult.frameworks.junit.add(f.relative);
  if ([...raw.matchAll(RX.jakartaAnno)].length > 0) globalResult.frameworks.jakarta.add(f.relative);
  if ([...raw.matchAll(RX.quarkusAnno)].length > 0) globalResult.frameworks.quarkus.add(f.relative);

  // ── TODOs ─────────────────────────────────────────────────────────────────
  for (const m of raw.matchAll(RX.todoFixme)) {
    globalResult.todos.push({ file: f.relative, note: m[0].trim() });
  }

  // ── Java version ──────────────────────────────────────────────────────────
  const javaVersion = detectJavaVersion(raw);
  if (javaVersion > globalResult.summary.maxJavaVersion) {
    globalResult.summary.maxJavaVersion = javaVersion;
  }

  // ── SEMANTIC ANALYSIS ─────────────────────────────────────────────────────
  const domain       = classifyDomain(raw, f.name, pkg);
  const sideEffects  = analyzeSideEffects(raw, f.relative);
  const taint        = analyzeTaint(raw, f.relative);
  const memLeaks     = detectMemoryLeaks(raw, f.relative);
  const legacy       = analyzeLegacy(raw, f.relative);
  const polyMap      = buildPolymorphicMap(raw, f);

  // Collect globally
  if (taint.vulnerabilities.length > 0) {
    globalResult.security.vulnerabilities.push(...taint.vulnerabilities.map(v => ({ ...v, file: f.relative })));
  }
  if (memLeaks.length > 0) {
    globalResult.memoryLeaks.push(...memLeaks);
  }
  if (legacy.totalCount > 0) {
    globalResult.legacyIssues.push({ file: f.relative, ...legacy });
  }
  if (domain.context !== 'UNKNOWN') {
    if (!globalResult.domainMap[domain.context]) globalResult.domainMap[domain.context] = [];
    globalResult.domainMap[domain.context].push(f.relative);
  }
  if (sideEffects.broadcastSpecific.length > 0) {
    globalResult.broadcastFiles.add(f.relative);
  }

  // Refactoring risk (SCC not yet known at file level – will be updated later)
  const riskPre = calcRefactoringRisk(
    { lines: lines.length, relative: f.relative },
    sideEffects, memLeaks, legacy, domain, { packageCycles: 0, classCycles: 0 }
  );

  const fileInfo = {
    name:         f.name,
    relative:     f.relative,
    package:      pkg,
    sizeKB:       +(f.size / 1024).toFixed(2),
    lines:        lines.length,
    codeLines:    codeL,
    commentLines: commentL,
    blankLines:   blankL,
    classes,
    methods,
    fields:       fieldMatches.length,
    imports:      importList,
    javaVersion,
    // Semantic
    domain:       domain.context,
    domainScore:  domain.score,
    allContexts:  domain.allContexts || {},
    refactoringRisk:    riskPre,
    sideEffects,
    taint:        { sources: taint.sources, vulnCount: taint.vulnerabilities.length, isTainted: taint.isTainted },
    memLeakCount: memLeaks.length,
    legacyCount:  legacy.totalCount,
    polymorphicCalls: polyMap,
  };

  return fileInfo;
}

// ══════════════════════════════════════════════════════════════════════════════
// MAIN
// ══════════════════════════════════════════════════════════════════════════════

let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', c => { inputBuf += c; });
process.stdin.on('end', () => {
  let files;
  try { files = JSON.parse(inputBuf.trim()); }
  catch (e) {
    process.stderr.write('Invalid JSON input: ' + e.message + '\n');
    process.exit(1);
  }

  const result = {
    summary: {
      totalFiles:      0,
      totalLines:      0,
      totalClasses:    0,
      totalMethods:    0,
      totalFields:     0,
      totalImports:    0,
      codeLines:       0,
      commentLines:    0,
      blankLines:      0,
      totalSizeKB:     0,
      maxJavaVersion:  1,
    },
    packages:       {},
    imports:        {},
    annotations:    {},
    frameworks:     { spring: new Set(), lombok: new Set(), junit: new Set(), jakarta: new Set(), quarkus: new Set() },
    todos:          [],
    files:          [],
    topMethods:     [],
    largestFiles:   [],
    // SEMANTIC
    domainMap:      {},          // context → [files]
    security:       { vulnerabilities: [], riskFiles: [] },
    memoryLeaks:    [],
    legacyIssues:   [],
    broadcastFiles: new Set(),
    scc:            { packageCycles: [], classCycles: [], totalPackageCycles: 0, totalClassCycles: 0 },
    refactoringMap: {},          // file → { strategy, riskLevel, score }
    semanticSummary: {},
  };

  // ── Per-file analysis ──────────────────────────────────────────────────────
  for (const f of files) {
    let content;
    try { content = fs.readFileSync(f.path, 'utf8'); }
    catch { continue; }

    const fileInfo = analyseFile(f, content, result);
    result.files.push(fileInfo);
    result.summary.totalFiles++;
  }

  // ── SCC / Coupling Analysis ────────────────────────────────────────────────
  const { pkgGraph, classGraph } = buildCouplingGraphs(result.files);
  const packageSCCs  = findSCCs(pkgGraph);
  const classSCCs    = findSCCs(classGraph);

  result.scc.packageCycles        = packageSCCs;
  result.scc.classCycles          = classSCCs;
  result.scc.totalPackageCycles   = packageSCCs.length;
  result.scc.totalClassCycles     = classSCCs.length;

  // Update refactoring risk with SCC info
  const sccInfo = { packageCycles: packageSCCs.length, classCycles: classSCCs.length };
  for (const fi of result.files) {
    const risk = calcRefactoringRisk(
      fi, fi.sideEffects, [],
      { hasHighRisk: fi.legacyCount > 0, totalCount: fi.legacyCount, safeToTransform: fi.legacyCount === 0 },
      { context: fi.domain }, sccInfo
    );
    fi.refactoringRisk = risk;
    result.refactoringMap[fi.relative] = risk;
  }

  // ── Semantic Summary ───────────────────────────────────────────────────────
  const totalVulns   = result.security.vulnerabilities.length;
  const critVulns    = result.security.vulnerabilities.filter(v => v.severity === 'CRITICAL').length;
  const totalLeaks   = result.memoryLeaks.length;
  const critLeaks    = result.memoryLeaks.filter(l => l.severity === 'CRITICAL').length;
  const doNotTouch   = result.files.filter(f => f.refactoringRisk.strategy === 'DO_NOT_TOUCH').length;
  const safeFiles    = result.files.filter(f => f.refactoringRisk.strategy === 'MICROSERVICE_WRAP' || f.refactoringRisk.strategy === 'SAFE_TRANSFORM').length;
  const broadcastCnt = result.broadcastFiles.size;

  result.semanticSummary = {
    detectedJavaVersion:    result.summary.maxJavaVersion,
    totalVulnerabilities:   totalVulns,
    criticalVulnerabilities:critVulns,
    totalMemoryLeaks:       totalLeaks,
    criticalMemoryLeaks:    critLeaks,
    filesDoNotTouch:        doNotTouch,
    filesSafeToRefactor:    safeFiles,
    broadcastCriticalFiles: broadcastCnt,
    packageCycles:          packageSCCs.length,
    classCycles:            classSCCs.length,
    dominantDomain:         getDominantDomain(result.domainMap),
    overallRisk:            calcOverallRisk(totalVulns, critVulns, totalLeaks, packageSCCs.length, doNotTouch),
  };

  // Mark security risk files
  result.security.riskFiles = [...new Set(result.security.vulnerabilities.map(v => v.file))];

  // ── Sort helpers ───────────────────────────────────────────────────────────
  result.topMethods   = [...result.files].sort((a,b) => b.methods.length - a.methods.length).slice(0, 10);
  result.largestFiles = [...result.files].sort((a,b) => b.lines - a.lines).slice(0, 10);
  result.summary.totalSizeKB = +(files.reduce((s, f) => s + f.size, 0) / 1024).toFixed(2);

  // ── Serialise Sets ─────────────────────────────────────────────────────────
  result.frameworks.spring  = [...result.frameworks.spring];
  result.frameworks.lombok  = [...result.frameworks.lombok];
  result.frameworks.junit   = [...result.frameworks.junit];
  result.frameworks.jakarta = [...result.frameworks.jakarta];
  result.frameworks.quarkus = [...result.frameworks.quarkus];
  result.broadcastFiles     = [...result.broadcastFiles];

  process.stdout.write(JSON.stringify(result, null, 0) + '\n');
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function getDominantDomain(domainMap) {
  const priority = ['HARDWARE','COMPLIANCE','REALTIME','SERVER','DATA_ACCESS','CORE','API','MODEL','UTIL'];
  for (const ctx of priority) {
    if (domainMap[ctx] && domainMap[ctx].length > 0) return ctx;
  }
  return 'UNKNOWN';
}

function calcOverallRisk(vulns, critVulns, leaks, cycles, doNotTouch) {
  let score = 0;
  score += critVulns * 20;
  score += vulns     * 5;
  score += leaks     * 3;
  score += cycles    * 8;
  score += doNotTouch* 10;
  score = Math.min(score, 100);
  return score >= 70 ? 'CRITICAL' : score >= 45 ? 'HIGH' : score >= 20 ? 'MEDIUM' : 'LOW';
}


----------

neo $ cat agents/fileReader.js
#!/usr/bin/env node
/**
 * fileReader.js
 * Reads the target path from stdin (first line = path string, or raw path arg).
 * Returns JSON array of { name, path, relative, size, ext }.
 * READ-ONLY: write operations are blocked.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

// ── Read-only protection ─────────────────────────────────────────────────────
fs.writeFileSync = fs.writeFile = fs.appendFileSync = fs.appendFile =
fs.unlinkSync    = fs.unlink    = fs.rmdirSync      = fs.rmdir      =
fs.mkdirSync     = fs.mkdir     = () => { process.exit(99); };

// ── Collect stdin (Orchestrator writes the path there) ───────────────────────
let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => { inputBuf += chunk; });
process.stdin.on('end', () => {
    const targetArg = inputBuf.trim() || process.argv[2] || '.';
    const root      = path.resolve(targetArg);

    if (!fs.existsSync(root)) {
        process.stderr.write('Directory not found: ' + root + '\n');
        process.exit(1);
    }

    try {
        const files = walk(root, root);
        process.stdout.write(JSON.stringify(files, null, 0) + '\n');
    } catch (e) {
        process.stderr.write(e.message + '\n');
        process.exit(1);
    }
});

function walk(dir, root) {
    let results = [];
    const entries = fs.readdirSync(dir);

    for (const entry of entries) {
        if (entry.startsWith('.') ||
            entry === 'node_modules' || entry === 'build' ||
            entry === 'bin' || entry === 'out') continue;

        const full = path.join(dir, entry);
        let   stat;
        try { stat = fs.statSync(full); } catch { continue; }

        if (stat.isDirectory()) {
            results = results.concat(walk(full, root));
        } else if (path.extname(entry).toLowerCase() === '.java') {
            results.push({
                name:     entry,
                path:     full,
                relative: path.relative(root, full),
                size:     stat.size,
                ext:      '.java'
            });
        }
    }
    return results;
}


----------------

cat agents/mdGenerator.js
#!/usr/bin/env node
/**
 * mdGenerator.js  ─  MAXXKI SEMANTIC REPORT GENERATOR  v3.0
 * ══════════════════════════════════════════════════════════════════════════════
 * Receives payload { files, analysis, project, date }
 * Generates a professional, semantically-rich Markdown report.
 * READ-ONLY.
 * ══════════════════════════════════════════════════════════════════════════════
 */

'use strict';
const fs = require('fs');
fs.writeFileSync = fs.writeFile = () => { process.exit(99); };

let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', c => { inputBuf += c; });
process.stdin.on('end', () => {
  let payload, analysis;
  try {
    payload  = JSON.parse(inputBuf.trim());
    analysis = typeof payload.analysis === 'string' ? JSON.parse(payload.analysis) : payload.analysis;
  } catch (e) {
    process.stderr.write('Invalid input: ' + e.message + '\n');
    process.exit(1);
  }

  const s   = analysis.summary  || {};
  const sem = analysis.semanticSummary || {};
  const date    = new Date(payload.date).toLocaleString('de-DE');
  const project = payload.project || '(unknown)';

  let md = '';

  // ── TITLE ─────────────────────────────────────────────────────────────────
  md += `# MAXXKI Deep Semantic Analysis Report\n\n`;
  md += `| | |\n|---|---|\n`;
  md += `| **Project** | \`${project}\` |\n`;
  md += `| **Analysed** | ${date} |\n`;
  md += `| **Engine** | MAXXKI Deep Semantic Analyser v3.0 |\n`;
  md += `| **Java Version Detected** | Java ${sem.detectedJavaVersion || '?'} |\n`;
  md += `| **Dominant Domain** | ${sem.dominantDomain || 'UNKNOWN'} |\n`;
  md += `| **Overall Risk** | **${sem.overallRisk || '?'}** |\n\n`;
  md += `---\n\n`;

  // ── EXECUTIVE SUMMARY ────────────────────────────────────────────────────
  md += `## Executive Summary\n\n`;
  md += `| Metric | Value |\n|---|---:|\n`;
  md += `| Java Files | ${s.totalFiles || 0} |\n`;
  md += `| Total Size | ${s.totalSizeKB || 0} KB |\n`;
  md += `| Total Lines | ${s.totalLines || 0} |\n`;
  md += `| Code / Comment / Blank | ${s.codeLines||0} / ${s.commentLines||0} / ${s.blankLines||0} |\n`;
  md += `| Classes / Methods / Fields | ${s.totalClasses||0} / ${s.totalMethods||0} / ${s.totalFields||0} |\n`;
  md += `| Java Version (detected) | **${sem.detectedJavaVersion || 1}** |\n`;
  md += `| **Security Vulnerabilities** | **${sem.totalVulnerabilities||0}** (${sem.criticalVulnerabilities||0} CRITICAL) |\n`;
  md += `| **Memory Leaks Detected** | **${sem.totalMemoryLeaks||0}** (${sem.criticalMemoryLeaks||0} CRITICAL) |\n`;
  md += `| **Files: DO NOT TOUCH** | **${sem.filesDoNotTouch||0}** |\n`;
  md += `| **Files: Safe to Refactor** | **${sem.filesSafeToRefactor||0}** |\n`;
  md += `| Broadcast-Critical Files | ${sem.broadcastCriticalFiles||0} |\n`;
  md += `| Package Dependency Cycles (SCC) | ${sem.packageCycles||0} |\n`;
  md += `| Class Dependency Cycles (SCC) | ${sem.classCycles||0} |\n\n`;

  const commentRatio = s.totalLines ? ((s.commentLines / s.totalLines) * 100).toFixed(1) : 0;
  md += `> **Comment ratio:** ${commentRatio}%  |  **Overall risk:** ${sem.overallRisk || '?'}\n\n`;
  md += `---\n\n`;

  // ── DOMAIN CONTEXT MAP ───────────────────────────────────────────────────
  md += `## 1. Domain Context Map\n\n`;
  const domainMap  = analysis.domainMap || {};
  const riskColors = { HARDWARE:'🔴', COMPLIANCE:'🔴', REALTIME:'🟠', SERVER:'🟠', DATA_ACCESS:'🟡', CORE:'🟡', API:'🟢', MODEL:'🟢', UTIL:' 🟢', UNKNOWN:'⚪' };
  const strategies = { HARDWARE:'DO_NOT_TOUCH', COMPLIANCE:'DO_NOT_TOUCH', REALTIME:'ANALYZE_ONLY', SERVER:'ANALYZE_ONLY', DATA_ACCESS:'SAFE_TRANSFORM', CORE:'SAFE_TRANSFORM', API:'SAFE_TRANSFORM', MODEL:'MICROSERVICE_WRAP', UTIL:'MICROSERVICE_WRAP', UNKNOWN:'ANALYZE_ONLY' };

  if (Object.keys(domainMap).length > 0) {
    md += `| Context | Files | Risk | Strategy |\n|---|---:|---|---|\n`;
    const contextPriority = ['HARDWARE','COMPLIANCE','REALTIME','SERVER','DATA_ACCESS','CORE','API','MODEL','UTIL','UNKNOWN'];
    for (const ctx of contextPriority) {
      if (!domainMap[ctx] || domainMap[ctx].length === 0) continue;
      md += `| ${riskColors[ctx]||'⚪'} **${ctx}** | ${domainMap[ctx].length} | ${getRisk(ctx)} | \`${strategies[ctx]||'ANALYZE_ONLY'}\` |\n`;
    }
    md += '\n';

    for (const ctx of contextPriority) {
      if (!domainMap[ctx] || domainMap[ctx].length === 0) continue;
      md += `<details>\n<summary>${riskColors[ctx]||''} <strong>${ctx}</strong> – ${domainMap[ctx].length} file(s)</summary>\n\n`;
      for (const f of domainMap[ctx].sort()) md += `- \`${f}\`\n`;
      md += `\n</details>\n\n`;
    }
  } else {
    md += '_No domain context detected._\n\n';
  }
  md += `---\n\n`;

  // ── REFACTORING RISK MAP ──────────────────────────────────────────────────
  md += `## 2. Refactoring Risk Assessment\n\n`;
  const refMap = analysis.refactoringMap || {};
  const byStrategy = { DO_NOT_TOUCH: [], ANALYZE_ONLY: [], SAFE_TRANSFORM: [], MICROSERVICE_WRAP: [] };
  for (const [file, risk] of Object.entries(refMap)) {
    if (byStrategy[risk.strategy]) byStrategy[risk.strategy].push({ file, ...risk });
  }

  for (const [strat, items] of Object.entries(byStrategy)) {
    if (items.length === 0) continue;
    const icon = strat === 'DO_NOT_TOUCH' ? '🚫' : strat === 'ANALYZE_ONLY' ? '⚠️' : strat === 'SAFE_TRANSFORM' ? '✅' : '🔄';
    md += `### ${icon} ${strat} (${items.length} files)\n\n`;
    md += `| File | Risk Score | Risk Level |\n|---|---:|---|\n`;
    for (const item of items.sort((a, b) => b.score - a.score).slice(0, 20)) {
      md += `| \`${item.file}\` | ${item.score} | ${item.riskLevel} |\n`;
    }
    md += '\n';
  }
  md += `---\n\n`;

  // ── SECURITY VULNERABILITIES ─────────────────────────────────────────────
  md += `## 3. Security Vulnerabilities (Taint Flow Analysis)\n\n`;
  const vulns = (analysis.security || {}).vulnerabilities || [];
  if (vulns.length > 0) {
    md += `> ⚠️ **${vulns.length} vulnerability/ies detected** (${vulns.filter(v=>v.severity==='CRITICAL').length} CRITICAL)\n\n`;
    md += `| File | Type | Severity | Line | Recommendation |\n|---|---|---|---:|---|\n`;
    for (const v of vulns.sort((a,b) => severityOrd(b.severity) - severityOrd(a.severity))) {
      md += `| \`${v.file}\` | \`${v.type}\` | **${v.severity}** | ${v.lineNumber} | ${v.recommendation} |\n`;
    }
  } else {
    md += `_No taint-flow vulnerabilities detected._ ✅\n`;
  }
  md += `\n---\n\n`;

  // ── MEMORY LEAKS ──────────────────────────────────────────────────────────
  md += `## 4. Memory Leak Detection\n\n`;
  const leaks = analysis.memoryLeaks || [];
  if (leaks.length > 0) {
    md += `> ⚠️ **${leaks.length} potential memory leak(s)** (${leaks.filter(l=>l.severity==='CRITICAL').length} CRITICAL)\n\n`;
    md += `| File | Type | Severity | Line | Recommendation |\n|---|---|---|---:|---|\n`;
    for (const l of leaks.sort((a,b) => severityOrd(b.severity) - severityOrd(a.severity)).slice(0, 30)) {
      md += `| \`${l.location}\` | \`${l.type}\` | **${l.severity}** | ${l.lineNumber} | ${l.recommendation} |\n`;
    }
  } else {
    md += `_No memory leaks detected._ ✅\n`;
  }
  md += `\n---\n\n`;

  // ── SCC / CIRCULAR DEPENDENCIES ──────────────────────────────────────────
  md += `## 5. Coupling Analysis (Tarjan SCC)\n\n`;
  const scc = analysis.scc || {};
  if ((scc.packageCycles||[]).length > 0 || (scc.classCycles||[]).length > 0) {
    md += `> ⚠️ **Circular dependencies detected** – refactoring these packages is HIGH RISK\n\n`;
    if ((scc.packageCycles||[]).length > 0) {
      md += `### Package-Level Cycles (${scc.packageCycles.length})\n\n`;
      for (const cycle of scc.packageCycles) {
        md += `- \`${cycle.join(' ↔ ')}\`\n`;
      }
      md += '\n';
    }
    if ((scc.classCycles||[]).length > 0) {
      md += `### Class-Level Cycles (${scc.classCycles.length})\n\n`;
      for (const cycle of scc.classCycles.slice(0, 20)) {
        md += `- \`${cycle.join(' ↔ ')}\`\n`;
      }
      md += '\n';
    }
  } else {
    md += `_No circular dependencies detected._ ✅\n\n`;
  }
  md += `---\n\n`;

  // ── SIDE EFFECTS PER FILE ─────────────────────────────────────────────────
  md += `## 6. Side Effect Analysis\n\n`;
  const sideEffectFiles = (analysis.files || []).filter(f => f.sideEffects && f.sideEffects.severity !== 'NONE');
  if (sideEffectFiles.length > 0) {
    md += `| File | Severity | Risk Score | IO | Threads | DB | Buffer | Broadcast |\n|---|---|---:|---:|---:|---:|---:|---:|\n`;
    for (const f of sideEffectFiles.sort((a,b) => (b.sideEffects.riskScore||0) - (a.sideEffects.riskScore||0)).slice(0,30)) {
      const se = f.sideEffects;
      md += `| \`${f.relative}\` | **${se.severity}** | ${se.riskScore} | ${se.ioOperations?.length||0} | ${se.threadOperations?.length||0} | ${se.dbAccess?.length||0} | ${se.bufferOverflowRisks?.length||0} | ${se.broadcastSpecific?.length||0} |\n`;
    }
    md += '\n';
  } else {
    md += `_No significant side effects detected._ ✅\n\n`;
  }
  md += `---\n\n`;

  // ── LEGACY ISSUES ─────────────────────────────────────────────────────────
  md += `## 7. Legacy Code Analysis\n\n`;
  const legacyIssues = analysis.legacyIssues || [];
  if (legacyIssues.length > 0) {
    md += `| File | Issues | High Risk | Safe to Transform |\n|---|---:|---|---|\n`;
    for (const li of legacyIssues.sort((a,b) => b.totalCount - a.totalCount).slice(0,20)) {
      const types = (li.issues||[]).map(i => `\`${i.type}\``).join(', ');
      md += `| \`${li.file}\` | ${li.totalCount} | ${li.hasHighRisk ? '⚠️ Yes' : 'No'} | ${li.safeToTransform ? '✅ Yes' : '❌ No'} |\n`;
    }
    md += '\n';

    // Detail per issue type
    const byType = {};
    for (const li of legacyIssues) {
      for (const issue of (li.issues||[])) {
        if (!byType[issue.type]) byType[issue.type] = { count: 0, files: [], recommendation: issue.recommendation };
        byType[issue.type].count += issue.count;
        byType[issue.type].files.push(li.file);
      }
    }
    md += `### Legacy Issue Types\n\n`;
    md += `| Type | Count | Recommendation |\n|---|---:|---|\n`;
    for (const [type, data] of Object.entries(byType).sort((a,b) => b[1].count - a[1].count)) {
      md += `| \`${type}\` | ${data.count} | ${data.recommendation} |\n`;
    }
    md += '\n';
  } else {
    md += `_No legacy issues detected._ ✅\n\n`;
  }
  md += `---\n\n`;

  // ── BROADCAST CRITICAL FILES ──────────────────────────────────────────────
  md += `## 8. Broadcast-Critical Files\n\n`;
  const bcFiles = analysis.broadcastFiles || [];
  if (bcFiles.length > 0) {
    md += `> 🔴 These files contain broadcast-specific patterns (RS422, Timecode, Playout, GPI, SDI etc.)\n> **DO NOT TOUCH without broadcast engineering team review.**\n\n`;
    md += `| File |\n|---|\n`;
    for (const bf of bcFiles.sort()) md += `| \`${bf}\` |\n`;
    md += '\n';
  } else {
    md += `_No broadcast-specific patterns detected._\n\n`;
  }
  md += `---\n\n`;

  // ── STANDARD SECTIONS ─────────────────────────────────────────────────────
  md += `## 9. Package Structure\n\n`;
  const pkgs = analysis.packages || {};
  if (Object.keys(pkgs).length) {
    md += `| Package | Files |\n|---|---:|\n`;
    for (const [pkg, files] of Object.entries(pkgs).sort()) md += `| \`${pkg}\` | ${files.length} |\n`;
    md += '\n';
    for (const [pkg, files] of Object.entries(pkgs).sort()) {
      md += `<details>\n<summary><code>${pkg}</code> – ${files.length} file(s)</summary>\n\n`;
      for (const f of files.sort()) md += `- \`${f}\`\n`;
      md += `\n</details>\n\n`;
    }
  } else { md += '_No packages detected._\n\n'; }
  md += `---\n\n`;

  md += `## 10. Class / Interface / Enum Inventory\n\n`;
  const fileList = analysis.files || [];
  if (fileList.length) {
    md += `| File | Domain | Classes | Methods | Fields | Lines | Risk |\n|---|---|---:|---:|---:|---:|---|\n`;
    for (const f of fileList.sort((a,b)=>a.relative.localeCompare(b.relative))) {
      const classNames = f.classes.length ? f.classes.join(', ') : '—';
      md += `| \`${f.relative}\` | \`${f.domain||'?'}\` | ${classNames} | ${f.methods.length} | ${f.fields} | ${f.lines} | ${f.refactoringRisk?.riskLevel||'?'} |\n`;
    }
    md += '\n';
  }
  md += `---\n\n`;

  md += `## 11. Most Complex Files (by method count)\n\n`;
  const top = (analysis.topMethods||[]).filter(f=>f.methods.length>0);
  if (top.length) {
    md += `| Rank | File | Domain | Methods | Lines | Risk |\n|---:|---|---|---:|---:|---|\n`;
    top.forEach((f,i) => md += `| ${i+1} | \`${f.relative}\` | \`${f.domain||'?'}\` | ${f.methods.length} | ${f.lines} | ${f.refactoringRisk?.riskLevel||'?'} |\n`);
    md += '\n';
  } else { md += '_No methods found._\n\n'; }
  md += `---\n\n`;

  md += `## 12. Annotations & Frameworks\n\n`;
  const annos = analysis.annotations || {};
  const annoEntries = Object.entries(annos).sort((a,b)=>b[1]-a[1]);
  if (annoEntries.length) {
    md += `| Annotation | Count |\n|---|---:|\n`;
    for (const [k,v] of annoEntries) md += `| \`@${k}\` | ${v} |\n`;
    md += '\n';
  } else { md += '_No annotations detected._\n\n'; }

  const fw = analysis.frameworks || {};
  const fwKeys = ['spring','lombok','junit','jakarta','quarkus'];
  const detectedFW = fwKeys.filter(k => (fw[k]||[]).length > 0);
  if (detectedFW.length > 0) {
    md += `### Detected Frameworks\n\n`;
    for (const k of detectedFW) md += `- **${k.charAt(0).toUpperCase()+k.slice(1)}** – ${fw[k].length} file(s)\n`;
    md += '\n';
  }
  md += `---\n\n`;

  md += `## 13. Most Used Imports\n\n`;
  const imports = Object.entries(analysis.imports||{}).sort((a,b)=>b[1]-a[1]).slice(0,20);
  if (imports.length) {
    md += `| Package | Uses |\n|---|---:|\n`;
    for (const [k,v] of imports) md += `| \`${k}\` | ${v} |\n`;
    md += '\n';
  } else { md += '_No imports found._\n\n'; }
  md += `---\n\n`;

  md += `## 14. TODOs & FIXMEs\n\n`;
  const todos = analysis.todos || [];
  if (todos.length) {
    md += `| File | Note |\n|---|---|\n`;
    for (const t of todos) md += `| \`${t.file}\` | ${t.note.replace(/\|/g,'\\|')} |\n`;
    md += '\n';
  } else { md += '_No TODOs or FIXMEs found._ ✅\n\n'; }
  md += `---\n\n`;

  md += `*Report generated by MAXXKI Deep Semantic Analyser v3.0 — read-only, domain-aware, semantically-enriched.*\n`;

  process.stdout.write(md + '\n');
});

function getRisk(ctx) {
  const risks = { HARDWARE:'CRITICAL', COMPLIANCE:'CRITICAL', REALTIME:'HIGH', SERVER:'HIGH', DATA_ACCESS:'MEDIUM', CORE:'MEDIUM', API:'MEDIUM', MODEL:'LOW', UTIL:'VERY_LOW', UNKNOWN:'UNKNOWN' };
  return risks[ctx] || 'UNKNOWN';
}

function severityOrd(s) {
  return s === 'CRITICAL' ? 4 : s === 'HIGH' ? 3 : s === 'MEDIUM' ? 2 : s === 'LOW' ? 1 : 0;
}

---------
