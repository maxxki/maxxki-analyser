package com.maxxki.integrity;

public class ChainEntry {
    public final String entry;
    public final String hash;
    public final String prev_hash;
    public final long   timestamp;

    public ChainEntry(String entry, String hash, String prevHash, long timestamp) {
        this.entry     = entry;
        this.hash      = hash;
        this.prev_hash = prevHash;
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return String.format("ChainEntry{hash=%s..., ts=%d}", hash.substring(0, 12), timestamp);
    }
}
