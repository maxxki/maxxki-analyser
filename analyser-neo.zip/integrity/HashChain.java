package com.maxxki.integrity;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maxxki.llm.LLMClient;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;
import java.util.logging.Logger;
import java.util.stream.Stream;

/**
 * HashChain v1.1 – BLAKE3-basierte Append-Only-Integritätskette.
 *
 * Änderungen gegenüber v1.0:
 *   #3  cachedLastHash ist jetzt volatile.
 *       Vorher: Kein volatile – ohne happens-before-Garantie zwischen
 *       append() (LLM-Pool-Thread) und getLastHash() (HTTP-Handler-Thread)
 *       konnte ein Handler-Thread einen veralteten cachedLastHash lesen,
 *       was zu falschen prev_hash-Werten in der Kette führt.
 *       Fix: volatile stellt JMM-Sichtbarkeit bei jedem Cross-Thread-Zugriff sicher.
 *
 *   #4  size(): Stream wird jetzt durch try-with-resources geschlossen.
 *       Vorher: Files.lines() gibt einen Stream zurück der einen offenen
 *       Datei-Handle hält. Ohne try-with-resources blieb der Handle bei
 *       IOException offen (Resource Leak). Bei häufigen /api/llm/health
 *       Aufrufen akkumulierten sich offene File-Handles.
 *       Fix: try (Stream<String> lines = Files.lines(...)) { ... }
 */
public class HashChain {

    private static final Logger LOG = Logger.getLogger(HashChain.class.getName());

    public static final String GENESIS_HASH = "0".repeat(64);

    private final Path         chainFile;
    private final ObjectMapper mapper;

    // FIX #3: volatile – garantiert JMM-Visibility zwischen Schreib-Thread
    // (append() im LLM/Taint-Pool) und Lese-Thread (HTTP-Handler-Pool).
    // Ohne volatile: kein happens-before zwischen den Thread-Pools.
    private volatile String cachedLastHash = null;

    public HashChain(Path chainFile) {
        this.chainFile = chainFile;
        this.mapper    = new ObjectMapper();
    }

    public ChainEntry append(String entryText) throws IOException {
        ensureParentDirs();
        String     prevHash  = getLastHash();
        long       timestamp = System.currentTimeMillis();
        String     hashInput = buildChainInput(entryText, prevHash);
        String     entryHash = LLMClient.blake3Hex(hashInput);
        ChainEntry entry     = new ChainEntry(entryText, entryHash, prevHash, timestamp);
        String     jsonLine  = mapper.writeValueAsString(entry) + "\n";
        Files.write(chainFile, jsonLine.getBytes(StandardCharsets.UTF_8),
            StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        cachedLastHash = entryHash;  // volatile write – sichtbar für alle Threads
        LOG.fine("Chain appended: " + entryHash.substring(0, 12) + "...");
        return entry;
    }

    public VerificationResult verify() {
        if (!Files.exists(chainFile)) {
            return new VerificationResult(true, OptionalInt.empty(), null, null,
                "Chain file does not exist (empty chain is valid)");
        }
        String prevHash = GENESIS_HASH;
        int    idx      = 0;
        try (BufferedReader reader = Files.newBufferedReader(chainFile, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                idx++;
                JsonNode node       = mapper.readTree(line);
                String   recEntry   = node.path("entry").asText();
                String   recHash    = node.path("hash").asText();
                String   recPrevHash= node.path("prev_hash").asText();
                if (!recPrevHash.equals(prevHash)) {
                    return new VerificationResult(false, OptionalInt.of(idx),
                        prevHash, recPrevHash, "prev_hash mismatch at entry " + idx);
                }
                String expectedHash = LLMClient.blake3Hex(buildChainInput(recEntry, recPrevHash));
                if (!expectedHash.equals(recHash)) {
                    return new VerificationResult(false, OptionalInt.of(idx),
                        expectedHash, recHash, "Hash mismatch at entry " + idx);
                }
                prevHash = recHash;
            }
        } catch (IOException e) {
            return new VerificationResult(false, OptionalInt.of(idx),
                null, null, "IO error: " + e.getMessage());
        }
        cachedLastHash = prevHash.equals(GENESIS_HASH) ? null : prevHash;
        return new VerificationResult(true, OptionalInt.empty(), null, null,
            "All " + idx + " entries verified OK");
    }

    public String getLastHash() {
        // FIX #3: volatile read – immer aktueller Wert aus Haupt-Speicher
        if (cachedLastHash != null) return cachedLastHash;
        if (!Files.exists(chainFile)) return GENESIS_HASH;
        try (BufferedReader reader = Files.newBufferedReader(chainFile, StandardCharsets.UTF_8)) {
            String last = null;
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) last = line.trim();
            }
            if (last == null) return GENESIS_HASH;
            JsonNode node = mapper.readTree(last);
            cachedLastHash = node.path("hash").asText(GENESIS_HASH);
            return cachedLastHash;
        } catch (IOException e) {
            LOG.warning("Could not read last hash: " + e.getMessage());
            return GENESIS_HASH;
        }
    }

    public void export(Path output) throws IOException {
        if (!Files.exists(chainFile)) { Files.writeString(output, ""); return; }
        ensureParentDir(output);
        Files.copy(chainFile, output, StandardCopyOption.REPLACE_EXISTING);
        LOG.info("Chain exported to: " + output);
    }

    public List<ChainEntry> readAll() throws IOException {
        List<ChainEntry> entries = new ArrayList<>();
        if (!Files.exists(chainFile)) return entries;
        try (BufferedReader reader = Files.newBufferedReader(chainFile, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                JsonNode node = mapper.readTree(line);
                entries.add(new ChainEntry(
                    node.path("entry").asText(), node.path("hash").asText(),
                    node.path("prev_hash").asText(), node.path("timestamp").asLong()
                ));
            }
        }
        return entries;
    }

    /**
     * FIX #4: try-with-resources schliesst den Stream garantiert.
     * Vorher: Files.lines() Stream blieb bei IOException offen (Resource Leak).
     * Bei häufigen /api/llm/health-Aufrufen akkumulierten sich File-Handles.
     */
    public int size() {
        if (!Files.exists(chainFile)) return 0;
        try (Stream<String> lines = Files.lines(chainFile)) {
            return (int) lines.filter(l -> !l.trim().isEmpty()).count();
        } catch (IOException e) {
            return 0;
        }
    }

    private void ensureParentDirs() throws IOException { ensureParentDir(chainFile); }

    private static void ensureParentDir(Path p) throws IOException {
        Path parent = p.getParent();
        if (parent != null) Files.createDirectories(parent);
    }

    /**
     * Baut Hash-Input mit Längen-Präfix pro Segment.
     * Format: LEN:VALUE~LEN:VALUE~...
     * Konsistent mit LLMClient.buildHashInput() – kein Separator-Injection möglich.
     */
    public static String buildChainInput(String... segments) {
        StringBuilder sb = new StringBuilder();
        for (String seg : segments) {
            String s = seg != null ? seg : "";
            sb.append(s.length()).append(':').append(s).append('~');
        }
        return sb.toString();
    }
}
