package com.maxxki.integrity;

import java.util.OptionalInt;

public class VerificationResult {
    public final boolean      valid;
    public final OptionalInt  brokenAtIndex;
    public final String       expectedHash;
    public final String       actualHash;
    public final String       message;

    public VerificationResult(boolean valid, OptionalInt brokenAtIndex,
                               String expectedHash, String actualHash, String message) {
        this.valid          = valid;
        this.brokenAtIndex  = brokenAtIndex;
        this.expectedHash   = expectedHash;
        this.actualHash     = actualHash;
        this.message        = message;
    }

    @Override
    public String toString() {
        return "VerificationResult{valid=" + valid + ", msg=" + message + "}";
    }
}
