package com.maxxki.llm;

import java.util.List;

public class DiscourseResult {
    public final String               topic;
    public final List<DiscourseRound> rounds;
    public final String               consensus;
    public final String               blake3RootHash;
    public final double               averageTPS;

    public DiscourseResult(String topic, List<DiscourseRound> rounds,
                           String consensus, String blake3RootHash, double averageTPS) {
        this.topic          = topic;
        this.rounds         = rounds;
        this.consensus      = consensus;
        this.blake3RootHash = blake3RootHash;
        this.averageTPS     = averageTPS;
    }
}
