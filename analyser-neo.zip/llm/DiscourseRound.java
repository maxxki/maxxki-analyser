package com.maxxki.llm;

public class DiscourseRound {
    public final PersonaDiscourse.Persona persona;
    public final String content;
    public final double tps;
    public final String blake3Hash;
    public final int    roundNumber;
    public final double confidence;

    public DiscourseRound(PersonaDiscourse.Persona persona, String content,
                          double tps, String blake3Hash, int roundNumber, double confidence) {
        this.persona     = persona;
        this.content     = content;
        this.tps         = tps;
        this.blake3Hash  = blake3Hash;
        this.roundNumber = roundNumber;
        this.confidence  = confidence;
    }
}
