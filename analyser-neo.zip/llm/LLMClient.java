package com.maxxki.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bouncycastle.crypto.digests.Blake3Digest;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Properties;
import java.util.concurrent.*;
import java.util.logging.Logger;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicReference;

/**
 * LLMClient v1.1 – HTTP-Client für llama.cpp-Server (OpenAI-kompatibel).
 *
 * Änderungen gegenüber v1.0:
 *   #7  blake3Hex(): Blake3Digest-Konstruktor-Argument korrigiert.
 *       Vorher: new Blake3Digest(256) → Bouncy Castle interpretiert das als
 *       256-Byte Output-Länge, nicht 256 Bit. Der nachfolgende byte[32]-Buffer
 *       hätte nur die ersten 32 von 256 Bytes des Digests erfasst und
 *       doFinal() hätte möglicherweise eine ArrayIndexOutOfBoundsException
 *       oder inkonsistente Hash-Werte produziert.
 *       Fix: new Blake3Digest(32) → 32 Bytes = 256 Bit Ausgabe.
 *       Der byte[32]-Buffer und die Konstruktor-Angabe stimmen jetzt überein.
 *
 * Unveränderte Features:
 * · Async mit CompletableFuture (Timeout konfigurierbar)
 * · Retry-Logic: max 3 Versuche, Exponential Backoff
 * · TPS-Messung (Tokens per Second)
 * · BLAKE3-Hash jeder Response – Längen-Präfix (kein Separator-Injection)
 * · Healthcheck-Endpunkt
 * · Fallback: gibt null zurück wenn LLM nicht erreichbar
 */
public class LLMClient {

    private static final Logger LOG = Logger.getLogger(LLMClient.class.getName());

    private final HttpClient   httpClient;
    private final ObjectMapper mapper;
    private final String       endpoint;
    private final String       model;
    private final double       temperature;
    private final int          maxTokens;
    private final int          timeoutSeconds;
    private final int          retryAttempts;
    private final boolean      enabled;

    // Per-call state (Atomic-Referenzen für thread-safe Lesezugriff)
    private final AtomicReference<Double> lastTPS       = new AtomicReference<>(0.0);
    private final AtomicReference<String> lastHash      = new AtomicReference<>("0".repeat(64));
    private final AtomicInteger           lastTokens    = new AtomicInteger(0);
    private final AtomicLong              lastLatencyMs = new AtomicLong(0);

    // ── Constructor ────────────────────────────────────────────────────────────

    public LLMClient(Properties props) {
        this.enabled        = Boolean.parseBoolean(props.getProperty("llm.enabled",          "true"));
        this.endpoint       = props.getProperty("llm.url",               "http://127.0.0.1:8080");
        this.model          = props.getProperty("llm.model",             "llama-3.2-3b-instruct");
        this.temperature    = Double.parseDouble(props.getProperty("llm.temperature",         "0.4"));
        this.maxTokens      = Integer.parseInt(  props.getProperty("llm.max_tokens",          "350"));
        this.timeoutSeconds = Integer.parseInt(  props.getProperty("llm.timeout_seconds",     "30"));
        this.retryAttempts  = Integer.parseInt(  props.getProperty("llm.retry_attempts",      "3"));

        this.mapper = new ObjectMapper();
        this.httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    }

    // ── Core: chat() ───────────────────────────────────────────────────────────

    public LLMResponse chat(String systemPrompt, String userPrompt) {
        if (!enabled) {
            LOG.warning("LLM disabled – skipping call.");
            return null;
        }

        for (int attempt = 1; attempt <= retryAttempts; attempt++) {
            try {
                return chatAttempt(systemPrompt, userPrompt, attempt);
            } catch (TimeoutException e) {
                LOG.warning("LLM timeout (attempt " + attempt + "/" + retryAttempts + ")");
            } catch (Exception e) {
                LOG.warning("LLM error (attempt " + attempt + "/" + retryAttempts + "): " + e.getMessage());
            }

            if (attempt < retryAttempts) {
                long backoff = (long) (Math.pow(2, attempt) * 1000);
                try { Thread.sleep(backoff); } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        LOG.severe("LLM: all " + retryAttempts + " attempts failed.");
        return null;
    }

    private LLMResponse chatAttempt(String systemPrompt, String userPrompt, int attempt)
            throws Exception {

        String requestBody = buildRequestBody(systemPrompt, userPrompt);

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(endpoint + "/v1/chat/completions"))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(requestBody, StandardCharsets.UTF_8))
            .timeout(Duration.ofSeconds(timeoutSeconds))
            .build();

        Instant start = Instant.now();

        CompletableFuture<HttpResponse<String>> future = httpClient
            .sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

        HttpResponse<String> response = future.get(timeoutSeconds + 2L, TimeUnit.SECONDS);

        long latencyMs = Duration.between(start, Instant.now()).toMillis();

        if (response.statusCode() != 200) {
            String snippet = response.body();
            if (snippet.length() > 120) snippet = snippet.substring(0, 120) + "…";
            throw new IOException("HTTP " + response.statusCode() + ": " + snippet);
        }

        return parseResponse(response.body(), latencyMs);
    }

    /**
     * Parst die JSON-Response und berechnet TPS + BLAKE3-Hash.
     * Hash-Input verwendet Längen-Präfix (konsistent mit HashChain.buildChainInput).
     */
    private LLMResponse parseResponse(String body, long latencyMs) throws Exception {
        JsonNode root    = mapper.readTree(body);
        JsonNode choices = root.path("choices");

        if (choices.isEmpty()) {
            throw new IOException("Empty choices in LLM response");
        }

        String content = choices.get(0).path("message").path("content").asText("").trim();

        int tokens = root.path("usage").path("completion_tokens").asInt(0);
        if (tokens == 0) tokens = content.split("\\s+").length;

        double tps = latencyMs > 0 ? (tokens * 1000.0 / latencyMs) : 0.0;
        tps = Math.round(tps * 100.0) / 100.0;

        String hashInput  = buildHashInput(content, String.valueOf(tps), String.valueOf(latencyMs));
        String blake3Hash = blake3Hex(hashInput);

        this.lastTPS.set(tps);
        this.lastHash.set(blake3Hash);
        this.lastTokens.set(tokens);
        this.lastLatencyMs.set(latencyMs);

        return new LLMResponse(content, tps, tokens, blake3Hash, latencyMs);
    }

    /**
     * Baut Hash-Input mit Längen-Präfix pro Segment.
     * Format: LEN:VALUE~LEN:VALUE~...
     * Identisch mit HashChain.buildChainInput() – kein Separator-Injection möglich.
     */
    private static String buildHashInput(String... segments) {
        StringBuilder sb = new StringBuilder();
        for (String seg : segments) {
            String s = seg != null ? seg : "";
            sb.append(s.length()).append(':').append(s).append('~');
        }
        return sb.toString();
    }

    private String buildRequestBody(String systemPrompt, String userPrompt) {
        return "{" +
            "\"model\":"       + jsonStr(model)       + "," +
            "\"temperature\":" + temperature          + "," +
            "\"max_tokens\":"  + maxTokens            + "," +
            "\"messages\":["   +
                "{\"role\":\"system\",\"content\":" + jsonStr(systemPrompt) + "}," +
                "{\"role\":\"user\",\"content\":"   + jsonStr(userPrompt)   + "}" +
            "]}";
    }

    // ── Healthcheck ───────────────────────────────────────────────────────────

    public boolean isHealthy() {
        if (!enabled) return false;
        try {
            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(endpoint + "/health"))
                .GET()
                .timeout(Duration.ofSeconds(3))
                .build();
            HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
            return resp.statusCode() == 200;
        } catch (Exception e) {
            return false;
        }
    }

    // ── BLAKE3 ─────────────────────────────────────────────────────────────────

    /**
     * Berechnet den BLAKE3-256-Hash des Eingabe-Strings.
     *
     * FIX #7: Blake3Digest(32) statt Blake3Digest(256).
     * Bouncy Castle's Blake3Digest-Konstruktor erwartet die Output-Länge in BYTES.
     * Blake3Digest(256) hätte 256 Byte (2048 Bit) Ausgabe erzeugt, nicht 256 Bit.
     * Mit byte[32] als Output-Buffer hätte doFinal() nur 32 der 256 Bytes
     * geschrieben – kein konsistenter 256-Bit-Hash.
     * Fix: Blake3Digest(32) → 32 Bytes = 256 Bit, stimmt mit byte[32] überein.
     */
    public static String blake3Hex(String input) {
        // FIX #7: 32 (Bytes) statt 256 (fälschlicherweise als Bytes interpretiert)
        Blake3Digest digest = new Blake3Digest(32);
        byte[]       data   = input.getBytes(StandardCharsets.UTF_8);
        digest.update(data, 0, data.length);
        byte[] out = new byte[32];
        digest.doFinal(out, 0);
        StringBuilder sb = new StringBuilder(64);
        for (byte b : out) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public double  getLastTPS()       { return lastTPS.get(); }
    public String  getLastHash()      { return lastHash.get(); }
    public int     getLastTokens()    { return lastTokens.get(); }
    public long    getLastLatencyMs() { return lastLatencyMs.get(); }
    public String  getModel()         { return model; }
    public boolean isEnabled()        { return enabled; }

    // ── JSON-Escape Utility ───────────────────────────────────────────────────

    private static String jsonStr(String s) {
        if (s == null) return "null";
        return "\"" + s
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
            + "\"";
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// VALUE OBJECTS
// ══════════════════════════════════════════════════════════════════════════════

class LLMResponse {
    public final String content;
    public final double tps;
    public final int    tokens;
    public final String blake3Hash;
    public final long   latencyMs;

    public LLMResponse(String content, double tps, int tokens, String blake3Hash, long latencyMs) {
        this.content    = content;
        this.tps        = tps;
        this.tokens     = tokens;
        this.blake3Hash = blake3Hash;
        this.latencyMs  = latencyMs;
    }

    @Override
    public String toString() {
        return String.format("LLMResponse{tps=%.2f, tokens=%d, latency=%dms, hash=%s...}",
            tps, tokens, latencyMs, blake3Hash.substring(0, 12));
    }
}
