package com.maxxki.llm;

public class LLMJudge {
    public final PersonaDiscourse.Persona persona;
    public final String  judgement;
    public final double  confidence;
    public final String  blake3Hash;
    public final double  tps;

    public LLMJudge(PersonaDiscourse.Persona persona, String judgement,
                    double confidence, String blake3Hash, double tps) {
        this.persona    = persona;
        this.judgement  = judgement;
        this.confidence = confidence;
        this.blake3Hash = blake3Hash;
        this.tps        = tps;
    }

    public boolean isConfident(double threshold) {
        return confidence >= threshold;
    }

    @Override
    public String toString() {
        return String.format("LLMJudge{%s, conf=%.2f, tps=%.1f, hash=%s...}",
            persona.name(), confidence, tps, blake3Hash.substring(0, 12));
    }
}
