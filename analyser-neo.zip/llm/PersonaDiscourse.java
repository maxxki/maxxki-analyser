package com.maxxki.llm;

import com.maxxki.integrity.ChainEntry;
import com.maxxki.integrity.HashChain;

import java.util.*;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * PersonaDiscourse v2.2 – Kontextadaptiver LLM-Diskurs
 *
 * Änderungen gegenüber v2.1:
 *   #6  quickJudge(): vulnType wird jetzt durch sanitizeForPrompt() geschleust,
 *       bevor er in den Prompt eingebettet wird. Vorher: vulnType wurde direkt
 *       konkateniert – ein Angreifer konnte über den type-Parameter des
 *       /api/llm/analyze-Endpunkts Prompt-Injection-Payloads injizieren.
 *
 * Unveränderte Fixes aus v2.1:
 *   #7  extractConfidence() – nur "Confidence: X.X" in den letzten 3 Zeilen
 *   #8  sanitizeForPrompt() – Unicode-BiDi-Overrides, Zero-Width-Chars
 *   #11 containsFpKeywords() – erweitert um weitere FP-Muster
 */
public class PersonaDiscourse {

    private static final Logger LOG = Logger.getLogger(PersonaDiscourse.class.getName());

    // ══════════════════════════════════════════════════════════════════════════
    // PERSONAS
    // ══════════════════════════════════════════════════════════════════════════

    private static final String SHARED_RULES =
        "Max 2 sentences. No lists, no markdown, no headers. " +
        "Start directly with your finding. Do not repeat previous statements. " +
        "End your response with exactly: Confidence: X.X (e.g. Confidence: 0.8)";

    public enum Persona {

        DOMINUS("Red-Team Attacker",
            SHARED_RULES + "\n\n" +
            "You are a red-team attacker. Your goal: find ONE concrete, exploitable attack vector " +
            "that an attacker could use TODAY. Be specific: name the entry point, the payload type, " +
            "and the immediate impact. If you cannot find a realistic attack, state that clearly. " +
            "Bias toward actionable findings over theoretical concerns."),

        AXIOM("Forensic Context Analyst",
            SHARED_RULES + "\n\n" +
            "You are a forensic code analyst. Your goal: add ONE specific technical detail " +
            "about the CODE CONTEXT that changes the severity assessment. " +
            "Focus on: Is the sink reachable from user input? Is there sanitization upstream? " +
            "Are there mitigating factors (authentication, input constraints, framework defaults)? " +
            "Your job is to reduce false positives with evidence from the code structure."),

        CIPHER("Analysis Critic",
            SHARED_RULES + "\n\n" +
            "You are a rigorous security analysis critic. Your goal: find ONE specific flaw " +
            "in the PREVIOUS STATEMENT. Challenge assumptions. If the previous persona claimed " +
            "a vulnerability is exploitable, find why it might not be. If they said it's a false positive, " +
            "find the scenario where it IS exploitable. Be precise about what evidence is missing."),

        VECTOR("Remediation Strategist",
            SHARED_RULES + "\n\n" +
            "You are a remediation engineer. Your goal: name ONE specific, immediately applicable fix. " +
            "Not generic advice like 'use prepared statements' – give the exact API, method, " +
            "library class, or configuration parameter. Example: " +
            "'Replace with PreparedStatement ps = conn.prepareStatement(\"SELECT id FROM users WHERE name=?\"); ps.setString(1, input);' " +
            "Be concrete and implementation-specific.");

        public final String role;
        public final String systemPrompt;

        Persona(String role, String systemPrompt) {
            this.role         = role;
            this.systemPrompt = systemPrompt;
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // VULN-TYP-KONTEXT-BUILDER
    // ══════════════════════════════════════════════════════════════════════════

    private static final Map<String, String> VULN_BRIEFINGS;
    static {
        Map<String, String> m = new LinkedHashMap<>();
        m.put("SQL_INJECTION",
            "This is a potential SQL injection finding. Key questions: " +
            "Is the query built by string concatenation? Does a PreparedStatement exist nearby? " +
            "Is the tainted value validated or typed before use (e.g. parsed as int)? " +
            "What is the database context (read-only user, stored proc, ORM layer)?");
        m.put("XSS",
            "This is a potential Cross-Site Scripting finding. Key questions: " +
            "Is the output written to an HTTP response or a template? " +
            "Is the Content-Type set to text/html? Does a framework (Spring, JAX-RS) " +
            "auto-encode outputs? Is this reflected, stored, or DOM-based XSS?");
        m.put("PATH_TRAVERSAL",
            "This is a potential path traversal finding. Key questions: " +
            "Is the path resolved against a fixed base directory? " +
            "Is there a startsWith() check after path.toRealPath()? " +
            "Can the user inject ../ sequences? Is the file system access read or write?");
        m.put("COMMAND_INJECTION",
            "This is a potential command injection finding. Key questions: " +
            "Is Runtime.exec called with a String (dangerous) or String[] (safer)? " +
            "Is the user input validated against a whitelist before use? " +
            "Can the shell be invoked (sh -c / cmd /c)? What is the OS context?");
        m.put("XXE",
            "This is a potential XML External Entity (XXE) finding. Key questions: " +
            "Is setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true) set? " +
            "Is external entity resolution disabled? Is this a SAX, DOM, or StAX parser? " +
            "Is the XML coming from an untrusted source or only internal configs?");
        m.put("LDAP_INJECTION",
            "This is a potential LDAP injection finding. Key questions: " +
            "Is the LDAP filter built from raw user input? " +
            "Are special characters (*, (, ), \\, NUL) escaped? " +
            "Is there a whitelist for valid LDAP attributes? What is the LDAP server's write access?");
        m.put("HARDCODED_SECRET",
            "This is a potential hardcoded secret finding. Key questions: " +
            "Is the value actually a secret (password, token, key) or a placeholder/test value? " +
            "Is it in production code or a test class? " +
            "Is it version-controlled (git)? What is the exposure risk?");
        m.put("INSECURE_RANDOM",
            "This is a potential insecure randomness finding. Key questions: " +
            "Is java.util.Random used for a security-critical purpose (token, session ID, key)? " +
            "Or is it for non-security simulation/testing? " +
            "What is the predictability window given the seed?");
        m.put("WEAK_CRYPTOGRAPHY",
            "This is a weak cryptography finding. Key questions: " +
            "Is MD5/SHA-1 used for password hashing (critical) or data integrity (less critical)? " +
            "Is there a salt? Is it a single hash or iterated? " +
            "What data is being protected and what is the threat model?");
        VULN_BRIEFINGS = Collections.unmodifiableMap(m);
    }

    private String buildVulnContext(String vulnType, String code, String file, int lineNumber) {
        String briefing = VULN_BRIEFINGS.getOrDefault(vulnType,
            "Analyze this potential security vulnerability carefully.");

        return "=== SECURITY ANALYSIS REQUEST ===\n" +
               "Vulnerability Type: " + sanitizeForPrompt(vulnType) + "\n" +
               "File: " + sanitizeForPrompt(file) + "\n" +
               "Line: " + lineNumber + "\n" +
               "Code snippet:\n" + sanitizeForPrompt(truncate(code, 400)) + "\n\n" +
               "Context: " + briefing + "\n" +
               "=================================";
    }

    // ══════════════════════════════════════════════════════════════════════════
    // STATE
    // ══════════════════════════════════════════════════════════════════════════

    private final LLMClient llm;
    private final HashChain chain;

    public PersonaDiscourse(LLMClient llm, HashChain chain) {
        this.llm   = llm;
        this.chain = chain;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // PUBLIC API
    // ══════════════════════════════════════════════════════════════════════════

    public DiscourseResult runDiscourse(String topic, int rounds) throws Exception {
        if (!llm.isEnabled()) {
            LOG.warning("LLM disabled.");
            return emptyDiscourse(topic);
        }

        List<DiscourseRound> discourseRounds = new ArrayList<>();
        Persona[]            personas        = Persona.values();
        String               lastAnswer      = sanitizeForPrompt(topic);
        double               totalTps        = 0;
        int                  tpsCount        = 0;
        int                  actualRounds    = Math.min(rounds, personas.length);

        for (int i = 0; i < actualRounds; i++) {
            Persona persona = personas[i % personas.length];
            LOG.info("Discourse round " + (i + 1) + " – " + persona.name());

            String userPrompt = (persona == Persona.AXIOM)
                ? "Topic: " + sanitizeForPrompt(topic) + "\n\nPrevious finding:\n" + lastAnswer
                : lastAnswer;

            LLMResponse response = llm.chat(persona.systemPrompt, userPrompt);
            if (response == null) {
                LOG.warning("No response from " + persona.name() + " – skipping round");
                continue;
            }

            String answer = cleanAnswer(response.content);

            if (isTooSimilar(answer, lastAnswer)) {
                LOG.fine("Response too similar – requesting new angle from " + persona.name());
                response = llm.chat(persona.systemPrompt,
                    userPrompt + "\n\nIMPORTANT: Provide a completely different perspective. " +
                    "Do not repeat any point already made.");
                if (response != null) {
                    answer = cleanAnswer(response.content);
                } else {
                    continue;
                }
            }

            double     confidence = extractConfidence(answer);
            ChainEntry ce         = chain.append(buildChainInput("Discourse", persona.name(), topic, answer));
            discourseRounds.add(new DiscourseRound(persona, answer, response.tps, ce.hash, i + 1, confidence));
            lastAnswer = answer;
            totalTps  += response.tps;
            tpsCount++;
        }

        String consensus = buildConsensus(discourseRounds, topic);
        double avgTps    = tpsCount > 0 ? totalTps / tpsCount : 0.0;
        String rootHash  = discourseRounds.isEmpty()
            ? HashChain.GENESIS_HASH
            : discourseRounds.get(discourseRounds.size() - 1).blake3Hash;

        return new DiscourseResult(topic, discourseRounds, consensus, rootHash, avgTps);
    }

    public List<LLMJudge> deepAnalyze(String vulnType, String code, String file, int lineNumber) throws Exception {
        List<LLMJudge> judges = new ArrayList<>();
        if (!llm.isEnabled()) {
            LOG.warning("LLM disabled.");
            return judges;
        }

        String vulnContext = buildVulnContext(vulnType, code, file, lineNumber);
        String lastAnswer  = vulnContext;

        for (Persona persona : Persona.values()) {
            String systemPrompt = persona.systemPrompt + "\n\n" +
                "ADDITIONAL TASK: After your analysis, conclude with exactly:\n" +
                "VERDICT: REAL  – if this is a confirmed, exploitable vulnerability\n" +
                "VERDICT: FALSE POSITIVE  – if this is not actually exploitable\n" +
                "VERDICT: UNCERTAIN  – if more context is needed\n" +
                "Then: Confidence: X.X";

            LLMResponse response = llm.chat(systemPrompt, lastAnswer);
            if (response == null) {
                LOG.warning("No response from " + persona.name() + " – skipping");
                continue;
            }

            String answer     = cleanAnswer(response.content);
            double confidence = extractConfidence(answer);
            String verdict    = extractVerdict(answer);

            if (verdict.equals("UNCERTAIN") && confidence >= 0.75) verdict = "REAL";
            if (verdict.equals("UNCERTAIN") && confidence <= 0.3)  verdict = "FALSE POSITIVE";

            ChainEntry ce = chain.append(buildChainInput("Analysis", persona.name(), vulnType, verdict + "|" + answer));
            judges.add(new LLMJudge(persona, verdict + ": " + answer, confidence, ce.hash, response.tps));
            lastAnswer = answer;
        }
        return judges;
    }

    public List<LLMJudge> deepAnalyze(String vulnType, String code, String codeContext) throws Exception {
        return deepAnalyze(vulnType, code, codeContext, 0);
    }

    /**
     * Schnelle Einzelbeurteilung einer möglichen Schwachstelle.
     *
     * FIX #6: vulnType wird durch sanitizeForPrompt() geschleust bevor er in den
     * Prompt eingebettet wird. Vorher: direktes String-Concat ermöglichte
     * Prompt-Injection über den type-Parameter des /api/llm/analyze Endpunkts.
     */
    public LLMJudge quickJudge(String vulnType, String code) throws Exception {
        if (!llm.isEnabled()) return null;

        // FIX #6: Sanitize vulnType – verhindert Prompt-Injection
        String safeVulnType = sanitizeForPrompt(vulnType);
        String briefing     = VULN_BRIEFINGS.getOrDefault(vulnType, "");

        String prompt =
            "=== QUICK SECURITY VERDICT ===\n" +
            "Vulnerability Type: " + safeVulnType + "\n" +
            "Code:\n" + sanitizeForPrompt(truncate(code, 300)) + "\n\n" +
            (briefing.isEmpty() ? "" : "Background: " + briefing + "\n\n") +
            "Task: Determine if this is a REAL vulnerability or a FALSE POSITIVE.\n" +
            "Response format:\n" +
            "  Line 1: VERDICT: REAL  or  VERDICT: FALSE POSITIVE  or  VERDICT: UNCERTAIN\n" +
            "  Line 2: One sentence explanation.\n" +
            "  Line 3: Confidence: X.X";

        LLMResponse response = llm.chat(Persona.DOMINUS.systemPrompt, prompt);
        if (response == null) return null;

        String answer     = cleanAnswer(response.content);
        double confidence = extractConfidence(answer);
        String verdict    = extractVerdict(answer);

        if (verdict.equals("UNCERTAIN") && confidence >= 0.75) verdict = "REAL";
        if (verdict.equals("UNCERTAIN") && confidence <= 0.3)  verdict = "FALSE POSITIVE";

        ChainEntry ce = chain.append(buildChainInput("QuickJudge", vulnType, verdict, answer));
        return new LLMJudge(Persona.DOMINUS, verdict + ": " + answer, confidence, ce.hash, response.tps);
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SECURITY: CHAIN INPUT BUILDER
    // ══════════════════════════════════════════════════════════════════════════

    private static String buildChainInput(String... segments) {
        StringBuilder sb = new StringBuilder();
        for (String seg : segments) {
            String s = seg != null ? seg : "";
            sb.append(s.length()).append(':').append(s).append('~');
        }
        return sb.toString();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // VERDICT PARSING
    // ══════════════════════════════════════════════════════════════════════════

    private String extractVerdict(String text) {
        if (text == null || text.isEmpty()) return "UNCERTAIN";

        String[] lines = text.strip().split("\\r?\\n", 4);
        for (int i = 0; i < Math.min(3, lines.length); i++) {
            String line = lines[i].toUpperCase().trim();

            if (line.startsWith("VERDICT:")) {
                String rest = line.substring("VERDICT:".length()).trim();
                if (rest.startsWith("REAL"))           return "REAL";
                if (rest.startsWith("FALSE POSITIVE"))  return "FALSE POSITIVE";
                if (rest.startsWith("UNCERTAIN"))       return "UNCERTAIN";
            }

            if (line.startsWith("REAL") && !containsFpKeywords(line)) return "REAL";
            if (line.startsWith("FALSE POSITIVE"))                     return "FALSE POSITIVE";
        }

        return "UNCERTAIN";
    }

    private boolean containsFpKeywords(String line) {
        return line.contains("NOT REAL")                    ||
               line.contains("NOT A REAL")                  ||
               line.contains("REAL VULNERABILITY DOES NOT") ||
               line.contains("NO REAL")                     ||
               line.contains("NOT ACTUALLY REAL")           ||
               line.contains("NOT EXPLOITABLE")             ||
               line.contains("REAL? NO");
    }

    // ══════════════════════════════════════════════════════════════════════════
    // CONFIDENCE PARSING
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Extrahiert den Confidence-Wert aus dem LLM-Output.
     * Nur "Confidence: X.X" in den letzten 3 Zeilen wird akzeptiert.
     * Alle heuristischen Keyword-Strategien wurden entfernt (v2.1 #7).
     */
    private double extractConfidence(String text) {
        if (text == null || text.isEmpty()) return 0.5;

        String[] lines = text.split("\\r?\\n");
        for (int i = Math.max(0, lines.length - 3); i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.toLowerCase().startsWith("confidence:")) {
                String  valStr = line.substring("confidence:".length()).trim();
                Matcher m      = Pattern.compile("^(\\d+\\.?\\d*)").matcher(valStr);
                if (m.find()) {
                    double v = parseAndNormalizeConfidence(m.group(1));
                    if (v >= 0.0) return v;
                }
            }
        }

        return 0.5;
    }

    private double parseAndNormalizeConfidence(String val) {
        try {
            double v = Double.parseDouble(val);
            if (v > 1.0 && v <= 100.0) v = v / 100.0;
            if (v >= 0.0 && v <= 1.0)  return Math.round(v * 100.0) / 100.0;
        } catch (NumberFormatException ignored) {}
        return -1.0;
    }

    // ══════════════════════════════════════════════════════════════════════════
    // SANITIZATION
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Säubert LLM-Output / User-Input vor der Weiterverwendung.
     * Entfernt Steuerzeichen, BiDi-Overrides, Zero-Width-Chars, Log-Injection-Muster.
     */
    private static String sanitizeForPrompt(String input) {
        if (input == null) return "";
        // Standard-Steuerzeichen entfernen (außer \n=0x0A, \t=0x09)
        String s = input.replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F\\x7F]", "");
        // Unicode-Bidirectional-Overrides und unsichtbare Markierungen entfernen
        s = s.replaceAll("[\\u200E\\u200F\\u202A-\\u202E\\uFEFF]", "");
        // Zero-Width-Characters entfernen
        s = s.replaceAll("[\\u200B\\u200C\\u200D\\u2060]", "");
        // Mehr als 3 aufeinanderfolgende Newlines kollabieren
        s = s.replaceAll("(\r?\n){3,}", "\n\n");
        // Log-Injection-Muster unterbinden
        s = s.replaceAll("(?m)^\\d{4}-\\d{2}-\\d{2}\\s+\\w+:", "[FILTERED]");
        // Länge begrenzen
        if (s.length() > 2000) s = s.substring(0, 2000) + "…";
        return s.trim();
    }

    // ══════════════════════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════════════════════

    private String cleanAnswer(String text) {
        if (text == null) return "";
        text = text.replaceAll("</?[biu]>", "");
        text = text.replaceAll("\\*\\*(.*?)\\*\\*", "$1");
        text = text.replaceAll("\\*(.*?)\\*", "$1");
        text = text.replaceAll("#{1,6}\\s*", "");
        text = text.replaceAll("```\\w*\\n?", "");
        text = text.replaceAll("```", "");
        text = sanitizeForPrompt(text);
        String[] words = text.split("\\s+");
        if (words.length > 300) text = String.join(" ", Arrays.copyOf(words, 300)) + "…";
        return text.trim();
    }

    private boolean isTooSimilar(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty()) return false;
        Set<String> wA = new HashSet<>(Arrays.asList(a.toLowerCase().split("\\s+")));
        Set<String> wB = new HashSet<>(Arrays.asList(b.toLowerCase().split("\\s+")));
        Set<String> intersection = new HashSet<>(wA);
        intersection.retainAll(wB);
        int maxSize = Math.max(wA.size(), wB.size());
        return maxSize > 0 && (double) intersection.size() / maxSize > 0.70;
    }

    private String buildConsensus(List<DiscourseRound> rounds, String topic) {
        if (rounds.isEmpty()) return "No consensus – no rounds completed.";
        StringBuilder sb = new StringBuilder("Security Analysis Consensus\nTopic: ")
            .append(sanitizeForPrompt(topic)).append("\n\n");
        for (DiscourseRound r : rounds) {
            String excerpt = r.content.length() > 150
                ? r.content.substring(0, 150) + "…"
                : r.content;
            sb.append(String.format("[%s / %s | conf=%.2f]\n%s\n\n",
                r.persona.name(), r.persona.role, r.confidence, excerpt));
        }
        return sb.toString();
    }

    private DiscourseResult emptyDiscourse(String topic) {
        return new DiscourseResult(topic, new ArrayList<>(), "LLM disabled", HashChain.GENESIS_HASH, 0.0);
    }

    private static String truncate(String s, int maxLen) {
        return (s != null && s.length() > maxLen) ? s.substring(0, maxLen) + "…" : (s != null ? s : "");
    }

    @SuppressWarnings("unused")
    private static boolean containsAny(String text, String... tokens) {
        for (String t : tokens) if (text.contains(t)) return true;
        return false;
    }
}
