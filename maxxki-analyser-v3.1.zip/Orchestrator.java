import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.maxxki.integrity.ChainEntry;
import com.maxxki.integrity.HashChain;
import com.maxxki.integrity.VerificationResult;
import com.maxxki.llm.*;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.logging.Logger;

/**
 * Orchestrator v3.1 – MAXXKI Deep Semantic Analyser + LLM Extension
 *
 * Bestehende Endpoints (unverändert):
 *   GET /api/analyse?path=<dir>   – Node.js-Agenten Pipeline
 *   GET /api/health               – Basis-Healthcheck
 *   GET /                         – Frontend
 *
 * Neue LLM-Endpoints (additiv):
 *   POST /api/llm/analyze         – Einzelne Vulnerability analysieren
 *   POST /api/llm/discourse       – Vollständiger 4-Persona-Diskurs
 *   GET  /api/llm/health          – LLM + Chain Status
 *   GET  /api/llm/export          – Hash-Kette exportieren
 *
 * Fallback: Wenn LLM nicht verfügbar → normale MAXXKI-Analyse läuft weiter.
 */
public class Orchestrator {

    private static final Logger LOG = Logger.getLogger(Orchestrator.class.getName());

    // ── Existing constants (unchanged) ───────────────────────────────────────
    static final String AGENTS_DIR  = Paths.get("").toAbsolutePath() + "/agents";
    static final String OUTPUT_DIR  = "output";
    static final int    TIMEOUT_SEC = 120;
    static final int    DEFAULT_PORT= 7070;

    // ── LLM components ────────────────────────────────────────────────────────
    private static LLMClient        llmClient;
    private static HashChain        hashChain;
    private static PersonaDiscourse discourse;
    private static ObjectMapper     mapper = new ObjectMapper();

    // ── Confidence threshold for false-positive filtering ────────────────────
    private static double CONFIDENCE_THRESHOLD = 0.7;

    // ── main() ────────────────────────────────────────────────────────────────

    public static void main(String[] args) throws Exception {
        Properties props = loadProperties();
        initLLMComponents(props);

        if (args.length > 0 && args[0].equals("--server")) {
            int port = (args.length > 1) ? Integer.parseInt(args[1]) : DEFAULT_PORT;
            startServer(port);
            return;
        }
        String target = (args.length > 0) ? args[0] : "target";
        System.out.println("\n" + "=".repeat(52));
        System.out.println("  MAXXKI Deep Semantic Analyser – CLI");
        System.out.println("=".repeat(52));
        String result = runPipeline(target);
        System.out.println(result);
    }

    // ── Initialization ────────────────────────────────────────────────────────

    static Properties loadProperties() {
        Properties props = new Properties();
        // Default values
        props.setProperty("llm.enabled",         "false");
        props.setProperty("llm.url",              "http://127.0.0.1:8080");
        props.setProperty("llm.model",            "llama-3.2-3b-instruct");
        props.setProperty("llm.temperature",      "0.4");
        props.setProperty("llm.max_tokens",       "350");
        props.setProperty("llm.timeout_seconds",  "30");
        props.setProperty("llm.retry_attempts",   "3");
        props.setProperty("blake3.chain.path",    "hashes/chain.jsonl");
        props.setProperty("discourse.default_rounds", "4");

        Path configPath = Paths.get("config/maxxki.properties");
        if (Files.exists(configPath)) {
            try (InputStream in = Files.newInputStream(configPath)) {
                props.load(in);
                LOG.info("Loaded config: " + configPath);
            } catch (IOException e) {
                LOG.warning("Could not load maxxki.properties: " + e.getMessage());
            }
        } else {
            LOG.info("No config/maxxki.properties found – using defaults (LLM disabled).");
        }
        return props;
    }

    static void initLLMComponents(Properties props) {
        llmClient = new LLMClient(props);
        hashChain = new HashChain(Paths.get(props.getProperty("blake3.chain.path")));
        discourse = new PersonaDiscourse(llmClient, hashChain);

        // Verify chain on startup if configured
        if (Boolean.parseBoolean(props.getProperty("blake3.chain.verify_on_start", "true"))) {
            VerificationResult vr = hashChain.verify();
            if (vr.valid) {
                LOG.info("[chain] Integrity OK – " + vr.message);
            } else {
                LOG.severe("[chain] INTEGRITY BROKEN! " + vr.message);
            }
        }

        CONFIDENCE_THRESHOLD = Double.parseDouble(props.getProperty("llm.confidence_threshold", "0.7"));
        LOG.info("LLM enabled: " + llmClient.isEnabled());
    }

    // ── Server ────────────────────────────────────────────────────────────────

    static void startServer(int port) throws Exception {
        Files.createDirectories(Paths.get(OUTPUT_DIR));
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.setExecutor(Executors.newFixedThreadPool(8));

        // ── EXISTING ENDPOINTS (unchanged) ───────────────────────────────────

        server.createContext("/api/analyse", ex -> {
            addCors(ex);
            if ("OPTIONS".equals(ex.getRequestMethod())) { respond(ex, 200, ""); return; }
            if (!"GET".equals(ex.getRequestMethod()))    { respond(ex, 405, ""); return; }

            String query  = ex.getRequestURI().getQuery();
            String target = parseParam(query, "path");
            if (target == null || target.isEmpty()) target = "target";

            Path base = Paths.get(".").toAbsolutePath().normalize();
            Path tgt  = Paths.get(target).toAbsolutePath().normalize();
            if (!tgt.startsWith(base)) { respond(ex, 403, json("error", "Path outside project root.")); return; }
            if (!Files.isDirectory(tgt)) { respond(ex, 404, json("error", "Directory not found: " + target)); return; }

            try {
                String filesJson    = runAgent("fileReader.js",   target);
                String analysisJson = runAgent("codeAnalyzer.js", filesJson);
                String payload      = buildPayload(filesJson, analysisJson, target);
                String report       = runAgent("mdGenerator.js",  payload);

                // ── LLM False-Positive Reduction (optional, async) ───────────
                String llmSummaryJson = "null";
                if (llmClient.isEnabled() && llmClient.isHealthy()) {
                    try {
                        llmSummaryJson = runLLMFPReduction(analysisJson);
                    } catch (Exception llmEx) {
                        LOG.warning("LLM FP reduction failed (non-fatal): " + llmEx.getMessage());
                    }
                }

                String ts   = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
                String name = OUTPUT_DIR + "/report_" + ts + ".md";
                Files.writeString(Paths.get(name), report);

                String body = "{\"status\":\"ok\","
                    + "\"report\":"     + jsonString(report)      + ","
                    + "\"analysis\":"   + analysisJson             + ","
                    + "\"llmSummary\":" + llmSummaryJson           + ","
                    + "\"savedAs\":"    + jsonString(name)         + "}";
                respond(ex, 200, body);
            } catch (Exception e) {
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        server.createContext("/api/health", ex -> {
            addCors(ex);
            boolean agentsOk = Files.isDirectory(Paths.get(AGENTS_DIR));
            respond(ex, 200, "{\"status\":\"ok\",\"agents\":" + agentsOk + ",\"version\":\"3.1-llm\"}");
        });

        // ── NEW LLM ENDPOINTS ─────────────────────────────────────────────────

        /**
         * POST /api/llm/analyze
         * Body: { "type": "SQL_INJECTION", "code": "...", "context": "UserDao.java" }
         * Response: { "verdict": "...", "confidence": 0.95, "tps": 42.5, "blake3_hash": "...", "chain_valid": true }
         */
        server.createContext("/api/llm/analyze", ex -> {
            addCors(ex);
            if ("OPTIONS".equals(ex.getRequestMethod())) { respond(ex, 200, ""); return; }
            if (!"POST".equals(ex.getRequestMethod()))   { respond(ex, 405, json("error", "POST required")); return; }

            try {
                String   body   = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                JsonNode req    = mapper.readTree(body);
                String   type   = req.path("type").asText("UNKNOWN");
                String   code   = req.path("code").asText("");
                String   ctx    = req.path("context").asText("");

                if (code.isEmpty()) {
                    respond(ex, 400, json("error", "Field 'code' is required")); return;
                }

                // Quick single-persona judgment
                LLMJudge judge = discourse.quickJudge(type, code);

                if (judge == null) {
                    // LLM not available – fallback
                    respond(ex, 503, json("error", "LLM not available. Ensure llama-server is running."));
                    return;
                }

                VerificationResult vr = hashChain.verify();

                String result = "{" +
                    "\"verdict\":"     + jsonString(judge.judgement)        + "," +
                    "\"confidence\":"  + judge.confidence                   + "," +
                    "\"tps\":"         + judge.tps                          + "," +
                    "\"blake3_hash\":" + jsonString(judge.blake3Hash)       + "," +
                    "\"chain_valid\":" + vr.valid                           + "," +
                    "\"is_real\":"     + (judge.confidence >= CONFIDENCE_THRESHOLD) + "}";
                respond(ex, 200, result);

            } catch (Exception e) {
                LOG.severe("/api/llm/analyze error: " + e.getMessage());
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        /**
         * POST /api/llm/discourse
         * Body: { "topic": "SQL injection in UserDao.java", "rounds": 4 }
         * Response: { "topic": "...", "rounds": [...], "consensus": "...", "chain_hash": "...", "avg_tps": 42.5 }
         */
        server.createContext("/api/llm/discourse", ex -> {
            addCors(ex);
            if ("OPTIONS".equals(ex.getRequestMethod())) { respond(ex, 200, ""); return; }
            if (!"POST".equals(ex.getRequestMethod()))   { respond(ex, 405, json("error", "POST required")); return; }

            try {
                String   body   = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
                JsonNode req    = mapper.readTree(body);
                String   topic  = req.path("topic").asText("");
                int      rounds = req.path("rounds").asInt(4);

                if (topic.isEmpty()) {
                    respond(ex, 400, json("error", "Field 'topic' is required")); return;
                }

                DiscourseResult result = discourse.runDiscourse(topic, rounds);
                respond(ex, 200, discourseToJson(result));

            } catch (Exception e) {
                LOG.severe("/api/llm/discourse error: " + e.getMessage());
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        /**
         * GET /api/llm/health
         * Response: { "llm_available": true, "model": "...", "last_tps": 42.5, "chain_integrity": true, "last_hash": "..." }
         */
        server.createContext("/api/llm/health", ex -> {
            addCors(ex);
            if (!"GET".equals(ex.getRequestMethod())) { respond(ex, 405, ""); return; }

            boolean llmOk   = llmClient.isEnabled() && llmClient.isHealthy();
            VerificationResult vr = hashChain.verify();

            String result = "{" +
                "\"llm_available\":"  + llmOk                                + "," +
                "\"llm_enabled\":"    + llmClient.isEnabled()                 + "," +
                "\"model\":"          + jsonString(llmClient.getModel())      + "," +
                "\"last_tps\":"       + llmClient.getLastTPS()                + "," +
                "\"last_tokens\":"    + llmClient.getLastTokens()             + "," +
                "\"chain_integrity\":" + vr.valid                             + "," +
                "\"chain_size\":"     + hashChain.size()                      + "," +
                "\"last_hash\":"      + jsonString(hashChain.getLastHash())   + "," +
                "\"chain_message\":"  + jsonString(vr.message)                + "}";
            respond(ex, 200, result);
        });

        /**
         * GET /api/llm/export
         * Exports the hash chain as a downloadable JSONL file.
         */
        server.createContext("/api/llm/export", ex -> {
            addCors(ex);
            if (!"GET".equals(ex.getRequestMethod())) { respond(ex, 405, ""); return; }

            try {
                Files.createDirectories(Paths.get("exports"));
                Path exportPath = Paths.get("exports/chain_" + System.currentTimeMillis() + ".jsonl");
                hashChain.export(exportPath);

                String result = "{\"status\":\"ok\",\"exported\":" + jsonString(exportPath.toString()) +
                    ",\"entries\":" + hashChain.size() + "}";
                respond(ex, 200, result);
            } catch (Exception e) {
                respond(ex, 500, json("error", e.getMessage()));
            }
        });

        // ── Frontend ──────────────────────────────────────────────────────────
        server.createContext("/", ex -> {
            if (!"GET".equals(ex.getRequestMethod())) { respond(ex, 405, ""); return; }
            Path html = Paths.get("frontend/index.html");
            if (!Files.exists(html)) {
                byte[] msg = "frontend/index.html not found".getBytes();
                ex.getResponseHeaders().add("Content-Type", "text/plain");
                ex.sendResponseHeaders(404, msg.length);
                try (OutputStream o = ex.getResponseBody()) { o.write(msg); }
                return;
            }
            byte[] bytes = Files.readAllBytes(html);
            ex.getResponseHeaders().add("Content-Type", "text/html; charset=utf-8");
            ex.sendResponseHeaders(200, bytes.length);
            try (OutputStream o = ex.getResponseBody()) { o.write(bytes); }
        });

        server.start();
        System.out.println("\n" + "=".repeat(62));
        System.out.println("  MAXXKI Deep Semantic Analyser – API Server v3.1-LLM");
        System.out.println("=".repeat(62));
        System.out.println("  http://localhost:" + port);
        System.out.println("  Semantic: SCC · Taint · Memory · Side Effects · Domain");
        System.out.println("  LLM:      " + (llmClient.isEnabled() ? "ENABLED (" + llmClient.getModel() + ")" : "DISABLED"));
        System.out.println("=".repeat(62));
        System.out.println("  Press Ctrl+C to stop.\n");
    }

    // ── LLM False-Positive Reduction ─────────────────────────────────────────

    /**
     * Läuft über die top-Vulnerabilities aus dem analysisJson
     * und reduziert False-Positives via LLM.
     *
     * @return JSON-String mit LLM-bewerteten Vulnerabilities
     */
    private static String runLLMFPReduction(String analysisJson) throws Exception {
        JsonNode analysis = mapper.readTree(analysisJson);
        JsonNode vulns    = analysis.path("security").path("vulnerabilities");

        if (vulns.isEmpty()) return "[]";

        // Process in parallel (max 5 at a time to avoid rate-limiting)
        ExecutorService pool = Executors.newFixedThreadPool(3);
        List<CompletableFuture<String>> futures = new ArrayList<>();

        int limit = Math.min(vulns.size(), 10); // max 10 vulnerabilities
        for (int i = 0; i < limit; i++) {
            final JsonNode vuln = vulns.get(i);
            futures.add(CompletableFuture.supplyAsync(() -> {
                try {
                    String type = vuln.path("type").asText("UNKNOWN");
                    String code = vuln.path("code").asText("");
                    String file = vuln.path("file").asText("");

                    LLMJudge judge = discourse.quickJudge(type, code);
                    if (judge == null) {
                        return "{\"type\":" + jsonString(type) + ",\"file\":" + jsonString(file) +
                            ",\"llm_verdict\":\"UNAVAILABLE\",\"confidence\":0.5,\"is_real\":null}";
                    }
                    return "{\"type\":" + jsonString(type) + ",\"file\":" + jsonString(file) +
                        ",\"llm_verdict\":" + jsonString(judge.judgement.substring(0, Math.min(200, judge.judgement.length()))) +
                        ",\"confidence\":" + judge.confidence +
                        ",\"tps\":" + judge.tps +
                        ",\"blake3_hash\":" + jsonString(judge.blake3Hash) +
                        ",\"is_real\":" + (judge.confidence >= CONFIDENCE_THRESHOLD) + "}";
                } catch (Exception e) {
                    return "{\"error\":" + jsonString(e.getMessage()) + "}";
                }
            }, pool));
        }

        StringBuilder sb = new StringBuilder("[");
        List<String> results = futures.stream()
            .map(f -> { try { return f.get(35, TimeUnit.SECONDS); } catch (Exception e) { return "{\"error\":\"timeout\"}"; } })
            .collect(java.util.stream.Collectors.toList());

        for (int i = 0; i < results.size(); i++) {
            if (i > 0) sb.append(",");
            sb.append(results.get(i));
        }
        sb.append("]");
        pool.shutdown();
        return sb.toString();
    }

    // ── JSON Serialization ─────────────────────────────────────────────────────

    private static String discourseToJson(DiscourseResult r) throws Exception {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"topic\":").append(jsonString(r.topic)).append(",");
        sb.append("\"consensus\":").append(jsonString(r.consensus)).append(",");
        sb.append("\"blake3_root_hash\":").append(jsonString(r.blake3RootHash)).append(",");
        sb.append("\"average_tps\":").append(r.averageTPS).append(",");
        sb.append("\"rounds\":[");
        for (int i = 0; i < r.rounds.size(); i++) {
            if (i > 0) sb.append(",");
            DiscourseRound rnd = r.rounds.get(i);
            sb.append("{")
              .append("\"round\":").append(rnd.roundNumber).append(",")
              .append("\"persona\":").append(jsonString(rnd.persona.name())).append(",")
              .append("\"role\":").append(jsonString(rnd.persona.role)).append(",")
              .append("\"content\":").append(jsonString(rnd.content)).append(",")
              .append("\"confidence\":").append(rnd.confidence).append(",")
              .append("\"tps\":").append(rnd.tps).append(",")
              .append("\"blake3_hash\":").append(jsonString(rnd.blake3Hash))
              .append("}");
        }
        sb.append("]}");
        return sb.toString();
    }

    // ── EXISTING METHODS (unchanged) ──────────────────────────────────────────

    static String runPipeline(String target) throws Exception {
        Files.createDirectories(Paths.get(OUTPUT_DIR));
        System.out.println("[1/3] Scanning Java files …");
        String filesJson    = runAgent("fileReader.js",   target);
        System.out.println("[2/3] Deep semantic analysis (SCC · Taint · Memory · Domain) …");
        String analysisJson = runAgent("codeAnalyzer.js", filesJson);
        System.out.println("[3/3] Generating semantic report …");
        String payload      = buildPayload(filesJson, analysisJson, target);
        String report       = runAgent("mdGenerator.js",  payload);
        String ts   = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm"));
        String name = OUTPUT_DIR + "/report_" + ts + ".md";
        Files.writeString(Paths.get(name), report);
        System.out.println("\nSaved → " + name + "\n");
        return report;
    }

    static String runAgent(String agentName, String input) throws Exception {
        String agentPath = AGENTS_DIR + "/" + agentName;
        if (!Files.exists(Paths.get(agentPath)))
            throw new Exception("Agent not found: " + agentPath);

        ProcessBuilder pb = new ProcessBuilder("node", "--max-old-space-size=512", agentPath);
        pb.redirectErrorStream(false);
        Process p = pb.start();

        try (OutputStream stdin = p.getOutputStream()) {
            stdin.write(input.getBytes(StandardCharsets.UTF_8));
        }

        final StringBuilder outBuf = new StringBuilder();
        final StringBuilder errBuf = new StringBuilder();
        Thread outReader = new Thread(() -> {
            try { outBuf.append(new String(p.getInputStream().readAllBytes())); } catch (IOException ignored) {}
        });
        Thread errReader = new Thread(() -> {
            try { errBuf.append(new String(p.getErrorStream().readAllBytes())); } catch (IOException ignored) {}
        });
        outReader.start(); errReader.start();

        if (!p.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)) {
            p.destroyForcibly();
            throw new Exception("Timeout (" + TIMEOUT_SEC + "s): " + agentName);
        }
        outReader.join(); errReader.join();

        String out = outBuf.toString().trim();
        String err = errBuf.toString().trim();
        if (p.exitValue() != 0)
            throw new Exception("Agent '" + agentName + "' failed: " + (err.isEmpty() ? out : err));
        return out;
    }

    static String buildPayload(String filesJson, String analysisJson, String project) {
        return "{\"files\":"    + filesJson
             + ",\"analysis\":" + analysisJson
             + ",\"project\":"  + jsonString(project)
             + ",\"date\":"     + jsonString(LocalDateTime.now().toString())
             + "}";
    }

    static String jsonString(String s) {
        if (s == null) return "null";
        return "\"" + s.replace("\\","\\\\").replace("\"","\\\"")
                       .replace("\n","\\n").replace("\r","\\r")
                       .replace("\t","\\t") + "\"";
    }

    static String json(String key, String value) { return "{\"" + key + "\":" + jsonString(value) + "}"; }

    static String parseParam(String query, String key) {
        if (query == null) return null;
        for (String part : query.split("&")) {
            String[] kv = part.split("=", 2);
            if (kv.length == 2 && kv[0].equals(key))
                return java.net.URLDecoder.decode(kv[1], StandardCharsets.UTF_8);
        }
        return null;
    }

    static void addCors(HttpExchange ex) {
        ex.getResponseHeaders().add("Access-Control-Allow-Origin",  "*");
        ex.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        ex.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
        ex.getResponseHeaders().add("Content-Type", "application/json; charset=utf-8");
    }

    static void respond(HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }
}
