#  MAXXKI Deep Semantic Analyser v3.1-LLM

[![Java](https://img.shields.io/badge/Java-17+-orange.svg)](https://adoptium.net/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

Semantic code analysis with LLM-powered false-positive reduction and BLAKE3-verified audit chains.

# User → React Frontend → Orchestrator (Java)
                           ├── Node.js Agents (fileReader, codeAnalyzer, mdGenerator)
                           ├── LLM Client → llama.cpp/Qwen2
                           └── Hash Chain (BLAKE3 integrity)

## Features

- *Deep Semantic Analysis* – Taint flow, memory leaks, side effects, SCC cycles
- *LLM Integration* – Qwen2/Llama models via OpenAI-compatible API
- *4-Persona Security Discourse* – DOMINUS → AXIOM → CIPHER → VECTOR
- *BLAKE3 Hash Chain* – Tamper-proof audit trail of all LLM decisions
- *REST API + React Frontend* – Modern web UI for analysis

## 📋 Prerequisites

- Java 17+
- Node.js (for JS agents)
- llama.cpp server

## 🛠️ Installation

```bash
# Clone
git clone https://github.com/maxxki/maxxki-analyser.git
cd maxxki-analyser

# Compile
mvn clean compile assembly:single

# Configure
cp config/maxxki.properties.example config/maxxki.properties
# Edit llm.url and other settings


# Start
./llama-server -m models/qwen2-1.5b-instruct-q4_k_m.gguf \
  --host 127.0.0.1 --port 8080 -c 2048

java -jar target/maxxki-3.1-llm.jar --server 7070

# open browser

http://localhost:7070/


# properties example

llm.enabled=true
llm.url=http://127.0.0.1:8080
llm.model=qwen2-1.5b-instruct
llm.temperature=0.4
llm.max_tokens=350
llm.confidence_threshold=0.7
blake3.chain.path=hashes/chain.jsonl
