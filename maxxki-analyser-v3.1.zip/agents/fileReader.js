#!/usr/bin/env node
/**
 * fileReader.js
 * Reads the target path from stdin (first line = path string, or raw path arg).
 * Returns JSON array of { name, path, relative, size, ext }.
 * READ-ONLY: write operations are blocked.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

// ── Read-only protection ─────────────────────────────────────────────────────
fs.writeFileSync = fs.writeFile = fs.appendFileSync = fs.appendFile =
fs.unlinkSync    = fs.unlink    = fs.rmdirSync      = fs.rmdir      =
fs.mkdirSync     = fs.mkdir     = () => { process.exit(99); };

// ── Collect stdin (Orchestrator writes the path there) ───────────────────────
let inputBuf = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => { inputBuf += chunk; });
process.stdin.on('end', () => {
    const targetArg = inputBuf.trim() || process.argv[2] || '.';
    const root      = path.resolve(targetArg);

    if (!fs.existsSync(root)) {
        process.stderr.write('Directory not found: ' + root + '\n');
        process.exit(1);
    }

    try {
        const files = walk(root, root);
        process.stdout.write(JSON.stringify(files, null, 0) + '\n');
    } catch (e) {
        process.stderr.write(e.message + '\n');
        process.exit(1);
    }
});

function walk(dir, root) {
    let results = [];
    const entries = fs.readdirSync(dir);

    for (const entry of entries) {
        if (entry.startsWith('.') ||
            entry === 'node_modules' || entry === 'build' ||
            entry === 'bin' || entry === 'out') continue;

        const full = path.join(dir, entry);
        let   stat;
        try { stat = fs.statSync(full); } catch { continue; }

        if (stat.isDirectory()) {
            results = results.concat(walk(full, root));
        } else if (path.extname(entry).toLowerCase() === '.java') {
            results.push({
                name:     entry,
                path:     full,
                relative: path.relative(root, full),
                size:     stat.size,
                ext:      '.java'
            });
        }
    }
    return results;
}
