package com.maxxki.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.bouncycastle.crypto.digests.Blake3Digest;

import java.io.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.util.Properties;
import java.util.concurrent.*;
import java.util.logging.Logger;

/**
 * LLMClient – HTTP-Client für llama.cpp-Server (OpenAI-kompatibel).
 *
 * Features:
 * · Async mit CompletableFuture (Timeout konfigurierbar)
 * · Retry-Logic: max 3 Versuche, Exponential Backoff
 * · TPS-Messung (Tokens per Second)
 * · BLAKE3-Hash jeder Response (inkl. Metadaten)
 * · Healthcheck-Endpunkt
 * · Fallback: gibt null zurück wenn LLM nicht erreichbar
 */
public class LLMClient {

    private static final Logger LOG = Logger.getLogger(LLMClient.class.getName());

    private final HttpClient   httpClient;
    private final ObjectMapper mapper;
    private final String       endpoint;
    private final String       model;
    private final double       temperature;
    private final int          maxTokens;
    private final int          timeoutSeconds;
    private final int          retryAttempts;
    private final boolean      enabled;

    // Per-call state (last call only – single-threaded usage pattern)
    private volatile double lastTPS      = 0.0;
    private volatile String lastHash     = "0".repeat(64);
    private volatile int    lastTokens   = 0;
    private volatile long   lastLatencyMs = 0;

    // ── Constructor ────────────────────────────────────────────────────────────

    /**
     * Baut LLMClient aus maxxki.properties.
     *
     * @param props geladene Properties-Datei
     */
    public LLMClient(Properties props) {
        this.enabled        = Boolean.parseBoolean(props.getProperty("llm.enabled",          "true"));
        this.endpoint       = props.getProperty("llm.url",               "http://127.0.0.1:8080");
        this.model          = props.getProperty("llm.model",             "llama-3.2-3b-instruct");
        this.temperature    = Double.parseDouble(props.getProperty("llm.temperature",         "0.4"));
        this.maxTokens      = Integer.parseInt(  props.getProperty("llm.max_tokens",          "350"));
        this.timeoutSeconds = Integer.parseInt(  props.getProperty("llm.timeout_seconds",     "30"));
        this.retryAttempts  = Integer.parseInt(  props.getProperty("llm.retry_attempts",      "3"));

        this.mapper = new ObjectMapper();
        this.httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(5))
            .build();
    }

    // ── Core: chat() ───────────────────────────────────────────────────────────

    /**
     * Sendet einen Chat-Request an den LLM-Server.
     * Asynchron mit Timeout, Retry und BLAKE3-Hashing.
     *
     * @param systemPrompt Das System-Prompt (Persona-Instruktion)
     * @param userPrompt   Die eigentliche Frage / der Code-Snippet
     * @return LLMResponse oder null bei Fehler/Timeout
     */
    public LLMResponse chat(String systemPrompt, String userPrompt) {
        if (!enabled) {
            LOG.warning("LLM disabled – skipping call.");
            return null;
        }

        for (int attempt = 1; attempt <= retryAttempts; attempt++) {
            try {
                return chatAttempt(systemPrompt, userPrompt, attempt);
            } catch (TimeoutException e) {
                LOG.warning("LLM timeout (attempt " + attempt + "/" + retryAttempts + ")");
            } catch (Exception e) {
                LOG.warning("LLM error (attempt " + attempt + "/" + retryAttempts + "): " + e.getMessage());
            }

            if (attempt < retryAttempts) {
                long backoff = (long) (Math.pow(2, attempt) * 1000); // 2s, 4s, 8s
                try { Thread.sleep(backoff); } catch (InterruptedException ignored) {}
            }
        }

        LOG.severe("LLM: all " + retryAttempts + " attempts failed.");
        return null;
    }

    /**
     * Einzelner Chat-Versuch mit Timeout via CompletableFuture.
     */
    private LLMResponse chatAttempt(String systemPrompt, String userPrompt, int attempt)
            throws Exception {

        String requestBody = buildRequestBody(systemPrompt, userPrompt);

        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(endpoint + "/v1/chat/completions"))
            .header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(requestBody, StandardCharsets.UTF_8))
            .timeout(Duration.ofSeconds(timeoutSeconds))
            .build();

        Instant start = Instant.now();

        CompletableFuture<HttpResponse<String>> future = httpClient
            .sendAsync(request, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));

        HttpResponse<String> response = future.get(timeoutSeconds + 2L, TimeUnit.SECONDS);

        long latencyMs = Duration.between(start, Instant.now()).toMillis();

        if (response.statusCode() != 200) {
            throw new IOException("HTTP " + response.statusCode() + ": " + response.body().substring(0, Math.min(200, response.body().length())));
        }

        return parseResponse(response.body(), latencyMs);
    }

    /**
     * Parst die JSON-Response und berechnet TPS + BLAKE3-Hash.
     */
    private LLMResponse parseResponse(String body, long latencyMs) throws Exception {
        JsonNode root    = mapper.readTree(body);
        JsonNode choices = root.path("choices");

        if (choices.isEmpty()) {
            throw new IOException("Empty choices in LLM response");
        }

        String content = choices.get(0).path("message").path("content").asText("").trim();

        // Token count aus usage-Block, fallback: word estimate
        int tokens = root.path("usage").path("completion_tokens").asInt(0);
        if (tokens == 0) tokens = content.split("\\s+").length;

        double tps = latencyMs > 0 ? (tokens * 1000.0 / latencyMs) : 0.0;
        tps = Math.round(tps * 100.0) / 100.0;

        // BLAKE3-Hash: content + tps + latency
        String hashInput  = content + "|tps=" + tps + "|lat=" + latencyMs;
        String blake3Hash = blake3Hex(hashInput);

        // Cache last values for getters
        this.lastTPS       = tps;
        this.lastHash      = blake3Hash;
        this.lastTokens    = tokens;
        this.lastLatencyMs = latencyMs;

        return new LLMResponse(content, tps, tokens, blake3Hash, latencyMs);
    }

    /**
     * Baut den JSON-Request-Body für den Chat-Endpunkt.
     */
    private String buildRequestBody(String systemPrompt, String userPrompt) {
        return "{" +
            "\"model\":"       + jsonStr(model)       + "," +
            "\"temperature\":" + temperature          + "," +
            "\"max_tokens\":"  + maxTokens            + "," +
            "\"messages\":["   +
                "{\"role\":\"system\",\"content\":" + jsonStr(systemPrompt) + "}," +
                "{\"role\":\"user\",\"content\":"   + jsonStr(userPrompt)   + "}" +
            "]}";
    }

    // ── Healthcheck ───────────────────────────────────────────────────────────

    /**
     * Prüft ob der LLM-Server erreichbar ist.
     *
     * @return true wenn /health 200 zurückgibt
     */
    public boolean isHealthy() {
        if (!enabled) return false;
        try {
            HttpRequest req = HttpRequest.newBuilder()
                .uri(URI.create(endpoint + "/health"))
                .GET()
                .timeout(Duration.ofSeconds(3))
                .build();
            HttpResponse<String> resp = httpClient.send(req, HttpResponse.BodyHandlers.ofString());
            return resp.statusCode() == 200;
        } catch (Exception e) {
            return false;
        }
    }

    // ── BLAKE3 ─────────────────────────────────────────────────────────────────

    /**
     * Berechnet BLAKE3-Hash eines Strings als Hex-String (64 Zeichen).
     * Verwendet Bouncy Castle bcprov.
     */
    public static String blake3Hex(String input) {
        Blake3Digest digest = new Blake3Digest(256);
        byte[]       data   = input.getBytes(StandardCharsets.UTF_8);
        digest.update(data, 0, data.length);
        byte[] out = new byte[32];
        digest.doFinal(out, 0);
        StringBuilder sb = new StringBuilder(64);
        for (byte b : out) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    /** TPS des letzten erfolgreichen Calls. */
    public double getLastTPS()      { return lastTPS; }

    /** BLAKE3-Hash des letzten erfolgreichen Calls. */
    public String getLastHash()     { return lastHash; }

    /** Token-Count des letzten Calls. */
    public int    getLastTokens()   { return lastTokens; }

    /** Latenz in ms des letzten Calls. */
    public long   getLastLatencyMs(){ return lastLatencyMs; }

    /** Konfigurierter Modell-Name. */
    public String getModel()        { return model; }

    /** Ob LLM aktiviert ist. */
    public boolean isEnabled()      { return enabled; }

    // ── JSON-Escape Utility ───────────────────────────────────────────────────

    private static String jsonStr(String s) {
        if (s == null) return "null";
        return "\"" + s
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
            + "\"";
    }
}

// ══════════════════════════════════════════════════════════════════════════════
// VALUE OBJECTS
// ══════════════════════════════════════════════════════════════════════════════

/**
 * Immutable response object für einen LLM-Call.
 */
class LLMResponse {
    public final String content;
    public final double tps;
    public final int    tokens;
    public final String blake3Hash;
    public final long   latencyMs;

    public LLMResponse(String content, double tps, int tokens, String blake3Hash, long latencyMs) {
        this.content    = content;
        this.tps        = tps;
        this.tokens     = tokens;
        this.blake3Hash = blake3Hash;
        this.latencyMs  = latencyMs;
    }

    @Override
    public String toString() {
        return String.format("LLMResponse{tps=%.2f, tokens=%d, latency=%dms, hash=%s...}",
            tps, tokens, latencyMs, blake3Hash.substring(0, 12));
    }
}
