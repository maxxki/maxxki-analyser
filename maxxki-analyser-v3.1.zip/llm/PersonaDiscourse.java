package com.maxxki.llm;

import com.maxxki.integrity.ChainEntry;
import com.maxxki.integrity.HashChain;

import java.util.*;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PersonaDiscourse {

    private static final Logger LOG = Logger.getLogger(PersonaDiscourse.class.getName());

    private static final String BASE_INSTRUCTION =
        "Maximum 2 sentences. No lists. No headers. No markdown. " +
        "Start immediately with the finding. Do not repeat previous statements.";

    public enum Persona {
        DOMINUS("Red-Team Researcher",
            BASE_INSTRUCTION + " You are a red-team security researcher. " +
            "Find ONE new vulnerability not yet mentioned. Be specific about attack vector. " +
            "End with 'Confidence: X.X' (0.0=unsure, 1.0=certain)."),
        AXIOM("Forensic Analyst",
            BASE_INSTRUCTION + " You are a forensic analyst. " +
            "Add ONE new technical detail (exploit mechanism, affected component, or impact) to the previous finding. " +
            "End with 'Confidence: X.X' (0.0=unsure, 1.0=certain)."),
        CIPHER("Critic",
            BASE_INSTRUCTION + " You are a security critic. " +
            "Find ONE specific flaw or limitation in the previous statement. Be precise. " +
            "End with 'Confidence: X.X' (0.0=unsure, 1.0=certain)."),
        VECTOR("Strategist",
            BASE_INSTRUCTION + " You are a security strategist. " +
            "Name ONE specific tool, library, config setting, or code pattern that directly mitigates the identified flaw. No generic advice. " +
            "End with 'Confidence: X.X' (0.0=unsure, 1.0=certain).");

        public final String role;
        public final String systemPrompt;
        Persona(String role, String systemPrompt) { this.role = role; this.systemPrompt = systemPrompt; }
    }

    private final LLMClient  llm;
    private final HashChain  chain;

    private static final String[] CONFIDENCE_KEYWORDS = {
        "confidence:", "confidence score:", "certainty:", "probability:",
        "likelihood:", "confident:", "sureness:", "confidence level:"
    };

    public PersonaDiscourse(LLMClient llm, HashChain chain) {
        this.llm = llm;
        this.chain = chain;
    }

    public DiscourseResult runDiscourse(String topic, int rounds) throws Exception {
        if (!llm.isEnabled()) {
            LOG.warning("LLM disabled.");
            return emptyDiscourse(topic);
        }
        
        List<DiscourseRound> discourseRounds = new ArrayList<>();
        Persona[] personas = Persona.values();
        String lastAnswer = "Topic: " + topic;
        double totalTps = 0;
        int tpsCount = 0;
        int actualRounds = Math.min(rounds, personas.length);
        
        for (int i = 0; i < actualRounds; i++) {
            Persona persona = personas[i % personas.length];
            LOG.info("Discourse round " + (i+1) + " – " + persona.name());
            
            String userPrompt = (persona == Persona.AXIOM)
                ? "Topic: " + topic + "\n\nPrevious finding: " + lastAnswer
                : lastAnswer;
            
            LLMResponse response = llm.chat(persona.systemPrompt, userPrompt);
            if (response == null) {
                LOG.warning("No response from " + persona.name());
                continue;
            }
            
            String answer = cleanAnswer(response.content);
            
            if (isTooSimilar(answer, lastAnswer)) {
                response = llm.chat(persona.systemPrompt,
                    userPrompt + "\n\nGive a completely different angle. Do not repeat previous points.");
                if (response != null) {
                    answer = cleanAnswer(response.content);
                } else {
                    continue;
                }
            }
            
            ChainEntry ce = chain.append("Discourse|" + persona.name() + "|" + topic + "|" + answer);
            double confidence = extractConfidence(answer);
            discourseRounds.add(new DiscourseRound(persona, answer, response.tps, ce.hash, i+1, confidence));
            lastAnswer = answer;
            totalTps += response.tps;
            tpsCount++;
        }
        
        String consensus = buildConsensus(discourseRounds, topic);
        double avgTps = tpsCount > 0 ? totalTps / tpsCount : 0.0;
        String rootHash = discourseRounds.isEmpty() ? HashChain.GENESIS_HASH
                        : discourseRounds.get(discourseRounds.size()-1).blake3Hash;
        
        return new DiscourseResult(topic, discourseRounds, consensus, rootHash, avgTps);
    }

    public List<LLMJudge> deepAnalyze(String vulnType, String code, String codeContext) throws Exception {
        List<LLMJudge> judges = new ArrayList<>();
        if (!llm.isEnabled()) {
            LOG.warning("LLM disabled.");
            return judges;
        }
        
        String analysisTopic = "Vulnerability type: " + vulnType +
            "\nCode snippet:\n" + truncate(code, 400) + "\nContext: " + codeContext;
        String lastAnswer = analysisTopic;
        
        for (Persona persona : Persona.values()) {
            String systemPrompt = persona.systemPrompt +
                "\nFocus: Is this a REAL vulnerability or a false positive? " +
                "Answer format: Start with 'VERDICT: REAL' or 'VERDICT: FALSE POSITIVE', " +
                "then explain briefly. End with 'Confidence: X.X' (0.0-1.0).";
            
            LLMResponse response = llm.chat(systemPrompt, lastAnswer);
            if (response == null) {
                LOG.warning("No response from " + persona.name());
                continue;
            }
            
            String answer = cleanAnswer(response.content);
            double confidence = extractConfidence(answer);
            
            // Extrahiere das Verdict aus der Antwort
            String verdict = extractVerdict(answer);
            String finalAnswer = verdict.isEmpty() ? answer : verdict + ": " + answer;
            
            ChainEntry ce = chain.append("Analysis|" + persona.name() + "|" + vulnType + "|" + finalAnswer);
            judges.add(new LLMJudge(persona, finalAnswer, confidence, ce.hash, response.tps));
            lastAnswer = finalAnswer;
        }
        return judges;
    }

    public LLMJudge quickJudge(String vulnType, String code) throws Exception {
        if (!llm.isEnabled()) return null;
        
        String prompt = "You are a security expert. Is this a REAL vulnerability or a false positive?\n" +
            "Vulnerability: " + vulnType + "\nCode: " + truncate(code, 300) + "\n" +
            "Answer format: First state 'REAL' or 'FALSE POSITIVE', then explain briefly. " +
            "End with 'Confidence: X.X' (0.0=unsure, 1.0=certain).";
        
        LLMResponse response = llm.chat(Persona.DOMINUS.systemPrompt, prompt);
        if (response == null) return null;
        
        String answer = cleanAnswer(response.content);
        double confidence = extractConfidence(answer);
        String verdict = extractVerdict(answer);
        
        // Wenn kein explizites Verdict gefunden wurde, nutze Confidence als Indikator
        String finalVerdict = verdict.isEmpty()
            ? (confidence >= 0.7 ? "REAL" : (confidence <= 0.3 ? "FALSE POSITIVE" : "UNCERTAIN"))
            : verdict;
        
        String finalAnswer = finalVerdict + ": " + answer;
        
        ChainEntry ce = chain.append("QuickJudge|" + vulnType + "|" + finalAnswer);
        return new LLMJudge(Persona.DOMINUS, finalAnswer, confidence, ce.hash, response.tps);
    }

    /**
     * Extrahiert die Confidence aus dem Text mit mehreren Strategien.
     */
    private double extractConfidence(String text) {
        if (text == null || text.isEmpty()) return 0.5;
        String lower = text.toLowerCase();
        
        // Strategie 1: Suche nach "Confidence: X.X" am Ende oder überall
        Pattern confidencePattern = Pattern.compile("[Cc]onfidence:\\s*(\\d+\\.?\\d*)|(\\d+)%\\s*confident");
        Matcher m = confidencePattern.matcher(text);
        if (m.find()) {
            String val = m.group(1) != null ? m.group(1) : m.group(2);
            if (val != null) {
                try {
                    double v = Double.parseDouble(val);
                    if (v > 1.0 && v <= 100) v = v / 100.0;
                    if (v >= 0.0 && v <= 1.0) return Math.round(v * 100) / 100.0;
                } catch (NumberFormatException ignored) {}
            }
        }
        
        // Strategie 2: Explizite Confidence-Keywords
        for (String keyword : CONFIDENCE_KEYWORDS) {
            int idx = lower.indexOf(keyword);
            if (idx >= 0) {
                String remainder = text.substring(idx + keyword.length()).trim();
                Pattern numPattern = Pattern.compile("(\\d+\\.\\d+|\\d+)");
                Matcher numMatcher = numPattern.matcher(remainder);
                if (numMatcher.find()) {
                    try {
                        double v = Double.parseDouble(numMatcher.group(1));
                        if (v > 1.0) v = v / 100.0;
                        return Math.min(Math.max(v, 0.0), 1.0);
                    } catch (NumberFormatException ignored) {}
                }
            }
        }
        
        // Strategie 3: Explizite Aussagen über Sicherheit/Unsicherheit
        if (lower.matches(".*\\b(definitely|certainly|absolutely|clearly a real|without doubt)\\b.*")) {
            return 0.9;
        }
        if (lower.matches(".*\\b(very confident|high confidence|strongly believe)\\b.*")) {
            return 0.85;
        }
        if (lower.matches(".*\\b(likely|probably|most likely)\\b.*")) {
            return 0.7;
        }
        if (lower.matches(".*\\b(unclear|not sure|maybe|could be|possibly)\\b.*")) {
            return 0.5;
        }
        if (lower.matches(".*\\b(unlikely|probably not|doubtful)\\b.*")) {
            return 0.3;
        }
        if (lower.contains("false positive") && !lower.contains("real")) {
            return 0.25;
        }
        if ((lower.contains("no vulnerability") || lower.contains("not vulnerable")) &&
            !lower.contains("vulnerable")) {
            return 0.2;
        }
        
        // Strategie 4: Länge der Antwort als Indikator
        if (text.length() > 250) return 0.7;
        if (text.length() < 50) return 0.4;
        
        return 0.5;
    }

    /**
     * Extrahiert das Verdict (REAL/FALSE POSITIVE) aus der Antwort.
     */
    private String extractVerdict(String text) {
        if (text == null) return "";
        String upper = text.toUpperCase();
        
        if (upper.contains("VERDICT: REAL") || upper.matches(".*\\bREAL\\b.*")) {
            return "REAL";
        }
        if (upper.contains("VERDICT: FALSE POSITIVE") ||
            upper.contains("FALSE POSITIVE") ||
            (upper.contains("FALSE") && upper.contains("POSITIVE"))) {
            return "FALSE POSITIVE";
        }
        if (upper.startsWith("REAL") || upper.startsWith("FALSE POSITIVE")) {
            return upper.split("\\s+")[0] + (upper.startsWith("FALSE") ? " POSITIVE" : "");
        }
        
        return "";
    }

    private String cleanAnswer(String text) {
        if (text == null) return "";
        // Entferne Markdown und Formatierungen
        text = text.replaceAll("</?b>", "");
        text = text.replaceAll("\\*\\*(.*?)\\*\\*", "$1");
        text = text.replaceAll("\\*(.*?)\\*", "$1");
        text = text.replaceAll("#{1,6}\\s*", "");
        text = text.replaceAll("```\\w*\\n?", "");
        text = text.replaceAll("```", "");
        
        // Begrenze Länge
        String[] words = text.trim().split("\\s+");
        if (words.length > 150) {
            text = String.join(" ", Arrays.copyOf(words, 150));
        }
        return text.trim();
    }

    private boolean isTooSimilar(String a, String b) {
        if (a == null || b == null) return false;
        Set<String> wordsA = new HashSet<>(Arrays.asList(a.toLowerCase().split("\\s+")));
        Set<String> wordsB = new HashSet<>(Arrays.asList(b.toLowerCase().split("\\s+")));
        Set<String> inter = new HashSet<>(wordsA);
        inter.retainAll(wordsB);
        int maxSize = Math.max(wordsA.size(), wordsB.size());
        return maxSize > 0 && (double) inter.size() / maxSize > 0.7;
    }

    private String buildConsensus(List<DiscourseRound> rounds, String topic) {
        if (rounds.isEmpty()) return "No consensus – no rounds completed.";
        StringBuilder sb = new StringBuilder("Topic: ").append(topic).append("\n");
        for (DiscourseRound r : rounds) {
            String content = r.content.length() > 150
                ? r.content.substring(0, 150) + "..."
                : r.content;
            sb.append(r.persona.name()).append(" (").append(r.persona.role).append("): ")
              .append(content).append("\n");
        }
        return sb.toString();
    }

    private DiscourseResult emptyDiscourse(String topic) {
        return new DiscourseResult(topic, new ArrayList<>(), "LLM disabled", HashChain.GENESIS_HASH, 0.0);
    }

    private static String truncate(String s, int maxLen) {
        return (s != null && s.length() > maxLen) ? s.substring(0, maxLen) + "..." : s;
    }
}
