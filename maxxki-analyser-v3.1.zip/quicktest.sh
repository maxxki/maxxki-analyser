#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────
#  MAXXKI Deep Semantic Analyser v3.0 – Quick Test
# ─────────────────────────────────────────────────────────
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PASS=0; FAIL=0
ok()   { echo "  ✅  $1"; PASS=$((PASS+1)); }
fail() { echo "  ❌  $1"; FAIL=$((FAIL+1)); }
check() { local label="$1"; shift; if "$@" > /dev/null 2>&1; then ok "$label"; else fail "$label"; fi }

echo ""
echo "=== MAXXKI Deep Semantic Analyser v3.0 – Quick Test ==="
echo ""

TMP="$SCRIPT_DIR/_test_tmp"
mkdir -p "$TMP/com/example"

cat > "$TMP/com/example/TestClass.java" << 'JAVA'
package com.example;
import java.util.Vector;
import java.io.RandomAccessFile;
import step2e.db.DBHandler;

public class TestClass {
    private static Vector<String> cache = new Vector<String>();
    private String userInput = "";

    public void process(String input) throws Exception {
        this.userInput = input;
        // SQL injection risk
        String q = "SELECT * FROM TABLE WHERE ID='" + input + "'";
        DBHandler.getResultString(q);
        // unclosed resource
        RandomAccessFile rf = new RandomAccessFile("/tmp/test", "r");
        cache.add(input);
        // TODO: close rf
    }
}
JAVA

echo "Dependency checks:"
check "node available"  node --version
check "java available"  java -version
check "javac available" javac -version
echo ""

echo "Agent tests:"
FILES=$(echo "$TMP" | node agents/fileReader.js 2>/dev/null)
check "fileReader – finds .java files"   bash -c "echo '$FILES' | grep -q '.java'"
check "fileReader – returns JSON array"  bash -c "echo '$FILES' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.length>0?0:1)\""

ANALYSIS=$(echo "$FILES" | node agents/codeAnalyzer.js 2>/dev/null)
check "codeAnalyzer – runs OK"           bash -c "echo '$ANALYSIS' | node -e \"JSON.parse(require('fs').readFileSync('/dev/stdin','utf8'))\""
check "codeAnalyzer – detects classes"  bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.summary.totalClasses>0?0:1)\""
check "codeAnalyzer – detects legacy"   bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.legacyIssues.length>0?0:1)\""
check "codeAnalyzer – detects domain"   bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(Object.keys(d.domainMap).length>0?0:1)\""
check "codeAnalyzer – semantic summary" bash -c "echo '$ANALYSIS' | node -e \"const d=JSON.parse(require('fs').readFileSync('/dev/stdin','utf8')); process.exit(d.semanticSummary.overallRisk?0:1)\""
echo ""

echo "Compiler & pipeline:"
check "javac Orchestrator.java" javac Orchestrator.java
check "java Orchestrator (CLI)" java Orchestrator "$TMP"
echo ""

rm -rf "$TMP" Orchestrator.class 2>/dev/null || true

echo ""
echo "═══════════════════════════════════════════════════"
printf "  Passed: %s  |  Failed: %s\n" "$PASS" "$FAIL"
echo "═══════════════════════════════════════════════════"
[ "$FAIL" -eq 0 ] && echo "  All good – run ./run.sh 🚀" || echo "  Fix failures above."
echo ""
