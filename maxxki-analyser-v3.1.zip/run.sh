#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────
#  MAXXKI Deep Semantic Analyser v3.0 – Start Script
#  ./run.sh                  → API server (port 7070)
#  ./run.sh --cli <path>     → CLI mode
#  ./run.sh --port 8080      → custom port
# ─────────────────────────────────────────────────────────
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

PORT=7070; MODE="server"; TARGET="target"

while [[ $# -gt 0 ]]; do
  case $1 in
    --cli)  MODE="cli"; TARGET="${2:-target}"; shift 2 ;;
    --port) PORT="$2"; shift 2 ;;
    --help)
      echo "Usage: ./run.sh [--cli <path>] [--port <port>]"
      exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

check() {
  command -v "$1" > /dev/null 2>&1 || {
    echo "ERROR: '$1' not found. Install: $2"; exit 1
  }
}

echo ""
echo "════════════════════════════════════════════════════"
echo "  MAXXKI Deep Semantic Analyser v3.0"
echo "════════════════════════════════════════════════════"
check node  "nodejs"
check javac "openjdk-17"
check java  "openjdk-17"
echo "  node  $(node --version)"
echo "  java  $(java -version 2>&1 | head -1 | awk '{print $3}' | tr -d '\"')"
echo "════════════════════════════════════════════════════"

if [ ! -f Orchestrator.class ] || [ Orchestrator.java -nt Orchestrator.class ]; then
  echo "  Compiling Orchestrator.java ..."
  javac Orchestrator.java
fi

mkdir -p output

if [ "$MODE" = "server" ]; then
  echo "  Starting server → http://localhost:$PORT"
  echo "  Semantic: SCC · Taint · Memory · Side Effects · Domain"
  echo "  Press Ctrl+C to stop."
  echo "════════════════════════════════════════════════════"
  java Orchestrator --server "$PORT"
else
  echo "  CLI mode → $TARGET"
  echo "════════════════════════════════════════════════════"
  java Orchestrator "$TARGET"
fi
