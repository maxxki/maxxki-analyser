#!/bin/bash
# MAXXKI Setup Script

echo "🔧 MAXXKI Deep Semantic Analyser Setup"

# Check Java
if ! command -v java &> /dev/null; then
    echo "❌ Java not found. Please install Java 17+"
    exit 1
fi

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install Node.js"
    exit 1
fi

# Compile
echo "📦 Compiling..."
mvn clean compile assembly:single

# Create directories
mkdir -p output hashes exports

# Copy config template
if [ ! -f config/maxxki.properties ]; then
    cp config/maxxki.properties.example config/maxxki.properties
    echo "✅ Created config/maxxki.properties – edit before running"
fi

echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit config/maxxki.properties"
echo "2. Start llama.cpp server"
echo "3. Run: java -jar target/maxxki-3.1-llm.jar --server 7070"
