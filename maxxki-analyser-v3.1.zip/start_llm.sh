#!/bin/bash
# ════════════════════════════════════════════════════════════════
#  MAXXKI + LLM Watchdog  v1.0
#  Starts llama-server and Orchestrator.
#  Keeps both alive – auto-restarts on crash.
# ════════════════════════════════════════════════════════════════

set -euo pipefail

# ── Configuration (override via env or maxxki.properties) ───────
LLAMA_BIN="${LLAMA_BIN:-/usr/local/bin/llama-server}"
MODEL_PATH="${MODEL_PATH:-$HOME/models/llama-3.2-3b-instruct-q4_k_m.gguf}"
ORCHESTRATOR_JAR="${ORCHESTRATOR_JAR:-./target/maxxki-3.1-llm.jar}"
CONFIG_FILE="${CONFIG_FILE:-./config/maxxki.properties}"
LOG_DIR="${LOG_DIR:-./logs}"
LLAMA_PORT="${LLAMA_PORT:-8080}"
ORCH_PORT="${ORCH_PORT:-7070}"
RESTART_DELAY="${RESTART_DELAY:-5}"
CTX_SIZE="${CTX_SIZE:-4096}"
THREADS="${THREADS:-4}"
N_PREDICT="${N_PREDICT:-512}"

# ── Colour codes ─────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

mkdir -p "$LOG_DIR"

# ── Logging helper ───────────────────────────────────────────────
log() {
    local ts
    ts="$(date '+%H:%M:%S')"
    echo -e "[${ts}] $1"
    echo "[${ts}] $(echo -e "$1" | sed 's/\x1b\[[0-9;]*m//g')" >> "$LOG_DIR/watchdog_$(date +%Y%m%d).log"
}

# ── Sanity checks ─────────────────────────────────────────────────
check_requirements() {
    local ok=true

    if [ ! -f "$MODEL_PATH" ]; then
        log "${RED}ERROR: Model not found: $MODEL_PATH${NC}"
        log "Set MODEL_PATH env variable or place model at the above path."
        ok=false
    fi

    if [ ! -x "$LLAMA_BIN" ]; then
        log "${RED}ERROR: llama-server not found or not executable: $LLAMA_BIN${NC}"
        log "Install llama.cpp and set LLAMA_BIN env variable."
        ok=false
    fi

    if [ ! -f "$ORCHESTRATOR_JAR" ]; then
        log "${YELLOW}WARNING: JAR not found: $ORCHESTRATOR_JAR${NC}"
        log "Attempting to run from class files (dev mode)..."
    fi

    if ! command -v java &> /dev/null; then
        log "${RED}ERROR: java not found in PATH${NC}"
        ok=false
    fi

    if ! command -v curl &> /dev/null; then
        log "${YELLOW}WARNING: curl not found – health checks disabled${NC}"
    fi

    $ok || exit 1
}

# ── llama-server control ──────────────────────────────────────────
LLAMA_PID=""
LLAMA_LOG=""

start_llama() {
    local date_suffix
    date_suffix="$(date +%Y%m%d_%H%M%S)"
    LLAMA_LOG="$LOG_DIR/llama_${date_suffix}.log"

    log "${GREEN}Starting llama-server...${NC}"
    log "  Model  : $MODEL_PATH"
    log "  Port   : $LLAMA_PORT"
    log "  Log    : $LLAMA_LOG"

    "$LLAMA_BIN" \
        --model     "$MODEL_PATH"  \
        --host      127.0.0.1      \
        --port      "$LLAMA_PORT"  \
        --ctx-size  "$CTX_SIZE"    \
        --threads   "$THREADS"     \
        --n-predict "$N_PREDICT"   \
        --log-disable              \
        > "$LLAMA_LOG" 2>&1 &

    LLAMA_PID=$!
    log "${GREEN}llama-server PID=$LLAMA_PID${NC}"
}

wait_llama() {
    log "${CYAN}Waiting for llama-server (port $LLAMA_PORT)...${NC}"
    for i in $(seq 1 60); do
        if curl -sf "http://127.0.0.1:${LLAMA_PORT}/health" > /dev/null 2>&1; then
            log "${GREEN}llama-server ready (${i}×2s = $((i*2))s)${NC}"
            return 0
        fi
        # Check if process still alive
        if [ -n "$LLAMA_PID" ] && ! kill -0 "$LLAMA_PID" 2>/dev/null; then
            log "${RED}llama-server process died during startup${NC}"
            tail -20 "$LLAMA_LOG" 2>/dev/null | while read -r line; do log "  [llama] $line"; done
            return 1
        fi
        sleep 2
    done
    log "${RED}llama-server not ready after 120s${NC}"
    return 1
}

llama_alive() {
    [ -n "$LLAMA_PID" ] && \
    kill -0 "$LLAMA_PID" 2>/dev/null && \
    curl -sf "http://127.0.0.1:${LLAMA_PORT}/health" > /dev/null 2>&1
}

# ── Orchestrator control ──────────────────────────────────────────
ORCH_PID=""

start_orchestrator() {
    log "${GREEN}Starting Orchestrator...${NC}"
    log "  Port   : $ORCH_PORT"
    log "  Config : $CONFIG_FILE"

    local date_suffix
    date_suffix="$(date +%Y%m%d_%H%M%S)"
    local ORCH_LOG="$LOG_DIR/orchestrator_${date_suffix}.log"

    if [ -f "$ORCHESTRATOR_JAR" ]; then
        java -jar "$ORCHESTRATOR_JAR" \
            -Djava.util.logging.SimpleFormatter.format='[%1$tT] %4$s %2$s: %5$s%n' \
            --server "$ORCH_PORT" \
            > "$ORCH_LOG" 2>&1 &
    else
        # Dev mode: compile + run from source
        java \
            -cp ".:libs/*" \
            -Djava.util.logging.SimpleFormatter.format='[%1$tT] %4$s %2$s: %5$s%n' \
            Orchestrator --server "$ORCH_PORT" \
            > "$ORCH_LOG" 2>&1 &
    fi

    ORCH_PID=$!
    log "${GREEN}Orchestrator PID=$ORCH_PID, log=$ORCH_LOG${NC}"
}

wait_orchestrator() {
    log "${CYAN}Waiting for Orchestrator (port $ORCH_PORT)...${NC}"
    for i in $(seq 1 20); do
        if curl -sf "http://127.0.0.1:${ORCH_PORT}/api/health" > /dev/null 2>&1; then
            log "${GREEN}Orchestrator ready${NC}"
            return 0
        fi
        if [ -n "$ORCH_PID" ] && ! kill -0 "$ORCH_PID" 2>/dev/null; then
            log "${RED}Orchestrator process died during startup${NC}"
            return 1
        fi
        sleep 2
    done
    log "${RED}Orchestrator not ready after 40s${NC}"
    return 1
}

orchestrator_alive() {
    [ -n "$ORCH_PID" ] && kill -0 "$ORCH_PID" 2>/dev/null
}

# ── Graceful shutdown ──────────────────────────────────────────────
ORCH_CRASHES=0
LLAMA_CRASHES=0

cleanup() {
    echo ""
    log "${YELLOW}Shutting down MAXXKI + LLM...${NC}"
    [ -n "$ORCH_PID"  ] && kill "$ORCH_PID"  2>/dev/null && log "Orchestrator stopped."
    [ -n "$LLAMA_PID" ] && kill "$LLAMA_PID" 2>/dev/null && log "llama-server stopped."
    log "Goodbye."
    exit 0
}

trap cleanup INT TERM EXIT

# ── Log rotation (keep 7 days) ────────────────────────────────────
rotate_logs() {
    find "$LOG_DIR" -name "*.log" -mtime +7 -delete 2>/dev/null || true
}

# ── Status report ─────────────────────────────────────────────────
print_status() {
    log "${GREEN}════════════════════════════════════════════════════════════${NC}"
    log "${GREEN}  MAXXKI + LLM – All services running${NC}"
    log "${GREEN}════════════════════════════════════════════════════════════${NC}"
    log "  Dashboard  : http://localhost:${ORCH_PORT}"
    log "  LLM API    : http://localhost:${LLAMA_PORT}"
    log "  Health     : http://localhost:${ORCH_PORT}/api/health"
    log "  LLM Health : http://localhost:${ORCH_PORT}/api/llm/health"
    log "  LLM Analyze: POST http://localhost:${ORCH_PORT}/api/llm/analyze"
    log "  Discourse  : POST http://localhost:${ORCH_PORT}/api/llm/discourse"
    log "${GREEN}════════════════════════════════════════════════════════════${NC}"
}

# ── Main ─────────────────────────────────────────────────────────
echo ""
log "${GREEN}════════════════════════════════════════════════════════════${NC}"
log "  MAXXKI + LLM Watchdog v1.0"
log "  Model  : $MODEL_PATH"
log "  Config : $CONFIG_FILE"
log "  Logs   : $LOG_DIR"
log "  Ctrl+C to stop"
log "${GREEN}════════════════════════════════════════════════════════════${NC}"

check_requirements
rotate_logs

while true; do

    # ── Ensure llama-server is running ──────────────────────────────
    if ! llama_alive; then
        [ -n "$LLAMA_PID" ] && kill "$LLAMA_PID" 2>/dev/null
        LLAMA_CRASHES=$((LLAMA_CRASHES + 1))
        [ "$LLAMA_CRASHES" -gt 1 ] && log "${RED}llama-server crash #${LLAMA_CRASHES}${NC}"

        start_llama
        if ! wait_llama; then
            log "${RED}llama-server failed to start. Retry in 30s...${NC}"
            sleep 30
            continue
        fi
    fi

    # ── Start Orchestrator ────────────────────────────────────────
    start_orchestrator
    if ! wait_orchestrator; then
        log "${RED}Orchestrator failed to start. Retry in ${RESTART_DELAY}s...${NC}"
        [ -n "$ORCH_PID" ] && kill "$ORCH_PID" 2>/dev/null
        sleep "$RESTART_DELAY"
        continue
    fi

    print_status

    # ── Monitor both processes ────────────────────────────────────
    while true; do
        sleep 10

        if ! orchestrator_alive; then
            ORCH_CRASHES=$((ORCH_CRASHES + 1))
            log "${RED}Orchestrator died (crash #${ORCH_CRASHES}). Restarting...${NC}"
            break
        fi

        if ! llama_alive; then
            LLAMA_CRASHES=$((LLAMA_CRASHES + 1))
            log "${RED}llama-server died (crash #${LLAMA_CRASHES}). Restarting both...${NC}"
            [ -n "$ORCH_PID" ] && kill "$ORCH_PID" 2>/dev/null
            ORCH_PID=""
            break
        fi
    done

    sleep "$RESTART_DELAY"

done
